
// Copyright 2012 Google Inc. All rights reserved.
(function(w,g){w[g]=w[g]||{};w[g].e=function(s){return eval(s);};})(window,'google_tag_manager');(function(){

var data = {
"resource": {
  "version":"346",
  
  "macros":[{
      "function":"__u",
      "vtp_component":"URL",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__e"
    },{
      "function":"__u",
      "vtp_component":"PATH",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__u",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__u",
      "vtp_component":"QUERY",
      "vtp_customUrlSource":["macro",0],
      "vtp_queryKey":"subscribed",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__u",
      "vtp_component":"QUERY",
      "vtp_queryKey":"amt",
      "vtp_customUrlSource":["macro",0],
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__aev",
      "vtp_varType":"TEXT"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){try{return window.top!==window.self}catch(a){return!1}})();"]
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"conference.year"
    },{
      "function":"__remm",
      "convert_case_to":1,
      "vtp_setDefaultValue":false,
      "vtp_input":["macro",0],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":false,
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key",".*\\.oreilly\\.com.*schedule\\\/(grid|full|presentations|stype|stopic|proceedings).*","value","Schedule"],["map","key",".*\\.oreilly\\.com.*schedule\\\/speaker.*","value","Speakers"],["map","key",".*\\.oreilly\\.com.*public\\\/register.*","value","Registration"],["map","key",".*\\.oreilly\\.com.*user\\\/account.*","value","User Info"],["map","key",".*\\.oreilly\\.com.*\\\/hotel.*","value","Venue, travel, and hotel"],["map","key",".*\\.oreilly\\.com.*schedule\\\/detail\\\/.*","value","Sessions, Tutorials, Keynotes"],["map","key",".*\\.oreilly\\.com.*users\\\/sign_in.*","value","Sign In or Create a New Account"],["map","key",".*\\.oreilly\\.com.*\\\/sponsors.*","value","Sponsors"],["map","key",".*\\.oreilly\\.com.*\\\/about.*","value","About"],["map","key",".*\\.oreilly\\.com.*\\\/resources.*","value","Resources"],["map","key",".*\\.oreilly\\.com.*\\\/(cfp|proposal|reviewing).*","value","CFP"]]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=document.location.hostname.match(\/(([^.\\\/]+\\.[^.\\\/]{2,3}\\.[^.\\\/]{2})|(([^.\\\/]+\\.)[^.\\\/]{2,4}))(\\\/.*)?$\/)[1];return a=a.toLowerCase()})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return function(b){var c=\/www.oreilly.com\\\/member\\\/(register|login|reset-password|profile)?\\\/?(\\?(.*))?$\/i,d=\/linkedin\\.com\\\/(oauth\\\/v(.*)\\\/login-success|uas\\\/login|uas\\\/oauth2\\\/authorization)\\\/?(\\?(.*))?$\/i,e=\/facebook\\.com\\\/(login\\.php|v(.*)\\\/dialog\\\/oauth(.*))\/i,f=\/api\\.twitter\\.com\\\/oauth\\\/(authorize|authenticate)\\\/?(\\?(.*))?$\/i,g=\/accounts\\.google\\.(.*)\\\/(signin\\\/oauth\\\/consent|accounts\\\/SetSID|signin\\\/oauth\\\/oauthchooseaccount)(\\?(.*))?$\/i,a=document.referrer;(c.test(a)||d.test(a)||\ne.test(a)||f.test(a)||g.test(a))\u0026\u0026b.set(\"referrer\",null)}})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"userIdentifier"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"conference.franchise"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"conference.location"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"businessLine"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"paymentMethod"
    },{
      "function":"__remm",
      "vtp_setDefaultValue":false,
      "vtp_input":["macro",0],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":false,
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key","^.*conferences.oreilly.com\\\/(strata($|\\\/|\\?).*)|^.*conferences.oreilly.com\\\/(strata\\-data\\-ai($|\\\/|\\?).*)","value","UA-112091926-2"],["map","key","^.*conferences.oreilly.com\\\/(software-?architecture($|\\\/|\\?).*)","value","UA-112091926-3"],["map","key","^.*conferences.oreilly.com\\\/(artificial-intelligence($|\\\/|\\?).*)","value","UA-112091926-4"],["map","key","^.*ai.oreilly.com.cn\\\/ai-cn(\\\/?|(.*))$","value","UA-112091926-4"],["map","key","^.*conferences.oreilly.com\\\/(velocity($|\\\/|\\?).*)","value","UA-112091926-5"],["map","key","^.*conferences.oreilly.com\\\/(fluent($|\\\/|\\?).*)","value","UA-112091926-6"],["map","key","^.*conferences.oreilly.com\\\/(oscon($|\\\/|\\?).*)","value","UA-112091926-7"],["map","key","^.*conferences.oreilly.com\\\/(jupyter($|\\\/|\\?).*)","value","UA-112091926-8"],["map","key","(.*)oreilly.com\\\/blended-courses.*","value","UA-112091926-11"],["map","key","^.*conferences.oreilly.com\\\/(tensorflow($|\\\/|\\?).*)","value","UA-112091926-12"],["map","key","^.*conferences.oreilly.com\\\/(infrastructure-ops($|\\\/|\\?).*)","value","UA-112091926-13"]]
    },{
      "function":"__gas",
      "vtp_useDebugVersion":false,
      "vtp_useHashAutoLink":false,
      "vtp_contentGroup":["list",["map","index","2","group",["macro",8]],["map","index","1","group",["macro",9]]],
      "vtp_decorateFormsAutoLink":false,
      "vtp_cookieDomain":["macro",10],
      "vtp_useEcommerceDataLayer":true,
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_fieldsToSet":["list",["map","fieldName","customTask","value",["macro",11]],["map","fieldName","allowLinker","value","true"],["map","fieldName","userId","value",["macro",12]]],
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index","1","dimension",["macro",13]],["map","index","2","dimension",["macro",14]],["map","index","3","dimension",["macro",8]],["map","index","4","dimension",["macro",15]],["map","index","5","dimension",["macro",16]],["map","index","6","dimension",["macro",12]]],
      "vtp_enableEcommerce":true,
      "vtp_trackingId":["macro",17],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableTransportUrl":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_ecommerceIsEnabled":true
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"0",
      "vtp_name":"nonInteraction"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"eventVal"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"eventCat"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"eventAct"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"eventLbl"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"VPUrl"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return ",["escape",["macro",24],8,16],".replace(\"\/conferences.oreilly.com\",\"\")})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"VPTitle"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"content.parentTopic"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"content.formatType"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){if(-1\u003Cdocument.location.href.indexOf(\"www.safaribooksonline.com\"))return\"oreilly.com\";if(-1\u003Cdocument.location.href.indexOf(\"oreilly.com\"))return\"www.safaribooksonline.com\"})();"]
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"formSuccessURL"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",30],8,16],";if(void 0!=a\u0026\u0026\"\"!=a\u0026\u0026null!=a)return a;if(2==",["escape",["macro",2],8,16],".split(\"\/\").length\u0026\u0026!",["escape",["macro",2],8,16],".endsWith(\".html\")){if(-1\u003C",["escape",["macro",0],8,16],".indexOf(\"?\")\u0026\u00260\u003E",["escape",["macro",0],8,16],".indexOf(\"\/?\"))return ",["escape",["macro",2],8,16],"+\"\/?\"+",["escape",["macro",0],8,16],".split(\"?\")[1];if(!(-1\u003C",["escape",["macro",0],8,16],".indexOf(\"\/?\")))return ",["escape",["macro",2],8,16],"+\"\/\"}})();"]
    },{
      "function":"__u",
      "vtp_component":"HOST",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__remm",
      "convert_case_to":1,
      "vtp_setDefaultValue":false,
      "vtp_input":["macro",32],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":false,
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key","www.safaribooksonline.com|learning.oreilly.com","value","Learning Platform"],["map","key","www.oreilly.com|get.oreilly.com|members.oreilly.com","value","Content \u0026 Marketing"]]
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"loggedIn"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"membersLoggedIn"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"product.title"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"product.type"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"product.identifier"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"content.title"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"content.identifier"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"content.author"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"content.publisher"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"content.releaseDate"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"product.topic"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"content.free"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"content.subdirectory"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"content.subTopic"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"learningPaidAccount"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"learningAccountType"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"organization"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"myTopics.add"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"myTopics.remove"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"slider.name"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"slider.cardTitle"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"sectionName"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"cardTitle"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"filterName"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"sponsorName"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"orgID"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"topicSearchValue"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"searchSuggestGroup"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ld.experiment"
    },{
      "function":"__v",
      "convert_case_to":1,
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ld.variation"
    },{
      "function":"__remm",
      "vtp_setDefaultValue":false,
      "vtp_input":["macro",0],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":false,
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key","(.*)(get.oreilly.com|www.oreilly.com|members.oreilly.com|shop.oreilly.com|ssearch.oreilly.com|learning.oreilly.com|oreilly.review|nc\\-proxy.binderhub\\-prod.gcp.oreilly.com)(.*)","value","UA-112091926-1"]]
    },{
      "function":"__gas",
      "vtp_useDebugVersion":false,
      "vtp_useHashAutoLink":false,
      "vtp_contentGroup":["list",["map","index","3","group",["macro",27]],["map","index","4","group",["macro",28]]],
      "vtp_decorateFormsAutoLink":false,
      "vtp_autoLinkDomains":["macro",29],
      "vtp_cookieDomain":["macro",10],
      "vtp_useEcommerceDataLayer":true,
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_fieldsToSet":["list",["map","fieldName","page","value",["macro",31]],["map","fieldName","allowLinker","value","true"],["map","fieldName","userId","value",["macro",12]]],
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index","1","dimension",["macro",33]],["map","index","2","dimension",["macro",34]],["map","index","4","dimension",["macro",35]],["map","index","9","dimension",["macro",36]],["map","index","10","dimension",["macro",37]],["map","index","11","dimension",["macro",38]],["map","index","12","dimension",["macro",39]],["map","index","13","dimension",["macro",28]],["map","index","14","dimension",["macro",40]],["map","index","15","dimension",["macro",41]],["map","index","16","dimension",["macro",42]],["map","index","17","dimension",["macro",43]],["map","index","18","dimension",["macro",27]],["map","index","19","dimension",["macro",44]],["map","index","20","dimension",["macro",45]],["map","index","21","dimension",["macro",46]],["map","index","27","dimension",["macro",47]],["map","index","22","dimension",["macro",16]],["map","index","6","dimension",["macro",48]],["map","index","7","dimension",["macro",49]],["map","index","8","dimension",["macro",50]],["map","index","25","dimension",["macro",51]],["map","index","26","dimension",["macro",52]],["map","index","23","dimension",["macro",53]],["map","index","24","dimension",["macro",54]],["map","index","28","dimension",["macro",55]],["map","index","30","dimension",["macro",56]],["map","index","29","dimension",["macro",57]],["map","index","31","dimension",["macro",58]],["map","index","32","dimension",["macro",59]],["map","index","33","dimension",["macro",12]],["map","index","34","dimension",["macro",60]],["map","index","36","dimension",["macro",61]],["map","index","37","dimension",["macro",62]],["map","index","38","dimension",["macro",63]]],
      "vtp_enableEcommerce":true,
      "vtp_trackingId":["macro",64],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableTransportUrl":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_ecommerceIsEnabled":true
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",19],8,16],";if(\"profile icon\"==",["escape",["macro",21],8,16],"\u0026\u0026\"hover\"==",["escape",["macro",22],8,16],"||\"global\"==",["escape",["macro",21],8,16],"\u0026\u0026\"navigation\"==",["escape",["macro",22],8,16],"\u0026\u0026\"your oreilly|hover\"==",["escape",["macro",23],8,16],")a=1;return a})();"]
    },{
      "function":"__v",
      "vtp_name":"gtm.historyChangeSource",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.triggers",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":""
    },{
      "function":"__v",
      "vtp_name":"gtm.scrollThreshold",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.videoStatus",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.videoPercent",
      "vtp_dataLayerVersion":1
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",70],8,16],";switch(a){case \"start\":return\"play\";case \"progress\":return\"\"+",["escape",["macro",71],8,16],"+\"%\"}})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":1,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"0",
      "vtp_name":"Campaign-170"
    },{
      "function":"__u",
      "vtp_component":"QUERY",
      "vtp_queryKey":"oid",
      "vtp_customUrlSource":["macro",0],
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__u",
      "vtp_component":"QUERY",
      "vtp_queryKey":"type",
      "vtp_customUrlSource":["macro",0],
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__u",
      "vtp_component":"QUERY",
      "vtp_queryKey":"ccy",
      "vtp_customUrlSource":["macro",0],
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__remm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",0],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":true,
      "vtp_ignoreCase":true,
      "vtp_defaultValue":"false",
      "vtp_map":["list",["map","key",".*www.oreilly.com.*","value","true"],["map","key",".*learning.oreilly.com.*learning-paths.*","value","true"],["map","key",".*learning.oreilly.com.*case-studies.*","value","true"],["map","key",".*learning.oreilly.com.*live-training.*","value","true"],["map","key",".*conferences.oreilly.com.*","value","true"]]
    },{
      "function":"__f",
      "vtp_component":"URL"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ecommerce.purchase.actionField.revenue"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ecommerce.purchase.actionField.id"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"logged_in"
    },{
      "function":"__u",
      "vtp_component":"QUERY",
      "vtp_queryKey":"term",
      "vtp_customUrlSource":["macro",0],
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__gas",
      "vtp_cookieDomain":"auto",
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_useHashAutoLink":false,
      "vtp_decorateFormsAutoLink":false,
      "vtp_enableLinkId":false,
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-39299553-7",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableTransportUrl":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false
    },{
      "function":"__gas",
      "vtp_cookieDomain":"auto",
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_useHashAutoLink":false,
      "vtp_decorateFormsAutoLink":false,
      "vtp_enableLinkId":false,
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-39299553-8",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableTransportUrl":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false
    },{
      "function":"__remm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",0],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":true,
      "vtp_defaultValue":"false",
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key",".*www.oreilly.com.*data-science.*|.*conferences.oreilly.com.*data-science.*","value","true"],["map","key",".*www.oreilly.com.*big-data.*|.*conferences.oreilly.com.*big-data.*","value","true"],["map","key",".*www.oreilly.com.*machine-learning.*|.*conferences.oreilly.com.*machine-learning.*","value","true"],["map","key",".*www.oreilly.com.*data-engineering.*|.*conferences.oreilly.com.*data-engineering.*","value","true"],["map","key",".*www.oreilly.com.*data-architecture.*|.*conferences.oreilly.com.*data-architecture.*","value","true"],["map","key",".*www.oreilly.com.*business-intelligence.*|.*conferences.oreilly.com.*business-intelligence.*","value","true"]]
    },{
      "function":"__remm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",0],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":true,
      "vtp_defaultValue":"false",
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key",".*www.oreilly.com.*artificial-intelligence.*|.*conferences.oreilly.com.*artificial-intelligence.*","value","true"],["map","key",".*www.oreilly.com.*machine-learning.*|.*conferences.oreilly.com.*machine-learning.*","value","true"],["map","key",".*www.oreilly.com.*deep-learning.*|.*conferences.oreilly.com.*deep-learning.*","value","true"],["map","key",".*www.oreilly.com.*reinforcement-learning.*|.*conferences.oreilly.com.*reinforcement-learning.*","value","true"],["map","key",".*www.oreilly.com.*neural-networks.*|.*conferences.oreilly.com.*neural-networks.*","value","true"],["map","key",".*www.oreilly.com.*GANS.*|.*conferences.oreilly.com.*GANS.*","value","true"],["map","key",".*www.oreilly.com.*NLP.*|.*conferences.oreilly.com.*NLP.*","value","true"],["map","key",".*www.oreilly.com.*natural-language-processing.*|.*conferences.oreilly.com.*natural-language-processing.*","value","true"],["map","key",".*www.oreilly.com.*NSTM.*|.*conferences.oreilly.com.*NSTM.*","value","true"],["map","key",".*www.oreilly.com.*tensorflow.*|.*conferences.oreilly.com.*tensorflow.*","value","true"]]
    },{
      "function":"__remm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",0],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":true,
      "vtp_defaultValue":"False",
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key","https:\/\/conferences.oreilly.com\/software-architecture\/sa-ny\/public\/content\/sponsors","value","True"],["map","key","https:\/\/conferences.oreilly.com\/software-architecture\/sa-ny\/public\/content\/resources","value","True"]]
    },{
      "function":"__smm",
      "convert_case_to":1,
      "vtp_setDefaultValue":false,
      "vtp_input":["macro",70],
      "vtp_map":["list",["map","key","start","value","play"],["map","key","progress","value",["macro",71]]]
    },{
      "function":"__remm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",0],
      "vtp_fullMatch":false,
      "vtp_replaceAfterMatch":true,
      "vtp_defaultValue":"False",
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key","https:\/\/conferences.oreilly.com\/strata\/strata-ca\/public\/schedule\/topic\/2867","value","True"],["map","key","conferences.oreilly.com\/strata\/strata-ca\/public\/register\/purchased","value","True"]]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"transactionID"
    },{
      "function":"__remm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",0],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":true,
      "vtp_defaultValue":"false",
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key","conferences.oreilly.com\/strata\/strata-ca\/public\/register\/purchased*","value","true"],["map","key","conferences.oreilly.com\/strata\/strata-ca\/public\/register\/invoice*","value","true"]]
    },{
      "function":"__remm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",0],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":true,
      "vtp_defaultValue":"false",
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key",".*www.oreilly.com.*data-science.*|.*conferences.oreilly.com.*data-science.*","value","true"],["map","key",".*www.oreilly.com.*big-data.*|.*conferences.oreilly.com.*big-data.*","value","true"],["map","key",".*www.oreilly.com.*machine-learning.*|.*conferences.oreilly.com.*machine-learning.*","value","true"],["map","key",".*www.oreilly.com.*data-engineering.*|.*conferences.oreilly.com.*data-engineering.*","value","true"],["map","key",".*www.oreilly.com.*data-architecture.*|.*conferences.oreilly.com.*data-architecture.*","value","true"],["map","key",".*www.oreilly.com.*business-intelligence.*|.*conferences.oreilly.com.*business-intelligence.*","value","true"],["map","key",".*www.oreilly.com.*databases.*|.*conferences.oreilly.com.*databases.*","value","true"],["map","key",".*www.oreilly.com.*analytics.*|.*conferences.oreilly.com.*analytics.*","value","true"],["map","key",".*www.oreilly.com.*data-show-podcasts.*|.*conferences.oreilly.com.*data-show-podcasts.*","value","true"]]
    },{
      "function":"__remm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",0],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":true,
      "vtp_defaultValue":"false",
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key",".*www.oreilly.com.*machine-learning.*|.*conferences.oreilly.com.*machine-learning.*","value","true"],["map","key",".*www.oreilly.com.*deep-learning.*|.*conferences.oreilly.com.*deep-learning.*","value","true"],["map","key",".*www.oreilly.com.*reinforcement-learning.*|.*conferences.oreilly.com.*reinforcement-learning.*","value","true"],["map","key",".*www.oreilly.com.*neural-networks.*|.*conferences.oreilly.com.*neural-networks.*","value","true"],["map","key",".*www.oreilly.com.*natural-language-processing.*|.*conferences.oreilly.com.*natural-language-processing.*","value","true"],["map","key",".*www.oreilly.com.*bots.*|.*conferences.oreilly.com.*bots.*","value","true"],["map","key",".*www.oreilly.com.*agents.*|.*conferences.oreilly.com.*agents.*","value","true"],["map","key",".*www.oreilly.com.*tensorflow.*|.*conferences.oreilly.com.*tensorflow.*","value","true"]]
    },{
      "function":"__remm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",0],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":true,
      "vtp_defaultValue":"false",
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key",".*www.oreilly.com.*open-source.*|.*conferences.oreilly.com.*open-source.*","value","true"],["map","key",".*www.oreilly.com.*cloud-native.*|.*conferences.oreilly.com.*cloud-native.*","value","true"],["map","key",".*www.oreilly.com.*software-development.*|.*conferences.oreilly.com.*software-development.*","value","true"],["map","key",".*www.oreilly.com.*blockchain.*|.*conferences.oreilly.com.*blockchain.*","value","true"]]
    },{
      "function":"__remm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",0],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":true,
      "vtp_defaultValue":"False",
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key","https:\/\/conferences.oreilly.com\/oscon\/oscon-or\/public\/content\/sponsors","value","True"],["map","key","https:\/\/conferences.oreilly.com\/oscon\/oscon-or\/public\/content\/resources","value","True"]]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){max=100;min=1;return Math.floor(Math.random()*(max-min+1))+min})();"]
    },{
      "function":"__remm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",0],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":true,
      "vtp_defaultValue":"False",
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key","conferences.oreilly.com\/strata\/strata-ny\/public\/content\/sponsors","value","True"],["map","key","conferences.oreilly.com\/strata\/strata-ny\/public\/content\/resources","value","True"]]
    },{
      "function":"__remm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",0],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":true,
      "vtp_defaultValue":"false",
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key",".*artificial-intelligence.*","value","true"],["map","key",".*tensorflow.*","value","true"],["map","key",".*neural-networks.*","value","true"],["map","key",".*data-mining.*","value","true"],["map","key",".*unsupervised-learning.*","value","true"],["map","key",".*deep-learning.*","value","true"],["map","key",".*machine-learning.*","value","true"]]
    },{
      "function":"__remm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",0],
      "vtp_fullMatch":true,
      "vtp_replaceAfterMatch":true,
      "vtp_defaultValue":"False",
      "vtp_ignoreCase":true,
      "vtp_map":["list",["map","key","conferences.oreilly.com\/software-architecture\/sa-eu\/public\/content\/sponsors","value","True"],["map","key","conferences.oreilly.com\/software-architecture\/sa-eu\/public\/content\/resources","value","True"]]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":1,
      "vtp_setDefaultValue":false,
      "vtp_name":"ecommerce"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"Revenue"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"OrderID"
    },{
      "function":"__e"
    },{
      "function":"__v",
      "vtp_name":"gtm.element",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.elementClasses",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.elementId",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.elementTarget",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.elementUrl",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.scrollUnits",
      "vtp_dataLayerVersion":1
    }],
  "tags":[{
      "function":"__html",
      "priority":10,
      "once_per_event":true,
      "vtp_html":"\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(){function b(){!1===c\u0026\u0026(c=!0,Munchkin.init(\"107-FMS-070\"))}var c=!1,a=document.createElement(\"script\");a.type=\"text\/javascript\";a.async=!0;a.src=\"\/\/munchkin.marketo.net\/munchkin.js\";a.onreadystatechange=function(){\"complete\"!=this.readyState\u0026\u0026\"loaded\"!=this.readyState||b()};a.onload=b;document.getElementsByTagName(\"head\")[0].appendChild(a)})();\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":43
    },{
      "function":"__html",
      "priority":1,
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/get.oreilly.com\/rs\/107-FMS-070\/images\/digitalpi-utm-tracker-oreilly.com.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":47
    },{
      "function":"__awct",
      "once_per_event":true,
      "vtp_enableConversionLinker":true,
      "vtp_conversionCookiePrefix":"_gcl",
      "vtp_conversionId":"1047975969",
      "vtp_conversionLabel":"WjAECOPA2nMQobDb8wM",
      "vtp_url":["macro",3],
      "vtp_enableProductReportingCheckbox":true,
      "vtp_enableNewCustomerReportingCheckbox":false,
      "vtp_enableEnhancedConversionsCheckbox":false,
      "vtp_enableRdpCheckbox":true,
      "vtp_enableTransportUrl":false,
      "tag_id":31
    },{
      "function":"__sp",
      "once_per_event":true,
      "vtp_conversionId":"1047975969",
      "vtp_customParamsFormat":"NONE",
      "vtp_enableOgtRmktParams":true,
      "vtp_enableUserId":false,
      "vtp_url":["macro",3],
      "vtp_enableRdpCheckbox":true,
      "tag_id":32
    },{
      "function":"__bzi",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_id":"70561",
      "tag_id":34
    },{
      "function":"__awct",
      "once_per_event":true,
      "vtp_enableConversionLinker":true,
      "vtp_conversionCookiePrefix":"_gcl",
      "vtp_conversionId":"837681939",
      "vtp_conversionLabel":"tfRcCMnwwHQQk4a4jwM",
      "vtp_url":["macro",3],
      "vtp_enableProductReportingCheckbox":true,
      "vtp_enableNewCustomerReportingCheckbox":false,
      "vtp_enableEnhancedConversionsCheckbox":false,
      "vtp_enableRdpCheckbox":true,
      "vtp_enableTransportUrl":false,
      "tag_id":35
    },{
      "function":"__sp",
      "once_per_event":true,
      "vtp_conversionId":"837681939",
      "vtp_customParamsFormat":"NONE",
      "vtp_enableOgtRmktParams":true,
      "vtp_enableUserId":false,
      "vtp_url":["macro",3],
      "vtp_enableRdpCheckbox":true,
      "tag_id":36
    },{
      "function":"__awct",
      "once_per_event":true,
      "vtp_enableConversionLinker":true,
      "vtp_conversionCookiePrefix":"_gcl",
      "vtp_conversionId":"837681939",
      "vtp_conversionLabel":"zLNTCNHo-XYQk4a4jwM",
      "vtp_url":["macro",3],
      "vtp_enableProductReportingCheckbox":true,
      "vtp_enableNewCustomerReportingCheckbox":false,
      "vtp_enableEnhancedConversionsCheckbox":false,
      "vtp_enableRdpCheckbox":true,
      "vtp_enableTransportUrl":false,
      "tag_id":39
    },{
      "function":"__baut",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_tagId":"5794699",
      "vtp_uetqName":"uetq",
      "vtp_eventType":"PAGE_LOAD",
      "tag_id":40
    },{
      "function":"__baut",
      "once_per_event":true,
      "vtp_eventCategory":"Safari",
      "vtp_tagId":"5794699",
      "vtp_uetqName":"uetq",
      "vtp_eventType":"CUSTOM",
      "vtp_eventAction":"Submit",
      "tag_id":41
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_overrideGaSettings":false,
      "vtp_trackType":"TRACK_PAGEVIEW",
      "vtp_gaSettings":["macro",18],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableTransportUrl":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "tag_id":53
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":["macro",19],
      "vtp_overrideGaSettings":false,
      "vtp_eventValue":["macro",20],
      "vtp_eventCategory":["macro",21],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",18],
      "vtp_eventAction":["macro",22],
      "vtp_eventLabel":["macro",23],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableTransportUrl":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":54
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_overrideGaSettings":true,
      "vtp_fieldsToSet":["list",["map","fieldName","page","value",["macro",25]],["map","fieldName","title","value",["macro",26]]],
      "vtp_trackType":"TRACK_PAGEVIEW",
      "vtp_gaSettings":["macro",18],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableTransportUrl":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "tag_id":56
    },{
      "function":"__awct",
      "once_per_event":true,
      "vtp_enableConversionLinker":true,
      "vtp_conversionCookiePrefix":"_gcl",
      "vtp_conversionId":"837681939",
      "vtp_conversionLabel":"pYI4CLSnrXwQk4a4jwM",
      "vtp_url":["macro",3],
      "vtp_enableProductReportingCheckbox":true,
      "vtp_enableNewCustomerReportingCheckbox":false,
      "vtp_enableEnhancedConversionsCheckbox":false,
      "vtp_enableRdpCheckbox":true,
      "vtp_enableTransportUrl":false,
      "tag_id":60
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_overrideGaSettings":true,
      "vtp_trackType":"TRACK_PAGEVIEW",
      "vtp_trackingId":"UA-39299553-7",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableTransportUrl":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "tag_id":63
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_overrideGaSettings":true,
      "vtp_fieldsToSet":["list",["map","fieldName","page","value",["macro",25]],["map","fieldName","title","value",["macro",26]]],
      "vtp_trackType":"TRACK_PAGEVIEW",
      "vtp_gaSettings":["macro",65],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableTransportUrl":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "tag_id":66
    },{
      "function":"__ua",
      "metadata":["map"],
      "setup_tags":["list",["tag",64,0]],
      "once_per_event":true,
      "vtp_nonInteraction":["macro",66],
      "vtp_overrideGaSettings":false,
      "vtp_eventValue":["macro",20],
      "vtp_eventCategory":["macro",21],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",65],
      "vtp_eventAction":["macro",22],
      "vtp_eventLabel":["macro",23],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableTransportUrl":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":67
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_overrideGaSettings":false,
      "vtp_trackType":"TRACK_PAGEVIEW",
      "vtp_gaSettings":["macro",65],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableTransportUrl":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "tag_id":68
    },{
      "function":"__gclidw",
      "once_per_event":true,
      "vtp_enableCookieOverrides":false,
      "vtp_enableCrossDomainFeature":true,
      "vtp_enableCookieUpdateFeature":false,
      "tag_id":78
    },{
      "function":"__baut",
      "once_per_event":true,
      "vtp_eventCategory":"form",
      "vtp_tagId":"5794699",
      "vtp_uetqName":"uetq",
      "vtp_eventType":"CUSTOM",
      "vtp_eventAction":"submit",
      "vtp_eventLabel":"free trial",
      "tag_id":85
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":90
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":true,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"scroll tracking",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",65],
      "vtp_eventAction":["template",["macro",69],"%"],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableTransportUrl":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":93
    },{
      "function":"__sp",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_enableDynamicRemarketing":false,
      "vtp_conversionId":"AW-773515308",
      "vtp_customParamsFormat":"NONE",
      "vtp_enableOgtRmktParams":true,
      "vtp_enableUserId":false,
      "vtp_url":["macro",3],
      "vtp_enableRdpCheckbox":true,
      "tag_id":130
    },{
      "function":"__gclidw",
      "once_per_event":true,
      "vtp_enableCrossDomain":false,
      "vtp_enableCookieOverrides":false,
      "vtp_enableCrossDomainFeature":true,
      "vtp_enableCookieUpdateFeature":false,
      "tag_id":162
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventValue":"0",
      "vtp_eventCategory":"video plays",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",65],
      "vtp_eventAction":["macro",72],
      "vtp_eventLabel":["macro",39],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableTransportUrl":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":188
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":293
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":["macro",19],
      "vtp_overrideGaSettings":true,
      "vtp_useEcommerceDataLayer":true,
      "vtp_eventValue":["macro",20],
      "vtp_eventCategory":["macro",21],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",65],
      "vtp_eventAction":["macro",22],
      "vtp_eventLabel":["macro",23],
      "vtp_enableEcommerce":true,
      "vtp_enableRecaptchaOption":false,
      "vtp_enableTransportUrl":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_ecommerceIsEnabled":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":294
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":true,
      "vtp_overrideGaSettings":true,
      "vtp_eventCategory":"VWO",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_eventAction":"Custom",
      "vtp_dimension":["list",["map","index","35","dimension",["macro",73]]],
      "vtp_trackingId":"UA-112091926-1",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableTransportUrl":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":726
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_load":true,
      "vtp_nonInteraction":["macro",66],
      "vtp_overrideGaSettings":false,
      "vtp_eventValue":["macro",20],
      "vtp_eventCategory":["macro",21],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",65],
      "vtp_eventAction":["macro",22],
      "vtp_eventLabel":["macro",23],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableTransportUrl":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":759
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-N4KPR77","nickname","Account App"]],
      "vtp_boundaries":["list",["zb","_eq",["macro",0],"\/account\/",false,false]],
      "vtp_enableTypeRestrictions":true,
      "vtp_whitelistedTypes":["list",["map","typeId","hl"],["map","typeId","sdl"],["map","typeId","fsl"],["map","typeId","cl"],["map","typeId","tl"],["map","typeId","jel"],["map","typeId","ytl"],["map","typeId","lcl"],["map","typeId","evl"],["map","typeId","vis"],["map","typeId","ctv"],["map","typeId","remm"],["map","typeId","smm"],["map","typeId","c"],["map","typeId","d"],["map","typeId","e"],["map","typeId","f"],["map","typeId","j"],["map","typeId","k"],["map","typeId","r"],["map","typeId","u"],["map","typeId","v"],["map","typeId","dbg"],["map","typeId","ev"],["map","typeId","cid"],["map","typeId","aev"],["map","typeId","gas"],["map","typeId","ua"]],
      "tag_id":1214
    },{
      "function":"__tl",
      "vtp_eventName":"gtm.timer",
      "vtp_interval":"3000",
      "vtp_limit":"1",
      "vtp_uniqueTriggerId":"1669222_110",
      "tag_id":1215
    },{
      "function":"__cl",
      "tag_id":1216
    },{
      "function":"__ytl",
      "vtp_progressThresholdsPercent":"25,50,75,95",
      "vtp_captureComplete":false,
      "vtp_captureStart":true,
      "vtp_fixMissingApi":true,
      "vtp_radioButtonGroup1":"PERCENTAGE",
      "vtp_capturePause":false,
      "vtp_captureProgress":true,
      "vtp_uniqueTriggerId":"1669222_203",
      "vtp_enableTriggerStartOption":true,
      "tag_id":1217
    },{
      "function":"__sdl",
      "vtp_verticalThresholdUnits":"PERCENT",
      "vtp_verticalThresholdsPercent":"25, 50, 75, 95",
      "vtp_verticalThresholdOn":true,
      "vtp_triggerStartOption":"WINDOW_LOAD",
      "vtp_horizontalThresholdOn":false,
      "vtp_uniqueTriggerId":"1669222_204",
      "vtp_enableTriggerStartOption":true,
      "tag_id":1218
    },{
      "function":"__hl",
      "tag_id":1219
    },{
      "function":"__hl",
      "tag_id":1220
    },{
      "function":"__hl",
      "tag_id":1221
    },{
      "function":"__cl",
      "tag_id":1222
    },{
      "function":"__evl",
      "vtp_useOnScreenDuration":false,
      "vtp_useDomChangeListener":true,
      "vtp_elementSelector":"input[name='promotionCode']",
      "vtp_firingFrequency":"ONCE",
      "vtp_selectorType":"CSS",
      "vtp_onScreenRatio":"50",
      "vtp_uniqueTriggerId":"1669222_1064",
      "tag_id":1223
    },{
      "function":"__evl",
      "vtp_useOnScreenDuration":false,
      "vtp_useDomChangeListener":true,
      "vtp_elementSelector":"div.orm-ff-NavigationWidget-navigationWidgetContainer",
      "vtp_firingFrequency":"MANY_PER_ELEMENT",
      "vtp_selectorType":"CSS",
      "vtp_onScreenRatio":"50",
      "vtp_uniqueTriggerId":"1669222_1106",
      "tag_id":1224
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":["template","\n\u003Ciframe height=\"1\" width=\"1\" frameborder=\"0\" scrolling=\"no\" src=\"https:\/\/www.emjcd.com\/tags\/c?containerTagId=2775\u0026amp;ITEM1=Safari-Subscription\u0026amp;AMT1=",["escape",["macro",5],12],"\u0026amp;QTY1=1\u0026amp;CID=1525054\u0026amp;OID=",["escape",["macro",74],12],"\u0026amp;TYPE=",["escape",["macro",75],12],"\u0026amp;CURRENCY=",["escape",["macro",76],12],"\" name=\"cj_conversion\"\u003E\u003C\/iframe\u003E\n"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":30
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=\"2.0\",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,\"script\",\"https:\/\/connect.facebook.net\/en_US\/fbevents.js\");fbq(\"init\",\"1732687426968531\");fbq(\"track\",\"PageView\");\u003C\/script\u003E\n\u003Cnoscript\u003E\u003Cimg height=\"1\" width=\"1\" style=\"display:none\" src=\"https:\/\/www.facebook.com\/tr?id=1732687426968531\u0026amp;ev=PageView\u0026amp;noscript=1\"\u003E\u003C\/noscript\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":33
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Efbq(\"trackCustom\",\"SafariSubscription\");\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":46
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003Evar domains_to_track,docHost=document.location.hostname;\nif(\"conferences.oreilly.com\"==docHost.toLowerCase()||\"ai.oreilly.com.cn\"==docHost.toLowerCase()){domains_to_track=[\"conference.oreilly.com\"];var folders_to_track=",["escape",["macro",2],8,16],".split(\"\/\")[1]}else if(\"shop.oreilly.com\"==docHost.toLowerCase())domains_to_track=[\"shop.oreilly.com\"],folders_to_track=",["escape",["macro",2],8,16],".split(\"\/\")[1];else if(\"oreilly.com\"==docHost.toLowerCase()||\"www.oreilly.com\"==docHost.toLowerCase())domains_to_track=[\"www.oreilly.com\"],folders_to_track=\"\";\nvar extDoc=\".doc .docx .xls .xlsx .xlsm .ppt .pptx .exe .zip .pdf .js .txt .csv\".split(\" \"),socSites=\"\",isSubDomainTracker=!0,isSeparateDomainTracker=!0,isGTM=!0,eValues={downloads:{category:\"Assets\",action:\"Download\",label:\"\",value:0,nonInteraction:0},outbound_downloads:{category:\"Outbound Assets\",action:\"Download\",label:\"\",value:0,nonInteraction:0},outbounds_oreilly:{category:\"Outbound Links\",action:\"Oreilly\",label:\"\",value:0,nonInteraction:0},outbounds:{category:\"Outbound Links\",action:\"Non-Oreilly\",\nlabel:\"\",value:0,nonInteraction:0},email:{category:\"Email Clicks\",action:\"Click\",label:\"\",value:0,nonInteraction:0},outbound_email:{category:\"Outbound Email Clicks\",action:\"Click\",label:\"\",value:0,nonInteraction:0},telephone:{category:\"Telephone Clicks\",action:\"Click\",label:\"\",value:0,nonInteraction:0},social:{category:\"Social Profiles\",action:\"Click\",label:\"\",value:0,nonInteraction:0}},mainDomain=document.location.hostname.match(\/(([^.\\\/]+\\.[^.\\\/]{2,3}\\.[^.\\\/]{2})|(([^.\\\/]+\\.)[^.\\\/]{2,4}))(\\\/.*)?$\/)[1];\nmainDomain=mainDomain.toLowerCase();1==isSubDomainTracker\u0026\u0026(mainDomain=document.location.hostname.replace(\"www.\",\"\").toLowerCase());var arr=document.getElementsByTagName(\"a\");\nfor(i=0;i\u003Carr.length;i++){var flag=0;if(!isExcluded(arr[i])){var mDownAtt=arr[i].getAttribute(\"onmousedown\"),doname=\"\",linkType=\"\",mailPattern=\/^mailto:[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}\/i,urlPattern=\/^(ftp|http|https):\\\/\\\/(\\w+:{0,1}\\w*@)?(\\S+)(:[0-9]+)?(\\\/|\\\/([\\w#!:.?+=\u0026%@!\\-\\\/]))?\/i,telPattern=\/^tel:(.*)([0-9]{3})\\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$\/i,internalDomain=\/(.*)(oreilly.com|safaribooksonline.com)(.*)\/i;if(mailPattern.test(arr[i].href)||urlPattern.test(arr[i].href)||telPattern.test(arr[i].href)){try{!urlPattern.test(arr[i].href)||\nmailPattern.test(arr[i].href)||telPattern.test(arr[i].href)?!mailPattern.test(arr[i].href)||telPattern.test(arr[i].href)||urlPattern.test(arr[i].href)?!telPattern.test(arr[i].href)||urlPattern.test(arr[i].href)||mailPattern.test(arr[i].href)||(doname=arr[i].href.toLowerCase(),linkType=\"tel\"):(doname=arr[i].href.toLowerCase().split(\"@\")[1],linkType=\"mail\"):(doname=arr[i].hostname.toLowerCase().replace(\"www.\",\"\"),linkType=\"url\")}catch(a){continue}if(null!=mDownAtt\u0026\u0026(mDownAtt=String(mDownAtt),-1\u003CmDownAtt.indexOf(\"dataLayer.push\")||\n-1\u003CmDownAtt.indexOf(\"('send'\")))continue;var condition=!1;if(condition=isSeparateDomainTracker?doname==mainDomain:-1!=doname.indexOf(mainDomain))\"mail\"===linkType?(eValues.email.label=arr[i].href.toLowerCase().match(\/[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}\/i),_tagLinks(arr[i],eValues.email.category,eValues.email.action,eValues.email.label,eValues.email.value,eValues.email.nonInteraction,mDownAtt)):\"url\"===linkType\u0026\u0026(\"\"==folders_to_track||_isInternalFolder(arr[i].href)?_isDownload(arr[i].href)\u0026\u0026\n(_setDownloadData(arr[i].href,doname),_tagLinks(arr[i],eValues.downloads.category,eValues.downloads.action,eValues.downloads.label,eValues.downloads.value,eValues.downloads.nonInteraction,mDownAtt)):_isDownload(arr[i].href)?(_setDownloadData(arr[i].href,doname),_tagLinks(arr[i],eValues.outbound_downloads.category,eValues.outbound_downloads.action,eValues.outbound_downloads.label,eValues.outbound_downloads.value,eValues.outbound_downloads.nonInteraction,mDownAtt)):internalDomain.test(arr[i].href)?\n(eValues.outbounds_oreilly.label=arr[i].href.replace(\"www.\",\"\").split(\"\/\/\")[1],_tagLinks(arr[i],eValues.outbounds_oreilly.category,eValues.outbounds_oreilly.action,eValues.outbounds_oreilly.label,eValues.outbounds_oreilly.value,eValues.outbounds_oreilly.nonInteraction,mDownAtt)):(eValues.outbounds.label=arr[i].href.toLowerCase().replace(\"www.\",\"\").split(\"\/\/\")[1],_tagLinks(arr[i],eValues.outbounds.category,eValues.outbounds.action,eValues.outbounds.label,eValues.outbounds.value,eValues.outbounds.nonInteraction,\nmDownAtt)));else for(var k=0;k\u003Cdomains_to_track.length;k++){var condition1=!1;condition1=isSeparateDomainTracker?doname==domains_to_track[k]:-1!=doname.indexOf(domains_to_track[k]);condition1?\"mail\"===linkType?(eValues.email.label=arr[i].href.toLowerCase().match(\/[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}\/i),_tagLinks(arr[i],eValues.email.category,eValues.email.action,eValues.email.label,eValues.email.value,eValues.email.nonInteraction,mDownAtt)):\"url\"===linkType\u0026\u0026(\"\"==folders_to_track||_isInternalFolder(arr[i].href)?\n_isDownload(arr[i].href)\u0026\u0026(_setDownloadData(arr[i].href,doname),_tagLinks(arr[i],eValues.downloads.category,eValues.downloads.action,eValues.downloads.label,eValues.downloads.value,eValues.downloads.nonInteraction,mDownAtt)):_isDownload(arr[i].href)?(_setDownloadData(arr[i].href,doname),_tagLinks(arr[i],eValues.outbound_downloads.category,eValues.outbound_downloads.action,eValues.outbound_downloads.label,eValues.outbound_downloads.value,eValues.outbound_downloads.nonInteraction,mDownAtt)):internalDomain.test(arr[i].href)?\n(eValues.outbounds_oreilly.label=arr[i].href.replace(\"www.\",\"\").split(\"\/\/\")[1],_tagLinks(arr[i],eValues.outbounds_oreilly.category,eValues.outbounds_oreilly.action,eValues.outbounds_oreilly.label,eValues.outbounds_oreilly.value,eValues.outbounds_oreilly.nonInteraction,mDownAtt)):(eValues.outbounds.label=arr[i].href.replace(\"www.\",\"\").split(\"\/\/\")[1],_tagLinks(arr[i],eValues.outbounds.category,eValues.outbounds.action,eValues.outbounds.label,eValues.outbounds.value,eValues.outbounds.nonInteraction,\nmDownAtt))):(flag++,flag==domains_to_track.length\u0026\u0026(\"mail\"===linkType\u0026\u0026(eValues.outbound_email.label=arr[i].href.toLowerCase().match(\/[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}\/),_tagLinks(arr[i],eValues.outbound_email.category,eValues.outbound_email.action,eValues.outbound_email.label,eValues.outbound_email.value,eValues.outbound_email.nonInteraction,mDownAtt)),\"tel\"===linkType\u0026\u0026(eValues.telephone.label=arr[i].href.toLowerCase().split(\"tel:\")[1],_tagLinks(arr[i],eValues.telephone.category,eValues.telephone.action,\neValues.telephone.label,eValues.telephone.value,eValues.telephone.nonInteraction,mDownAtt)),\"url\"===linkType\u0026\u0026(_isDownload(arr[i].href)?(_setDownloadData(arr[i].href,doname),_tagLinks(arr[i],eValues.outbound_downloads.category,eValues.outbound_downloads.action,eValues.outbound_downloads.label,eValues.outbound_downloads.value,eValues.outbound_downloads.nonInteraction,mDownAtt)):_isSocial(arr[i].href)?(eValues.social.label=arr[i].href.toLowerCase().replace(\"www.\",\"\").split(\"\/\/\")[1],eValues.social.action=\neValues.social.label.split(\".\")[0],_tagLinks(arr[i],eValues.social.category,eValues.social.action,eValues.social.label,eValues.social.value,eValues.social.nonInteraction,mDownAtt)):internalDomain.test(arr[i].href)?(eValues.outbounds_oreilly.label=arr[i].href.replace(\"www.\",\"\").split(\"\/\/\")[1],_tagLinks(arr[i],eValues.outbounds_oreilly.category,eValues.outbounds_oreilly.action,eValues.outbounds_oreilly.label,eValues.outbounds_oreilly.value,eValues.outbounds_oreilly.nonInteraction,mDownAtt)):(eValues.outbounds.label=\narr[i].href.toLowerCase().replace(\"www.\",\"\").split(\"\/\/\")[1],_tagLinks(arr[i],eValues.outbounds.category,eValues.outbounds.action,eValues.outbounds.label,eValues.outbounds.value,eValues.outbounds.nonInteraction,mDownAtt)))))}}}}function _isSocial(a){return\"\"!=socSites?null!=a.toLowerCase().replace(\/[+#]\/,\"\").match(new RegExp(\"^(.*)(\"+socSites.toLowerCase()+\")(.*)$\"))?!0:!1:!1}\nfunction _isInternalFolder(a){return\"\"!=folders_to_track?null!=a.toLowerCase().match(new RegExp(\"^(.*)(\"+folders_to_track+\")(.*)$\"))?!0:!1:!1}function _isDownload(a){for(var c=0,b=0;b\u003CextDoc.length;b++){var d=a.split(\".\");d=d[d.length-1].split(\/[#?\u0026?]\/);if(\".\"+d[0].toLowerCase()==extDoc[b])return!0;c++;if(c==extDoc.length)return!1}}\nfunction _setDownloadData(a,c){var b=a.toLowerCase().split(\".\");b=b[b.length-1].split(\/[#?\u0026?]\/);a=a.toLowerCase().split(c);a=a[1].split(\/[#?\u0026?]\/);eValues.downloads.action=eValues.outbound_downloads.action=b;eValues.downloads.label=eValues.outbound_downloads.label=a}\nfunction _tagLinks(a,c,b,d,g,e,f){isGTM?a.setAttribute(\"onmousedown\",(null!=f?f+\"; \":\"\")+\"dataLayer.push({'event': 'eventTracker', 'eventCat': '\"+c+\"', 'eventAct':'\"+b+\"', 'eventLbl': '\"+d+\"', 'eventVal': \"+g+\", 'nonInteraction': \"+e+\"});\"):(e=0==e?!1:!0,a.setAttribute(\"onmousedown\",(null!=f?f+\"; \":\"\")+\"ga('send', 'event', '\"+c+\"', '\"+b+\"', '\"+d+\"', \"+g+\", { nonInteraction: \"+e+\"});\"))}\nfunction isExcluded(a){var c=document.getElementsByTagName(\"footer\")[0];1\u003Cdocument.getElementsByTagName(\"footer\").length\u0026\u0026(c=document.getElementsByTagName(\"footer\")[document.getElementsByTagName(\"footer\").length-1]);for(var b=a.parentNode;null!=b;){if(b==c)return!0;b=b.parentNode}c=\/(.*)(conferences.oreilly.com|www.safaribooksonline.com|learning.oreilly.com|shop.oreilly.com)(.*)\/i;b=\/((.*)oreilly.com\\\/(learning|radar|idea)(.*))\/i;return c.test(a.href)\u0026\u0026b.test(document.location.href)\u0026\u0026jQuery\u0026\u0026(jQuery(a).parents(\".article-body\").length||\njQuery(a).parents(\".block-product\").length||jQuery(this).closest(\"[data-type \\x3d 'note']\").length)?!0:!1};\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":55
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript defer type=\"text\/gtmscript\"\u003E(function(){window.medalliaUserIdentifier=document.documentElement.dataset.userUuid;window.medalliaUserName=document.documentElement.dataset.username})();\u003C\/script\u003E\n\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/nebula-cdn.kampyle.com\/wu\/314849\/onsite\/embed.js\" async\u003E\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":61
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"\/\/static.criteo.net\/js\/ld\/ld.js\" async=\"true\"\u003E\u003C\/script\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Evar checkin=new Date,checkout=new Date;checkin.setDate((new Date).getDate()+10);checkout.setDate((new Date).getDate()+24);\nvar trialends=(1==(checkin.getMonth()+1).toString().length?\"0\"+(checkin.getMonth()+1):checkin.getMonth()+1)+\"\/\"+(1==checkin.getDate().toString().length?\"0\"+checkin.getDate():checkin.getDate())+\"\/\"+checkin.getFullYear(),trialends2=(1==(checkout.getMonth()+1).toString().length?\"0\"+(checkout.getMonth()+1):checkout.getMonth()+1)+\"\/\"+(1==checkout.getDate().toString().length?\"0\"+checkout.getDate():checkout.getDate())+\"\/\"+checkout.getFullYear();window.criteo_q=window.criteo_q||[];\nvar deviceType=\/iPad\/.test(navigator.userAgent)?\"t\":\/Mobile|iP(hone|od)|Android|BlackBerry|IEMobile|Silk\/.test(navigator.userAgent)?\"m\":\"d\";\nwindow.criteo_q.push({event:\"manualFlush\"},{event:\"setAccount\",account:47920},{event:\"setSiteType\",type:deviceType},{event:\"setEmail\",email:\"\"},{event:\"viewHome\"},{event:\"flushEvents\"},function(){setTimeout(function(){criteo_q.push({event:\"viewSearch\",din:trialends,dout:trialends2},{event:\"viewHome\"},{event:\"setData\",trialends:trialends},{event:\"flushEvents\"})},1E3)});\u003C\/script\u003E ",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":64
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"\/\/static.criteo.net\/js\/ld\/ld.js\" async=\"true\"\u003E\u003C\/script\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.criteo_q=window.criteo_q||[];var deviceType=\/iPad\/.test(navigator.userAgent)?\"t\":\/Mobile|iP(hone|od)|Android|BlackBerry|IEMobile|Silk\/.test(navigator.userAgent)?\"m\":\"d\";window.criteo_q.push({event:\"setAccount\",account:47920},{event:\"setSiteType\",type:deviceType},{event:\"setEmail\",email:\"##user_email##\"},{event:\"trackTransaction\",id:(new Date).getTime(),item:[{id:\"1\",price:\"##subscription_cost##\",quantity:1}]});\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":65
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"\/\/static.criteo.net\/js\/ld\/ld.js\" async=\"true\"\u003E\u003C\/script\u003E \u003Cscript type=\"text\/gtmscript\"\u003Ewindow.criteo_q=window.criteo_q||[];var deviceType=\/iPad\/.test(navigator.userAgent)?\"t\":\/Mobile|iP(hone|od)|Android|BlackBerry|IEMobile|Silk\/.test(navigator.userAgent)?\"m\":\"d\";window.criteo_q.push({event:\"setAccount\",account:47920},{event:\"setSiteType\",type:deviceType},{event:\"setEmail\",email:\"\"},{event:\"viewItem\",item:\"1\"});\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":70
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript defer type=\"text\/gtmscript\"\u003E(function(){window.medalliaUserIdentifier=document.documentElement.dataset.userUuid;window.medalliaUserName=document.documentElement.dataset.username})();\u003C\/script\u003E\n\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"https:\/\/nebula-cdn.kampyle.com\/wu\/314849\/onsite\/embed.js\" async\u003E\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":76
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Evar domains_to_include_regex=\/(.*)(conferences.oreilly.com|www.safaribooksonline.com|learning.oreilly.com|shop.oreilly.com)(.*)\/i;jQuery(\".block-product\").on(\"mousedown\",\"a\",function(){domains_to_include_regex.test(this.href)\u0026\u0026dataLayer.push({event:\"eventTracker\",eventCat:\"content promo\",eventAct:\"right sidebar\",eventLbl:this.href,eventVal:0})});\njQuery('[data-type\\x3d\"note\"]').on(\"mousedown\",\"a\",function(){domains_to_include_regex.test(this.href)\u0026\u0026dataLayer.push({event:\"eventTracker\",eventCat:\"content promo\",eventAct:\"editor note\",eventLbl:this.href,eventVal:0})});\njQuery(\".article-body\").on(\"mousedown\",\"a\",function(){!domains_to_include_regex.test(this.href)||jQuery(this).closest(\"[data-type \\x3d 'note']\").length||jQuery(this).parents(\".block-product\").length||dataLayer.push({event:\"eventTracker\",eventCat:\"content promo\",eventAct:\"body\",eventLbl:this.href,eventVal:0})});\u003C\/script\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":94
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":["template","\n\u003Cscript data-gtmsrc=\"https:\/\/w.soundcloud.com\/player\/api.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(){try{var t=function(e){var a,c,b,h,k,l,m,d,n=\"podcast\",f=0;var p=",["escape",["macro",39],8,16],";var g=SC.Widget(e);g.bind(SC.Widget.Events.READY,function(){g.bind(SC.Widget.Events.PLAY,function(){1E3\u003CDate.now()-f\u0026\u0026(a=\"Play\",q(n,a,p),f=Date.now())});g.bind(SC.Widget.Events.PLAY_PROGRESS,function(e){d=!1;c=Math.round(100*e.relativePosition);10!==c||b||(a=\"10%\",d=b=!0);25!==c||h||(a=\"25%\",d=h=!0);50!==c||k||(a=\"50%\",d=k=!0);75!==c||l||(a=\"75%\",d=l=!0);95!==c||m||(a=\"75%\",d=m=!0);d\u0026\u0026q(n,a,p)});g.bind(SC.Widget.Events.FINISH,\nfunction(){a=\"100%\";b=h=k=l=m=!1;q(n,a,p)})})},q=function(b,a,c){window.dataLayer.push({event:\"eventTracker\",eventCat:b,eventAct:a,eventLbl:c,eventVal:0,nonInteraction:0})},f,r=document.querySelectorAll('iframe[src*\\x3d\"api.soundcloud.com\"]');var b=0;for(f=r.length;b\u003Cf;b+=1)t(r[b])}catch(e){console.log(\"Error with SoundCloud API: \"+e.message)}})();\u003C\/script\u003E\n"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":96
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\n\u003Cscript type=\"text\/gtmscript\"\u003E!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=\"2.0\",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,\"script\",\"https:\/\/connect.facebook.net\/en_US\/fbevents.js\");fbq(\"init\",\"376595806465162\");fbq(\"track\",\"PageView\");\u003C\/script\u003E\n\u003Cnoscript\u003E\u003Cimg height=\"1\" width=\"1\" style=\"display:none\" src=\"https:\/\/www.facebook.com\/tr?id=376595806465162\u0026amp;ev=PageView\u0026amp;noscript=1\"\u003E\u003C\/noscript\u003E\n\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":163
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript\u003E(function(){if(null!==document.querySelector('iframe[title\\x3d\"fb:share_button Facebook Social Plugin\"]')\u0026\u0026void 0!==document.querySelector('iframe[title\\x3d\"fb:share_button Facebook Social Plugin\"]')){var a=!1;window.addEventListener(\"blur\",function(){a\u0026\u0026dataLayer.push({event:\"eventTracker\",eventCat:\"social\",eventAct:\"share\",eventLbl:\"facebook\",eventVal:0,nonInteraction:0})});document.querySelector('iframe[title\\x3d\"fb:share_button Facebook Social Plugin\"]').addEventListener(\"mouseover\",function(){window.focus();\na=!0});document.querySelector('iframe[title\\x3d\"fb:share_button Facebook Social Plugin\"]').addEventListener(\"mouseout\",function(){a=!1})}if(null!==document.querySelector(\"iframe.twitter-share-button\")\u0026\u0026void 0!==document.querySelector(\"iframe.twitter-share-button\")){var b=!1;window.addEventListener(\"blur\",function(){b\u0026\u0026dataLayer.push({event:\"eventTracker\",eventCat:\"social\",eventAct:\"share\",eventLbl:\"twitter\",eventVal:0,nonInteraction:0})});document.querySelector(\"iframe.twitter-share-button\").addEventListener(\"mouseover\",\nfunction(){window.focus();b=!0});document.querySelector(\"iframe.twitter-share-button\").addEventListener(\"mouseout\",function(){b=!1})}try{window.twttr=function(a,b,d){var c,e=a.getElementsByTagName(b)[0];if(!a.getElementById(d))return a=a.createElement(b),a.id=d,a.src=\"\/\/platform.twitter.com\/widgets.js\",e.parentNode.insertBefore(a,e),window.twttr||(c={_e:[],ready:function(a){c._e.push(a)}})}(document,\"script\",\"twitter-wjs\"),twttr.ready(function(a){a.events.bind(\"tweet\",trackTwitter)})}catch(c){}})();\nnull!==document.querySelector(\".IN-widget\")\u0026\u0026void 0!==document.querySelector(\".IN-widget\")\u0026\u0026document.querySelector(\".IN-widget\").addEventListener(\"click\",function(){dataLayer.push({event:\"eventTracker\",eventCat:\"social\",eventAct:\"share\",eventLbl:\"linkedin\",eventVal:0,nonInteraction:0})});\nfunction trackTwitter(a){a\u0026\u0026(a.target\u0026\u0026\"IFRAME\"==a.target.nodeName\u0026\u0026(opt_target=extractParamFromUri(a.target.src,\"url\")),dataLayer.push({event:\"eventTracker\",eventCat:\"social\",eventAct:\"share\",eventLbl:\"twitter\",eventVal:0,nonInteraction:0}))}function extractParamFromUri(a,b){if(a\u0026\u0026(b=new RegExp(\"[\\\\?\\x26#]\"+b+\"\\x3d([^\\x26#]*)\"),a=b.exec(a),null!=a))return unescape(a[1])};\u003C\/script\u003E",
      "vtp_supportDocumentWrite":true,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "vtp_usePostscribe":true,
      "tag_id":168
    },{
      "function":"__html",
      "vtp_html":"\n\u003Cscript type=\"text\/gtmscript\"\u003E!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=\"2.0\",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,\"script\",\"https:\/\/connect.facebook.net\/en_US\/fbevents.js\");fbq(\"init\",\"443792972845831\");fbq(\"set\",\"agent\",\"tmgoogletagmanager\",\"443792972845831\");fbq(\"track\",\"PageView\");\u003C\/script\u003E\n\u003Cnoscript\u003E\u003Cimg height=\"1\" width=\"1\" style=\"display:none\" src=\"https:\/\/www.facebook.com\/tr?id=443792972845831\u0026amp;ev=PageView\u0026amp;noscript=1\"\u003E\u003C\/noscript\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":202
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\n\u003Cscript type=\"text\/gtmscript\"\u003E!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=\"2.0\",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,\"script\",\"https:\/\/connect.facebook.net\/en_US\/fbevents.js\");fbq(\"init\",\"443792972845831\");fbq(\"track\",\"PageView\");\u003C\/script\u003E\n\u003Cnoscript\u003E\u003Cimg height=\"1\" width=\"1\" style=\"display:none\" src=\"https:\/\/www.facebook.com\/tr?id=443792972845831\u0026amp;ev=PageView\u0026amp;noscript=1\"\u003E\u003C\/noscript\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":203
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003E(function(){var a=4E3;window.setTimeout(function(){window.dataLayer.push({event:\"custom.historyChange\",custom:{historyChangeSource:",["escape",["macro",67],8,16],"}})},a)})();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":209
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E(function(){var a=4E3;window.setTimeout(function(){window.dataLayer.push({event:\"domReadyTimer\"})},a)})();\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":210
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Eadroll_adv_id=\"BOHFZPCX5ZAM5LXWJURNUB\";adroll_pix_id=\"3QFV44ZHVZG53BOB75QP3D\";\n(function(){var a=function(){if(document.readyState\u0026\u0026!\/loaded|complete\/.test(document.readyState))setTimeout(a,10);else if(window.__adroll_loaded){var b=document.createElement(\"script\"),c=\"https:\"==document.location.protocol?\"https:\/\/s.adroll.com\":\"http:\/\/a.adroll.com\";b.setAttribute(\"async\",\"true\");b.type=\"text\/javascript\";b.src=c+\"\/j\/roundtrip.js\";((document.getElementsByTagName(\"head\")||[null])[0]||document.getElementsByTagName(\"script\")[0].parentNode).appendChild(b)}else __adroll_loaded=!0,setTimeout(a,\n50)};window.addEventListener?window.addEventListener(\"load\",a,!1):window.attachEvent(\"onload\",a)})();\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":260
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003Ewindow._pp=window._pp||[];if(\"",["escape",["macro",2],7],"\"==\"\/confirmation\/nnv\/\"\u0026\u0026\"",["escape",["macro",78],7],"\"==\"https:\/\/learning.oreilly.com\/register\/\")_pp.targetUrl=\"\/confirm\/trial\";else if(\"",["escape",["macro",2],7],"\"==\"\/confirmation\/nv\/\"\u0026\u0026\"",["escape",["macro",78],7],"\"==\"https:\/\/learning.oreilly.com\/subscribe\/\")_pp.targetUrl=\"\/confirm\/paid\";else if(\"",["escape",["macro",2],7],"\"==\"\/confirmation\/nnv\/\"\u0026\u0026\"",["escape",["macro",78],7],"\"==\"https:\/\/learning.oreilly.com\/signup\/\")_pp.targetUrl=\"\/confirm\/paid\";_pp.siteId=\"2508\";\n_pp.siteUId=\"",["escape",["macro",12],7],"\";_pp.orderValue=\"",["escape",["macro",79],7],"\";_pp.orderId=\"",["escape",["macro",80],7],"\";(function(){var ppjs=document.createElement(\"script\");ppjs.type=\"text\/javascript\";ppjs.async=true;ppjs.src=(\"https:\"==document.location.protocol?\"https:\":\"http:\")+\"\/\/cdn.pbbl.co\/r\/\"+_pp.siteId+\".js\";var s=document.getElementsByTagName(\"script\")[0];s.parentNode.insertBefore(ppjs,s)})();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":269
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\n\u003Cscript type=\"text\/gtmscript\"\u003E!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=\"2.0\",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,\"script\",\"https:\/\/connect.facebook.net\/en_US\/fbevents.js\");fbq(\"init\",\"1732687426968531\");fbq(\"track\",\"PageView\");\u003C\/script\u003E\n\u003Cnoscript\u003E\u003Cimg height=\"1\" width=\"1\" style=\"display:none\" src=\"https:\/\/www.facebook.com\/tr?id=1732687426968531\u0026amp;ev=PageView\u0026amp;noscript=1\"\u003E\u003C\/noscript\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":287
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Efunction forceInputUppercase(a){var b=a.target.selectionStart,c=a.target.selectionEnd;a.target.value=a.target.value.toUpperCase();a.target.setSelectionRange(b,c)}void 0!=document.getElementById(\"id_promotion\")\u0026\u0026null!=document.getElementById(\"id_promotion\")\u0026\u0026document.getElementById(\"id_promotion\").addEventListener(\"keyup\",forceInputUppercase,!1);\nvoid 0!=document.getElementsByName(\"promotionCode\")[0]\u0026\u0026null!=document.getElementsByName(\"promotionCode\")[0]\u0026\u0026document.getElementsByName(\"promotionCode\")[0].addEventListener(\"keyup\",forceInputUppercase,!1);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":295
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Evar nonwExpandable=document.querySelectorAll(\".orm-ff-NavigationSubnav-headerListItem a, .orm-ff-NavigationView-headerListItem a\");nonwExpandable.forEach(function(a,b){b+1!=nonwExpandable.length?a.addEventListener(\"click\",function(){dataLayer.push({event:\"eventTracker\",eventCat:\"global nav\",eventAct:\"navigation\",eventLbl:a.childNodes[1].textContent})}):b+1==nonwExpandable.length\u0026\u0026a.addEventListener(\"click\",function(){dataLayer.push({event:\"eventTracker\",eventCat:\"user login\",eventAct:\"logout\",eventLbl:\"global nav | unified\"})})});\nvar nonwExpandableFo=document.querySelectorAll(\".drop-content li:not(.flyout-parent) a\");\nnonwExpandableFo.forEach(function(a,b){\"drop-content\"==a.parentNode.parentNode.parentNode.className\u0026\u0026b+1!=nonwExpandableFo.length?a.addEventListener(\"click\",function(){dataLayer.push({event:\"eventTracker\",eventCat:\"global nav\",eventAct:\"navigation\",eventLbl:a.childNodes[1].textContent})}):\"drop-content\"==a.parentNode.parentNode.parentNode.className\u0026\u0026b+1==nonwExpandableFo.length\u0026\u0026a.addEventListener(\"click\",function(){dataLayer.push({event:\"eventTracker\",eventCat:\"user login\",eventAct:\"logout\",eventLbl:\"global nav | unified\"})})});\nvar expandable=document.querySelectorAll(\".orm-ff-NavigationSubnav-toggleControls a, .orm-ff-NavigationView-toggleControls a\");expandable.forEach(function(a){a.addEventListener(\"click\",function(){dataLayer.push({event:\"eventTracker\",eventCat:\"global nav\",eventAct:\"navigation\",eventLbl:a.parentNode.parentNode.parentNode.querySelectorAll(\".orm-Button-btnContentWrap span\")[0].childNodes[1].textContent+\" | \"+a.textContent})})});var flyoutLinks=document.querySelectorAll(\".flyout a\");\nflyoutLinks.forEach(function(a){a.addEventListener(\"click\",function(){dataLayer.push({event:\"eventTracker\",eventCat:\"global nav\",eventAct:\"navigation\",eventLbl:a.closest(\"li.flyout-parent\").getElementsByTagName(\"a\")[0].textContent+\" | \"+a.textContent})})});\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":724
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003E\"undefined\"!==typeof kWidget\u0026\u0026kWidget.addReadyCallback(function(c){var b=document.getElementById(c);b.kBind(\"playerPlayEnd.pe\",function(){dataLayer.push({event:\"eventTracker\",eventCat:\"video plays\",eventAct:\"End\",eventLbl:",["escape",["macro",39],8,16],",eventVal:0,nonInteraction:0});b.kUnbind(\".pe\")});var d=!1,e=!1,f=!1,g=!1,h=!1;b.addJsListener(\"playerUpdatePlayhead\",function(){var a=b.evaluate(\"{video.player.currentTime}\"),c=b.evaluate(\"{mediaProxy.entry.duration}\");a=100*parseFloat(a\/c);0\u003Ca\u0026\u0026!d\u0026\u0026(d=!0,dataLayer.push({event:\"eventTracker\",\neventCat:\"video plays\",eventAct:\"play\",eventLbl:",["escape",["macro",39],8,16],",eventVal:0,nonInteraction:0}));25\u003Ca\u0026\u0026!e\u0026\u0026(e=!0,dataLayer.push({event:\"eventTracker\",eventCat:\"video plays\",eventAct:\"25%\",eventLbl:",["escape",["macro",39],8,16],",eventVal:0,nonInteraction:0}));50\u003Ca\u0026\u0026!f\u0026\u0026(f=!0,dataLayer.push({event:\"eventTracker\",eventCat:\"video plays\",eventAct:\"50%\",eventLbl:",["escape",["macro",39],8,16],",eventVal:0,nonInteraction:0}));75\u003Ca\u0026\u0026!g\u0026\u0026(g=!0,dataLayer.push({event:\"eventTracker\",eventCat:\"video plays\",eventAct:\"75%\",eventLbl:",["escape",["macro",39],8,16],",\neventVal:0,nonInteraction:0}));95\u003Ca\u0026\u0026!h\u0026\u0026(h=!0,dataLayer.push({event:\"eventTracker\",eventCat:\"video plays\",eventAct:\"95%\",eventLbl:",["escape",["macro",39],8,16],",eventVal:0,nonInteraction:0}));b.kUnbind(\".pp\")})});\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":744
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E(function(){var a=4E3;window.setTimeout(function(){window.dataLayer.push({event:\"windowReadyTimer\"})},a)})();\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":746
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003EdataLayer.push({\"ld.experiment\":void 0,\"ld.variation\":void 0});\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":1213
    }],
  "predicates":[{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"\\\/enterprise\\\/how\\-learning\\-accelerates\\-change\\-download\\\/|\\\/enterprise\\\/one\\-size\\-fits\\-all\\-training\\-doesnt\\-work\\-download\\\/|\\\/enterprise\\\/six\\-ways\\-leaders\\-can\\-navigate\\-change\\-download\\\/"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"gtm.js"
    },{
      "function":"_re",
      "arg0":["macro",2],
      "arg1":"ent.*_confirm\\.html"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"oreilly.com"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"get.oreilly.com"
    },{
      "function":"_cn",
      "arg0":["macro",4],
      "arg1":"true"
    },{
      "function":"_gt",
      "arg0":["macro",5],
      "arg1":"0.0"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"conferences.oreilly.com\/velocity"
    },{
      "function":"_cn",
      "arg0":["macro",6],
      "arg1":"Start your free trial"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"gtm.click"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"(.*)conferences.oreilly.com(.*)|(.*)ai.oreilly.com.cn(.*)",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",7],
      "arg1":"false"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"(.*)oreilly.com\\\/blended-courses.*"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"eventTracker"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":".*oreilly.com\\\/blended-courses.*"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"VPTracker"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"\\\/account\\\/insights"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"(.*)www.oreilly.com(\\\/?$|\\\/about\\\/approach.html|\\\/sign-in\\.html|(.*\\\/)*free\\\/(.*)*|\\\/ideas(\\\/.*)*|\\\/radar(\\\/.*)*|\\\/content(\\\/.*)*|\\\/learning(\\\/.*)*|\\\/topics(\\\/.*)*|\\\/people(\\\/.*)*|\\\/feed\\\/four\\-short\\-links\\\/?|\\\/all)",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"(.*)get.oreilly.com(.*)",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"(.*)www.oreilly.com\\\/online-learning(\\\/?$|\\\/enterprise\\.html|\\\/teams\\.html|\\\/individuals\\.html|\\\/government\\.html|\\\/academic\\.html|\\\/pricing\\.html|\\\/try-now\\.html)",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",32],
      "arg1":"(.*)oreilly.com|www.safaribooksonline.com|learning.oreilly.review|oreilly.review",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",32],
      "arg1":"conferences.oreilly.com",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"(.*)www\\.oreilly\\.com\\\/blended-courses.*",
      "ignore_case":true
    },{
      "function":"_cn",
      "arg0":["macro",23],
      "arg1":"your oreilly|hover"
    },{
      "function":"_re",
      "arg0":["macro",32],
      "arg1":"(.*)oreilly.com|www.safaribooksonline.com|learning.oreilly.review|oreilly.review|nc\\-proxy.binderhub\\-prod.gcp.oreilly.com",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"(.*)www\\.oreilly\\.com\\\/blended-courses.*|learning\\.oreilly\\.(review|com)\\\/(case-studies|learning-paths|videos|resource-centers|certifications).*|www\\.oreilly\\.(review|com)\\\/(resource-centers).*",
      "ignore_case":true
    },{
      "function":"_cn",
      "arg0":["macro",67],
      "arg1":"pushState"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"learning\\.oreilly\\.(review|com)\\\/(resource-centers|case-studies|learning-paths|videos|certifications).*|www\\.oreilly\\.(review|com)\\\/(resource-centers).*",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"gtm.historyChange"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"learning\\.oreilly\\.(review|com)\\\/(case-studies|learning-paths|videos|resource-centers|certifications).*|www\\.oreilly\\.(review|com)\\\/(resource-centers).*",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"domReadyTimer"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"custom.historyChange"
    },{
      "function":"_cn",
      "arg0":["macro",28],
      "arg1":"video"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"gtm.dom"
    },{
      "function":"_re",
      "arg0":["macro",28],
      "arg1":"article|podcast",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",28],
      "arg1":"jupyter notebook"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"gtm.scrollDepth"
    },{
      "function":"_re",
      "arg0":["macro",68],
      "arg1":"(^$|((^|,)1669222_204($|,)))"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"oreilly.com\/skills\/"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"gtm.video"
    },{
      "function":"_re",
      "arg0":["macro",68],
      "arg1":"(^$|((^|,)1669222_203($|,)))"
    },{
      "function":"_re",
      "arg0":["macro",21],
      "arg1":"learning platform sign up",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"updatedEcommerce"
    },{
      "function":"_eq",
      "arg0":["macro",73],
      "arg1":"0"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"VWO"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"((.*)(oreilly.com\/(feed\/four\\-short\\-links|all)(\/?))$)|((.*)oreilly.com\/(ideas|learning|topics|people)(\\\/(.*)|$|\\?(.*)))",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"gtm.load"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"conferences.oreilly.com"
    },{
      "function":"_cn",
      "arg0":["macro",77],
      "arg1":"true"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"(.*)conferences.oreilly.com(.*)|(.*)ai.oreilly.com.cn(.*)|(.*)www.oreilly.com(.*)|(.*)shop.oreilly.com(.*)"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"(.*)oreilly.com\\\/(learning|radar|ideas)(\\\/(.*)|\\?(.*))",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"(.*)learning.oreilly.review(.*)|www.oreilly.review\\\/register\\\/"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"safaribooksonline.com\/subscribe\/"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"\/signup\/"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"(.*)oreilly.com\\\/(learning|ideas|radar|content)(\\\/(.*)|\\?(.*))",
      "ignore_case":true
    },{
      "function":"_cn",
      "arg0":["macro",28],
      "arg1":"podcast"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":".*www.oreilly.com.*data-science.*"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"get.oreilly.com\/ind_introduction-to-machine-learning-interpretability.html"
    },{
      "function":"_re",
      "arg0":["macro",0],
      "arg1":"(.*)learning.oreilly.com(.*)|www.oreilly.com\\\/register\\\/"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"gtm.elementVisibility"
    },{
      "function":"_re",
      "arg0":["macro",68],
      "arg1":"(^$|((^|,)1669222_1064($|,)))"
    },{
      "function":"_re",
      "arg0":["macro",68],
      "arg1":"(^$|((^|,)1669222_1106($|,)))"
    }],
  "rules":[
    [["if",0,1],["add",2,13]],
    [["if",1,2],["add",2,13]],
    [["if",1],["add",3,8,22,29,44,53,54,31,32,34,35,36,37,38,39]],
    [["if",1,3],["add",4]],
    [["if",1,4],["add",4]],
    [["if",1,5,6],["add",5,40,42,46]],
    [["if",1],["unless",7],["add",6,18]],
    [["if",8,9],["add",7,9,19,45,59]],
    [["if",1,10,11],["add",10]],
    [["if",1,12],["add",10]],
    [["if",10,13],["add",11]],
    [["if",13,14],["add",11]],
    [["if",10,15],["add",12]],
    [["if",1,16],["add",14]],
    [["if",15,17],["add",15]],
    [["if",15,18],["add",15]],
    [["if",15,19],["add",15]],
    [["if",13,20],["unless",21,22],["add",16]],
    [["if",1,24],["unless",21,25],["add",17]],
    [["if",26,28],["unless",27],["add",17]],
    [["if",29,30],["add",17]],
    [["if",29,31],["add",17,62]],
    [["if",32,33],["add",20]],
    [["if",34,36,37],["unless",35],["add",21]],
    [["if",1,38],["add",23,51]],
    [["if",32,39,40],["add",24]],
    [["if",13,41],["add",25]],
    [["if",42],["add",26]],
    [["if",44],["unless",43],["add",27]],
    [["if",13,23],["add",28],["block",16]],
    [["if",1,45],["add",30]],
    [["if",46],["add",33,52,60,61]],
    [["if",1],["unless",47],["add",41]],
    [["if",1,48],["add",0,1]],
    [["if",33,49],["unless",50],["add",43]],
    [["if",33,51],["add",44,48,58]],
    [["if",1,52],["add",47]],
    [["if",1,53],["add",47]],
    [["if",46,54],["add",49]],
    [["if",33,55],["add",50]],
    [["if",1,56],["add",51]],
    [["if",26,28,29],["add",55]],
    [["if",29,33],["add",56]],
    [["if",1,57],["add",57]],
    [["if",1,58],["add",58]],
    [["if",59,60],["add",60]],
    [["if",59,61],["add",61]],
    [["if",32,46],["add",62,63]]]
},
"runtime":[]




};
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var ca,da="function"==typeof Object.create?Object.create:function(a){var b=function(){};b.prototype=a;return new b},fa;if("function"==typeof Object.setPrototypeOf)fa=Object.setPrototypeOf;else{var ha;a:{var ia={Hf:!0},ja={};try{ja.__proto__=ia;ha=ja.Hf;break a}catch(a){}ha=!1}fa=ha?function(a,b){a.__proto__=b;if(a.__proto__!==b)throw new TypeError(a+" is not extensible");return a}:null}var ka=fa,la=this||self,ma=/^[\w+/_-]+[=]{0,2}$/,na=null;var pa=function(){},qa=function(a){return"function"==typeof a},g=function(a){return"string"==typeof a},ra=function(a){return"number"==typeof a&&!isNaN(a)},sa=function(a){return"[object Array]"==Object.prototype.toString.call(Object(a))},n=function(a,b){if(Array.prototype.indexOf){var c=a.indexOf(b);return"number"==typeof c?c:-1}for(var d=0;d<a.length;d++)if(a[d]===b)return d;return-1},wa=function(a,b){if(a&&sa(a))for(var c=0;c<a.length;c++)if(a[c]&&b(a[c]))return a[c]},xa=function(a,b){if(!ra(a)||
!ra(b)||a>b)a=0,b=2147483647;return Math.floor(Math.random()*(b-a+1)+a)},za=function(a,b){for(var c=new ya,d=0;d<a.length;d++)c.set(a[d],!0);for(var e=0;e<b.length;e++)if(c.get(b[e]))return!0;return!1},Aa=function(a,b){for(var c in a)Object.prototype.hasOwnProperty.call(a,c)&&b(c,a[c])},Ba=function(a){return Math.round(Number(a))||0},Ca=function(a){return"false"==String(a).toLowerCase()?!1:!!a},Da=function(a){var b=[];if(sa(a))for(var c=0;c<a.length;c++)b.push(String(a[c]));return b},Fa=function(a){return a?
a.replace(/^\s+|\s+$/g,""):""},Ga=function(){return(new Date).getTime()},ya=function(){this.prefix="gtm.";this.values={}};ya.prototype.set=function(a,b){this.values[this.prefix+a]=b};ya.prototype.get=function(a){return this.values[this.prefix+a]};
var Ha=function(a,b,c){return a&&a.hasOwnProperty(b)?a[b]:c},Ia=function(a){var b=!1;return function(){if(!b)try{a()}catch(c){}b=!0}},Ja=function(a,b){for(var c in b)b.hasOwnProperty(c)&&(a[c]=b[c])},Ka=function(a){for(var b in a)if(a.hasOwnProperty(b))return!0;return!1},La=function(a,b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]),c.push.apply(c,b[a[d]]||[]);return c},Ma=function(a,b){for(var c={},d=c,e=a.split("."),f=0;f<e.length-1;f++)d=d[e[f]]={};d[e[e.length-1]]=b;return c},Na=function(a){var b=
[];Aa(a,function(c,d){10>c.length&&d&&b.push(c)});return b.join(",")};/*
 jQuery v1.9.1 (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license. */
var Oa=/\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,Pa=function(a){if(null==a)return String(a);var b=Oa.exec(Object.prototype.toString.call(Object(a)));return b?b[1].toLowerCase():"object"},Qa=function(a,b){return Object.prototype.hasOwnProperty.call(Object(a),b)},Ra=function(a){if(!a||"object"!=Pa(a)||a.nodeType||a==a.window)return!1;try{if(a.constructor&&!Qa(a,"constructor")&&!Qa(a.constructor.prototype,"isPrototypeOf"))return!1}catch(c){return!1}for(var b in a);return void 0===
b||Qa(a,b)},C=function(a,b){var c=b||("array"==Pa(a)?[]:{}),d;for(d in a)if(Qa(a,d)){var e=a[d];"array"==Pa(e)?("array"!=Pa(c[d])&&(c[d]=[]),c[d]=C(e,c[d])):Ra(e)?(Ra(c[d])||(c[d]={}),c[d]=C(e,c[d])):c[d]=e}return c};
var Sa=[],Ta={"\x00":"&#0;",'"':"&quot;","&":"&amp;","'":"&#39;","<":"&lt;",">":"&gt;","\t":"&#9;","\n":"&#10;","\x0B":"&#11;","\f":"&#12;","\r":"&#13;"," ":"&#32;","-":"&#45;","/":"&#47;","=":"&#61;","`":"&#96;","\u0085":"&#133;","\u00a0":"&#160;","\u2028":"&#8232;","\u2029":"&#8233;"},Ua=function(a){return Ta[a]},Va=/[\x00\x22\x26\x27\x3c\x3e]/g;var Za=/[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\\\x85\u2028\u2029]/g,$a={"\x00":"\\x00","\b":"\\x08","\t":"\\t","\n":"\\n","\x0B":"\\x0b",
"\f":"\\f","\r":"\\r",'"':"\\x22","&":"\\x26","'":"\\x27","/":"\\/","<":"\\x3c","=":"\\x3d",">":"\\x3e","\\":"\\\\","\u0085":"\\x85","\u2028":"\\u2028","\u2029":"\\u2029",$:"\\x24","(":"\\x28",")":"\\x29","*":"\\x2a","+":"\\x2b",",":"\\x2c","-":"\\x2d",".":"\\x2e",":":"\\x3a","?":"\\x3f","[":"\\x5b","]":"\\x5d","^":"\\x5e","{":"\\x7b","|":"\\x7c","}":"\\x7d"},db=function(a){return $a[a]};Sa[7]=function(a){return String(a).replace(Za,db)};
Sa[8]=function(a){if(null==a)return" null ";switch(typeof a){case "boolean":case "number":return" "+a+" ";default:return"'"+String(String(a)).replace(Za,db)+"'"}};var jb=/['()]/g,kb=function(a){return"%"+a.charCodeAt(0).toString(16)};Sa[12]=function(a){var b=
encodeURIComponent(String(a));jb.lastIndex=0;return jb.test(b)?b.replace(jb,kb):b};var lb=/[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,mb={"\x00":"%00","\u0001":"%01","\u0002":"%02","\u0003":"%03","\u0004":"%04","\u0005":"%05","\u0006":"%06","\u0007":"%07","\b":"%08","\t":"%09","\n":"%0A","\x0B":"%0B","\f":"%0C","\r":"%0D","\u000e":"%0E","\u000f":"%0F","\u0010":"%10",
"\u0011":"%11","\u0012":"%12","\u0013":"%13","\u0014":"%14","\u0015":"%15","\u0016":"%16","\u0017":"%17","\u0018":"%18","\u0019":"%19","\u001a":"%1A","\u001b":"%1B","\u001c":"%1C","\u001d":"%1D","\u001e":"%1E","\u001f":"%1F"," ":"%20",'"':"%22","'":"%27","(":"%28",")":"%29","<":"%3C",">":"%3E","\\":"%5C","{":"%7B","}":"%7D","\u007f":"%7F","\u0085":"%C2%85","\u00a0":"%C2%A0","\u2028":"%E2%80%A8","\u2029":"%E2%80%A9","\uff01":"%EF%BC%81","\uff03":"%EF%BC%83","\uff04":"%EF%BC%84","\uff06":"%EF%BC%86",
"\uff07":"%EF%BC%87","\uff08":"%EF%BC%88","\uff09":"%EF%BC%89","\uff0a":"%EF%BC%8A","\uff0b":"%EF%BC%8B","\uff0c":"%EF%BC%8C","\uff0f":"%EF%BC%8F","\uff1a":"%EF%BC%9A","\uff1b":"%EF%BC%9B","\uff1d":"%EF%BC%9D","\uff1f":"%EF%BC%9F","\uff20":"%EF%BC%A0","\uff3b":"%EF%BC%BB","\uff3d":"%EF%BC%BD"},ob=function(a){return mb[a]};Sa[16]=function(a){return a};var qb;
var rb=[],sb=[],tb=[],ub=[],vb=[],wb={},xb,yb,Ab,Bb=function(a,b){var c={};c["function"]="__"+a;for(var d in b)b.hasOwnProperty(d)&&(c["vtp_"+d]=b[d]);return c},Cb=function(a,b){var c=a["function"];if(!c)throw Error("Error: No function name given for function call.");var d=wb[c],e={},f;for(f in a)a.hasOwnProperty(f)&&0===f.indexOf("vtp_")&&(e[void 0!==d?f:f.substr(4)]=a[f]);return void 0!==d?d(e):qb(c,e,b)},Eb=function(a,b,c){c=c||[];var d={},e;for(e in a)a.hasOwnProperty(e)&&(d[e]=Db(a[e],b,c));
return d},Fb=function(a){var b=a["function"];if(!b)throw"Error: No function name given for function call.";var c=wb[b];return c?c.priorityOverride||0:0},Db=function(a,b,c){if(sa(a)){var d;switch(a[0]){case "function_id":return a[1];case "list":d=[];for(var e=1;e<a.length;e++)d.push(Db(a[e],b,c));return d;case "macro":var f=a[1];if(c[f])return;var h=rb[f];if(!h||b.Vc(h))return;c[f]=!0;try{var k=Eb(h,b,c);k.vtp_gtmEventId=b.id;d=Cb(k,b);Ab&&(d=Ab.fg(d,k))}catch(x){b.De&&b.De(x,Number(f)),d=!1}c[f]=
!1;return d;case "map":d={};for(var l=1;l<a.length;l+=2)d[Db(a[l],b,c)]=Db(a[l+1],b,c);return d;case "template":d=[];for(var m=!1,q=1;q<a.length;q++){var r=Db(a[q],b,c);yb&&(m=m||r===yb.Gb);d.push(r)}return yb&&m?yb.ig(d):d.join("");case "escape":d=Db(a[1],b,c);if(yb&&sa(a[1])&&"macro"===a[1][0]&&yb.Ig(a))return yb.$g(d);d=String(d);for(var u=2;u<a.length;u++)Sa[a[u]]&&(d=Sa[a[u]](d));return d;case "tag":var p=a[1];if(!ub[p])throw Error("Unable to resolve tag reference "+p+".");return d={pe:a[2],
index:p};case "zb":var t={arg0:a[2],arg1:a[3],ignore_case:a[5]};t["function"]=a[1];var v=Gb(t,b,c),w=!!a[4];return w||2!==v?w!==(1===v):null;default:throw Error("Attempting to expand unknown Value type: "+a[0]+".");}}return a},Gb=function(a,b,c){try{return xb(Eb(a,b,c))}catch(d){JSON.stringify(a)}return 2};var Hb=function(){var a=function(b){return{toString:function(){return b}}};return{yd:a("convert_case_to"),zd:a("convert_false_to"),Ad:a("convert_null_to"),Bd:a("convert_true_to"),Cd:a("convert_undefined_to"),Hh:a("debug_mode_metadata"),va:a("function"),ff:a("instance_name"),lf:a("live_only"),pf:a("malware_disabled"),qf:a("metadata"),Ih:a("original_vendor_template_id"),uf:a("once_per_event"),Jd:a("once_per_load"),Rd:a("setup_tags"),Td:a("tag_id"),Ud:a("teardown_tags")}}();var Ib=null,Lb=function(a){function b(r){for(var u=0;u<r.length;u++)d[r[u]]=!0}var c=[],d=[];Ib=Jb(a);for(var e=0;e<sb.length;e++){var f=sb[e],h=Kb(f);if(h){for(var k=f.add||[],l=0;l<k.length;l++)c[k[l]]=!0;b(f.block||[])}else null===h&&b(f.block||[])}for(var m=[],q=0;q<ub.length;q++)c[q]&&!d[q]&&(m[q]=!0);return m},Kb=function(a){for(var b=a["if"]||[],c=0;c<b.length;c++){var d=Ib(b[c]);if(0===d)return!1;if(2===d)return null}for(var e=a.unless||[],f=0;f<e.length;f++){var h=Ib(e[f]);if(2===h)return null;
if(1===h)return!1}return!0},Jb=function(a){var b=[];return function(c){void 0===b[c]&&(b[c]=Gb(tb[c],a));return b[c]}};/*
 Copyright (c) 2014 Derek Brans, MIT license https://github.com/krux/postscribe/blob/master/LICENSE. Portions derived from simplehtmlparser, which is licensed under the Apache License, Version 2.0 */

var ec,fc=function(){};(function(){function a(k,l){k=k||"";l=l||{};for(var m in b)b.hasOwnProperty(m)&&(l.Uf&&(l["fix_"+m]=!0),l.se=l.se||l["fix_"+m]);var q={comment:/^\x3c!--/,endTag:/^<\//,atomicTag:/^<\s*(script|style|noscript|iframe|textarea)[\s\/>]/i,startTag:/^</,chars:/^[^<]/},r={comment:function(){var p=k.indexOf("--\x3e");if(0<=p)return{content:k.substr(4,p),length:p+3}},endTag:function(){var p=k.match(d);if(p)return{tagName:p[1],length:p[0].length}},atomicTag:function(){var p=r.startTag();
if(p){var t=k.slice(p.length);if(t.match(new RegExp("</\\s*"+p.tagName+"\\s*>","i"))){var v=t.match(new RegExp("([\\s\\S]*?)</\\s*"+p.tagName+"\\s*>","i"));if(v)return{tagName:p.tagName,P:p.P,content:v[1],length:v[0].length+p.length}}}},startTag:function(){var p=k.match(c);if(p){var t={};p[2].replace(e,function(v,w,x,y,B){var z=x||y||B||f.test(w)&&w||null,A=document.createElement("div");A.innerHTML=z;t[w]=A.textContent||A.innerText||z});return{tagName:p[1],P:t,zb:!!p[3],length:p[0].length}}},chars:function(){var p=
k.indexOf("<");return{length:0<=p?p:k.length}}},u=function(){for(var p in q)if(q[p].test(k)){var t=r[p]();return t?(t.type=t.type||p,t.text=k.substr(0,t.length),k=k.slice(t.length),t):null}};l.se&&function(){var p=/^(AREA|BASE|BASEFONT|BR|COL|FRAME|HR|IMG|INPUT|ISINDEX|LINK|META|PARAM|EMBED)$/i,t=/^(COLGROUP|DD|DT|LI|OPTIONS|P|TD|TFOOT|TH|THEAD|TR)$/i,v=[];v.Be=function(){return this[this.length-1]};v.Xc=function(A){var F=this.Be();return F&&F.tagName&&F.tagName.toUpperCase()===A.toUpperCase()};v.eg=
function(A){for(var F=0,G;G=this[F];F++)if(G.tagName===A)return!0;return!1};var w=function(A){A&&"startTag"===A.type&&(A.zb=p.test(A.tagName)||A.zb);return A},x=u,y=function(){k="</"+v.pop().tagName+">"+k},B={startTag:function(A){var F=A.tagName;"TR"===F.toUpperCase()&&v.Xc("TABLE")?(k="<TBODY>"+k,z()):l.Rh&&t.test(F)&&v.eg(F)?v.Xc(F)?y():(k="</"+A.tagName+">"+k,z()):A.zb||v.push(A)},endTag:function(A){v.Be()?l.rg&&!v.Xc(A.tagName)?y():v.pop():l.rg&&(x(),z())}},z=function(){var A=k,F=w(x());k=A;if(F&&
B[F.type])B[F.type](F)};u=function(){z();return w(x())}}();return{append:function(p){k+=p},hh:u,Yh:function(p){for(var t;(t=u())&&(!p[t.type]||!1!==p[t.type](t)););},clear:function(){var p=k;k="";return p},Zh:function(){return k},stack:[]}}var b=function(){var k={},l=this.document.createElement("div");l.innerHTML="<P><I></P></I>";k.ci="<P><I></P></I>"!==l.innerHTML;l.innerHTML="<P><i><P></P></i></P>";k.bi=2===l.childNodes.length;return k}(),c=/^<([\-A-Za-z0-9_]+)((?:\s+[\w\-]+(?:\s*=?\s*(?:(?:"[^"]*")|(?:'[^']*')|[^>\s]+))?)*)\s*(\/?)>/,
d=/^<\/([\-A-Za-z0-9_]+)[^>]*>/,e=/([\-A-Za-z0-9_]+)(?:\s*=\s*(?:(?:"((?:\\.|[^"])*)")|(?:'((?:\\.|[^'])*)')|([^>\s]+)))?/g,f=/^(checked|compact|declare|defer|disabled|ismap|multiple|nohref|noresize|noshade|nowrap|readonly|selected)$/i;a.H=b;a.J=function(k){var l={comment:function(m){return"<--"+m.content+"--\x3e"},endTag:function(m){return"</"+m.tagName+">"},atomicTag:function(m){return l.startTag(m)+m.content+l.endTag(m)},startTag:function(m){var q="<"+m.tagName,r;for(r in m.P){var u=m.P[r];q+=
" "+r+'="'+(u?u.replace(/(^|[^\\])"/g,'$1\\"'):"")+'"'}return q+(m.zb?"/>":">")},chars:function(m){return m.text}};return l[k.type](k)};a.o=function(k){var l={},m;for(m in k){var q=k[m];l[m]=q&&q.replace(/(^|[^\\])"/g,'$1\\"')}return l};for(var h in b)a.h=a.h||!b[h]&&h;ec=a})();(function(){function a(){}function b(r){return void 0!==r&&null!==r}function c(r,u,p){var t,v=r&&r.length||0;for(t=0;t<v;t++)u.call(p,r[t],t)}function d(r,u,p){for(var t in r)r.hasOwnProperty(t)&&u.call(p,t,r[t])}function e(r,
u){d(u,function(p,t){r[p]=t});return r}function f(r,u){r=r||{};d(u,function(p,t){b(r[p])||(r[p]=t)});return r}function h(r){try{return m.call(r)}catch(p){var u=[];c(r,function(t){u.push(t)});return u}}var k={Lf:a,Mf:a,Nf:a,Of:a,Vf:a,Wf:function(r){return r},done:a,error:function(r){throw r;},kh:!1},l=this;if(!l.postscribe){var m=Array.prototype.slice,q=function(){function r(p,t,v){var w="data-ps-"+t;if(2===arguments.length){var x=p.getAttribute(w);return b(x)?String(x):x}b(v)&&""!==v?p.setAttribute(w,
v):p.removeAttribute(w)}function u(p,t){var v=p.ownerDocument;e(this,{root:p,options:t,Ab:v.defaultView||v.parentWindow,Pa:v,fc:ec("",{Uf:!0}),Jc:[p],gd:"",hd:v.createElement(p.nodeName),wb:[],Fa:[]});r(this.hd,"proxyof",0)}u.prototype.write=function(){[].push.apply(this.Fa,arguments);for(var p;!this.Rb&&this.Fa.length;)p=this.Fa.shift(),"function"===typeof p?this.ag(p):this.rd(p)};u.prototype.ag=function(p){var t={type:"function",value:p.name||p.toString()};this.cd(t);p.call(this.Ab,this.Pa);this.Ie(t)};
u.prototype.rd=function(p){this.fc.append(p);for(var t,v=[],w,x;(t=this.fc.hh())&&!(w=t&&"tagName"in t?!!~t.tagName.toLowerCase().indexOf("script"):!1)&&!(x=t&&"tagName"in t?!!~t.tagName.toLowerCase().indexOf("style"):!1);)v.push(t);this.Ch(v);w&&this.Ag(t);x&&this.Bg(t)};u.prototype.Ch=function(p){var t=this.Yf(p);t.ee&&(t.Tc=this.gd+t.ee,this.gd+=t.eh,this.hd.innerHTML=t.Tc,this.zh())};u.prototype.Yf=function(p){var t=this.Jc.length,v=[],w=[],x=[];c(p,function(y){v.push(y.text);if(y.P){if(!/^noscript$/i.test(y.tagName)){var B=
t++;w.push(y.text.replace(/(\/?>)/," data-ps-id="+B+" $1"));"ps-script"!==y.P.id&&"ps-style"!==y.P.id&&x.push("atomicTag"===y.type?"":"<"+y.tagName+" data-ps-proxyof="+B+(y.zb?" />":">"))}}else w.push(y.text),x.push("endTag"===y.type?y.text:"")});return{di:p,raw:v.join(""),ee:w.join(""),eh:x.join("")}};u.prototype.zh=function(){for(var p,t=[this.hd];b(p=t.shift());){var v=1===p.nodeType;if(!v||!r(p,"proxyof")){v&&(this.Jc[r(p,"id")]=p,r(p,"id",null));var w=p.parentNode&&r(p.parentNode,"proxyof");
w&&this.Jc[w].appendChild(p)}t.unshift.apply(t,h(p.childNodes))}};u.prototype.Ag=function(p){var t=this.fc.clear();t&&this.Fa.unshift(t);p.src=p.P.src||p.P.Jh;p.src&&this.wb.length?this.Rb=p:this.cd(p);var v=this;this.Bh(p,function(){v.Ie(p)})};u.prototype.Bg=function(p){var t=this.fc.clear();t&&this.Fa.unshift(t);p.type=p.P.type||p.P.TYPE||"text/css";this.Dh(p);t&&this.write()};u.prototype.Dh=function(p){var t=this.$f(p);this.Fg(t);p.content&&(t.styleSheet&&!t.sheet?t.styleSheet.cssText=p.content:
t.appendChild(this.Pa.createTextNode(p.content)))};u.prototype.$f=function(p){var t=this.Pa.createElement(p.tagName);t.setAttribute("type",p.type);d(p.P,function(v,w){t.setAttribute(v,w)});return t};u.prototype.Fg=function(p){this.rd('<span id="ps-style"/>');var t=this.Pa.getElementById("ps-style");t.parentNode.replaceChild(p,t)};u.prototype.cd=function(p){p.Wg=this.Fa;this.Fa=[];this.wb.unshift(p)};u.prototype.Ie=function(p){p!==this.wb[0]?this.options.error({message:"Bad script nesting or script finished twice"}):
(this.wb.shift(),this.write.apply(this,p.Wg),!this.wb.length&&this.Rb&&(this.cd(this.Rb),this.Rb=null))};u.prototype.Bh=function(p,t){var v=this.Zf(p),w=this.qh(v),x=this.options.Lf;p.src&&(v.src=p.src,this.oh(v,w?x:function(){t();x()}));try{this.Eg(v),p.src&&!w||t()}catch(y){this.options.error(y),t()}};u.prototype.Zf=function(p){var t=this.Pa.createElement(p.tagName);d(p.P,function(v,w){t.setAttribute(v,w)});p.content&&(t.text=p.content);return t};u.prototype.Eg=function(p){this.rd('<span id="ps-script"/>');
var t=this.Pa.getElementById("ps-script");t.parentNode.replaceChild(p,t)};u.prototype.oh=function(p,t){function v(){p=p.onload=p.onreadystatechange=p.onerror=null}var w=this.options.error;e(p,{onload:function(){v();t()},onreadystatechange:function(){/^(loaded|complete)$/.test(p.readyState)&&(v(),t())},onerror:function(){var x={message:"remote script failed "+p.src};v();w(x);t()}})};u.prototype.qh=function(p){return!/^script$/i.test(p.nodeName)||!!(this.options.kh&&p.src&&p.hasAttribute("async"))};
return u}();l.postscribe=function(){function r(){var w=t.shift(),x;w&&(x=w[w.length-1],x.Mf(),w.stream=u.apply(null,w),x.Nf())}function u(w,x,y){function B(G){G=y.Wf(G);v.write(G);y.Of(G)}v=new q(w,y);v.id=p++;v.name=y.name||v.id;var z=w.ownerDocument,A={close:z.close,open:z.open,write:z.write,writeln:z.writeln};e(z,{close:a,open:a,write:function(){return B(h(arguments).join(""))},writeln:function(){return B(h(arguments).join("")+"\n")}});var F=v.Ab.onerror||a;v.Ab.onerror=function(G,L,R){y.error({Vh:G+
" - "+L+":"+R});F.apply(v.Ab,arguments)};v.write(x,function(){e(z,A);v.Ab.onerror=F;y.done();v=null;r()});return v}var p=0,t=[],v=null;return e(function(w,x,y){"function"===typeof y&&(y={done:y});y=f(y,k);w=/^#/.test(w)?l.document.getElementById(w.substr(1)):w.Th?w[0]:w;var B=[w,x,y];w.Zg={cancel:function(){B.stream?B.stream.abort():B[1]=a}};y.Vf(B);t.push(B);v||r();return w.Zg},{streams:{},Xh:t,Mh:q})}();fc=l.postscribe}})();var D=window,E=document,gc=navigator,hc=E.currentScript&&E.currentScript.src,ic=function(a,b){var c=D[a];D[a]=void 0===c?b:c;return D[a]},jc=function(a,b){b&&(a.addEventListener?a.onload=b:a.onreadystatechange=function(){a.readyState in{loaded:1,complete:1}&&(a.onreadystatechange=null,b())})},kc=function(a,b,c){var d=E.createElement("script");d.type="text/javascript";d.async=!0;d.src=a;jc(d,b);c&&(d.onerror=c);var e;if(null===na)b:{var f=la.document,h=f.querySelector&&f.querySelector("script[nonce]");
if(h){var k=h.nonce||h.getAttribute("nonce");if(k&&ma.test(k)){na=k;break b}}na=""}e=na;e&&d.setAttribute("nonce",e);var l=E.getElementsByTagName("script")[0]||E.body||E.head;l.parentNode.insertBefore(d,l);return d},lc=function(){if(hc){var a=hc.toLowerCase();if(0===a.indexOf("https://"))return 2;if(0===a.indexOf("http://"))return 3}return 1},mc=function(a,b){var c=E.createElement("iframe");c.height="0";c.width="0";c.style.display="none";c.style.visibility="hidden";var d=E.body&&E.body.lastChild||
E.body||E.head;d.parentNode.insertBefore(c,d);jc(c,b);void 0!==a&&(c.src=a);return c},nc=function(a,b,c){var d=new Image(1,1);d.onload=function(){d.onload=null;b&&b()};d.onerror=function(){d.onerror=null;c&&c()};d.src=a;return d},oc=function(a,b,c,d){a.addEventListener?a.addEventListener(b,c,!!d):a.attachEvent&&a.attachEvent("on"+b,c)},pc=function(a,b,c){a.removeEventListener?a.removeEventListener(b,c,!1):a.detachEvent&&a.detachEvent("on"+b,c)},H=function(a){D.setTimeout(a,0)},qc=function(a,b){return a&&
b&&a.attributes&&a.attributes[b]?a.attributes[b].value:null},rc=function(a){var b=a.innerText||a.textContent||"";b&&" "!=b&&(b=b.replace(/^[\s\xa0]+|[\s\xa0]+$/g,""));b&&(b=b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g," "));return b},sc=function(a){var b=E.createElement("div");b.innerHTML="A<div>"+a+"</div>";b=b.lastChild;for(var c=[];b.firstChild;)c.push(b.removeChild(b.firstChild));return c},tc=function(a,b,c){c=c||100;for(var d={},e=0;e<b.length;e++)d[b[e]]=!0;for(var f=a,h=0;f&&h<=c;h++){if(d[String(f.tagName).toLowerCase()])return f;
f=f.parentElement}return null},uc=function(a){gc.sendBeacon&&gc.sendBeacon(a)||nc(a)},vc=function(a,b){var c=a[b];c&&"string"===typeof c.animVal&&(c=c.animVal);return c};var xc=function(a){return wc?E.querySelectorAll(a):null},yc=function(a,b){if(!wc)return null;if(Element.prototype.closest)try{return a.closest(b)}catch(e){return null}var c=Element.prototype.matches||Element.prototype.webkitMatchesSelector||Element.prototype.mozMatchesSelector||Element.prototype.msMatchesSelector||Element.prototype.oMatchesSelector,d=a;if(!E.documentElement.contains(d))return null;do{try{if(c.call(d,b))return d}catch(e){break}d=d.parentElement||d.parentNode}while(null!==d&&1===d.nodeType);
return null},zc=!1;if(E.querySelectorAll)try{var Ac=E.querySelectorAll(":root");Ac&&1==Ac.length&&Ac[0]==E.documentElement&&(zc=!0)}catch(a){}var wc=zc;var I={},Qc=null,Rc=Math.random();I.s="GTM-5P4V6Z";I.Kb="4m0";I.Id="";var Sc={__cl:!0,__ecl:!0,__ehl:!0,__evl:!0,__fal:!0,__fil:!0,__fsl:!0,__hl:!0,__jel:!0,__lcl:!0,__sdl:!0,__tl:!0,__ytl:!0,__paused:!0,__tg:!0},Tc="www.googletagmanager.com/gtm.js";
var Uc=Tc,Vc=null,Wc=null,Xc=null,Yc="//www.googletagmanager.com/a?id="+I.s+"&cv=346",Zc={},$c={},ad=function(){var a=Qc.sequence||0;Qc.sequence=a+1;return a};var bd={},J=function(a,b){bd[a]=bd[a]||[];bd[a][b]=!0},cd=function(a){for(var b=[],c=bd[a]||[],d=0;d<c.length;d++)c[d]&&(b[Math.floor(d/6)]^=1<<d%6);for(var e=0;e<b.length;e++)b[e]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(b[e]||0);return b.join("")};
var dd=function(){return"&tc="+ub.filter(function(a){return a}).length},gd=function(){ed||(ed=D.setTimeout(fd,500))},fd=function(){ed&&(D.clearTimeout(ed),ed=void 0);void 0===id||jd[id]&&!kd&&!ld||(md[id]||nd.Kg()||0>=od--?(J("GTM",1),md[id]=!0):(nd.ih(),nc(pd()),jd[id]=!0,qd=rd=ld=kd=""))},pd=function(){var a=id;if(void 0===a)return"";var b=cd("GTM"),c=cd("TAGGING");return[sd,jd[a]?"":"&es=1",td[a],b?"&u="+b:"",c?"&ut="+c:"",dd(),kd,ld,rd,qd,"&z=0"].join("")},ud=function(){return[Yc,"&v=3&t=t","&pid="+
xa(),"&rv="+I.Kb].join("")},vd="0.005000">Math.random(),sd=ud(),wd=function(){sd=ud()},jd={},kd="",ld="",qd="",rd="",id=void 0,td={},md={},ed=void 0,nd=function(a,b){var c=0,d=0;return{Kg:function(){if(c<a)return!1;Ga()-d>=b&&(c=0);return c>=a},ih:function(){Ga()-d>=b&&(c=0);c++;d=Ga()}}}(2,1E3),od=1E3,xd=function(a,b){if(vd&&!md[a]&&id!==a){fd();id=a;qd=kd="";var c;c=0===b.indexOf("gtm.")?encodeURIComponent(b):"*";td[a]="&e="+c+"&eid="+a;gd()}},yd=function(a,b,c){if(vd&&!md[a]&&
b){a!==id&&(fd(),id=a);var d,e=String(b[Hb.va]||"").replace(/_/g,"");0===e.indexOf("cvt")&&(e="cvt");d=e;var f=c+d;kd=kd?kd+"."+f:"&tr="+f;var h=b["function"];if(!h)throw Error("Error: No function name given for function call.");var k=(wb[h]?"1":"2")+d;qd=qd?qd+"."+k:"&ti="+k;gd();2022<=pd().length&&fd()}},zd=function(a,b,c){if(vd&&!md[a]){a!==id&&(fd(),id=a);var d=c+b;ld=ld?ld+
"."+d:"&epr="+d;gd();2022<=pd().length&&fd()}};var Ad={},Bd=new ya,Cd={},Dd={},Gd={name:"dataLayer",set:function(a,b){C(Ma(a,b),Cd);Ed()},get:function(a){return Fd(a,2)},reset:function(){Bd=new ya;Cd={};Ed()}},Fd=function(a,b){if(2!=b){var c=Bd.get(a);if(vd){var d=Hd(a);c!==d&&J("GTM",5)}return c}return Hd(a)},Hd=function(a){var b=a.split("."),c=!1,d=void 0;return c?d:Id(b)},Id=function(a){for(var b=Cd,c=0;c<a.length;c++){if(null===b)return!1;if(void 0===b)break;b=b[a[c]]}return b};
var Jd=function(a,b){Dd.hasOwnProperty(a)||(Bd.set(a,b),C(Ma(a,b),Cd),Ed())},Ed=function(a){Aa(Dd,function(b,c){Bd.set(b,c);C(Ma(b,void 0),Cd);C(Ma(b,c),Cd);a&&delete Dd[b]})},Kd=function(a,b,c){Ad[a]=Ad[a]||{};var d=1!==c?Hd(b):Bd.get(b);"array"===Pa(d)||"object"===Pa(d)?Ad[a][b]=C(d):Ad[a][b]=d},Ld=function(a,b){if(Ad[a])return Ad[a][b]},Md=function(a,b){Ad[a]&&delete Ad[a][b]};var Q={ra:"_ee",Kh:"_uci",yc:"event_callback",Fb:"event_timeout",D:"gtag.config",aa:"allow_ad_personalization_signals",zc:"restricted_data_processing",Za:"allow_google_signals",ba:"cookie_expires",Eb:"cookie_update",$a:"session_duration",ja:"user_properties"};Q.ze=[Q.aa,Q.Za,Q.Eb];Q.Ce=[Q.ba,Q.Fb,Q.$a];var Pd=/[A-Z]+/,Qd=/\s/,Rd=function(a){if(g(a)&&(a=Fa(a),!Qd.test(a))){var b=a.indexOf("-");if(!(0>b)){var c=a.substring(0,b);if(Pd.test(c)){for(var d=a.substring(b+1).split("/"),e=0;e<d.length;e++)if(!d[e])return;return{id:a,prefix:c,containerId:c+"-"+d[0],w:d}}}}},Td=function(a){for(var b={},c=0;c<a.length;++c){var d=Rd(a[c]);d&&(b[d.id]=d)}Sd(b);var e=[];Aa(b,function(f,h){e.push(h)});return e};
function Sd(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];"AW"===d.prefix&&d.w[1]&&b.push(d.containerId)}for(var e=0;e<b.length;++e)delete a[b[e]]};var Ud=function(){var a=!1;return a};var T=function(a,b,c,d){return(2===Vd()||d||"http:"!=D.location.protocol?a:b)+c},Vd=function(){var a=lc(),b;if(1===a)a:{var c=Uc;c=c.toLowerCase();for(var d="https://"+c,e="http://"+c,f=1,h=E.getElementsByTagName("script"),k=0;k<h.length&&100>k;k++){var l=h[k].src;if(l){l=l.toLowerCase();if(0===l.indexOf(e)){b=3;break a}1===f&&0===l.indexOf(d)&&(f=2)}}b=f}else b=a;return b};var ie=new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),je={cl:["ecl"],customPixels:["nonGooglePixels"],ecl:["cl"],ehl:["hl"],hl:["ehl"],html:["customScripts","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],customScripts:["html","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],nonGooglePixels:[],nonGoogleScripts:["nonGooglePixels"],nonGoogleIframes:["nonGooglePixels"]},ke={cl:["ecl"],customPixels:["customScripts","html"],
ecl:["cl"],ehl:["hl"],hl:["ehl"],html:["customScripts"],customScripts:["html"],nonGooglePixels:["customPixels","customScripts","html","nonGoogleScripts","nonGoogleIframes"],nonGoogleScripts:["customScripts","html"],nonGoogleIframes:["customScripts","html","nonGoogleScripts"]},le="google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(" ");
var ne=function(a){var b=Fd("gtm.whitelist");b&&J("GTM",9);var c=b&&La(Da(b),je),d=Fd("gtm.blacklist");d||(d=Fd("tagTypeBlacklist"))&&J("GTM",3);d?
J("GTM",8):d=[];me()&&(d=Da(d),d.push("nonGooglePixels","nonGoogleScripts","sandboxedScripts"));0<=n(Da(d),"google")&&J("GTM",2);var e=d&&La(Da(d),ke),f={};return function(h){var k=h&&h[Hb.va];if(!k||"string"!=typeof k)return!0;k=k.replace(/^_*/,"");if(void 0!==f[k])return f[k];var l=$c[k]||[],m=a(k,l);if(b){var q;if(q=m)a:{if(0>n(c,k))if(l&&0<l.length)for(var r=0;r<
l.length;r++){if(0>n(c,l[r])){J("GTM",11);q=!1;break a}}else{q=!1;break a}q=!0}m=q}var u=!1;if(d){var p=0<=n(e,k);if(p)u=p;else{var t=za(e,l||[]);t&&J("GTM",10);u=t}}var v=!m||u;v||!(0<=n(l,"sandboxedScripts"))||c&&-1!==n(c,"sandboxedScripts")||(v=za(e,le));return f[k]=v}},me=function(){return ie.test(D.location&&D.location.hostname)};var oe={fg:function(a,b){b[Hb.yd]&&"string"===typeof a&&(a=1==b[Hb.yd]?a.toLowerCase():a.toUpperCase());b.hasOwnProperty(Hb.Ad)&&null===a&&(a=b[Hb.Ad]);b.hasOwnProperty(Hb.Cd)&&void 0===a&&(a=b[Hb.Cd]);b.hasOwnProperty(Hb.Bd)&&!0===a&&(a=b[Hb.Bd]);b.hasOwnProperty(Hb.zd)&&!1===a&&(a=b[Hb.zd]);return a}};var pe={active:!0,isWhitelisted:function(){return!0}},qe=function(a){var b=Qc.zones;!b&&a&&(b=Qc.zones=a());return b};var re=function(){};var se=!1,te=0,ue=[];function ve(a){if(!se){var b=E.createEventObject,c="complete"==E.readyState,d="interactive"==E.readyState;if(!a||"readystatechange"!=a.type||c||!b&&d){se=!0;for(var e=0;e<ue.length;e++)H(ue[e])}ue.push=function(){for(var f=0;f<arguments.length;f++)H(arguments[f]);return 0}}}function we(){if(!se&&140>te){te++;try{E.documentElement.doScroll("left"),ve()}catch(a){D.setTimeout(we,50)}}}var xe=function(a){se?a():ue.push(a)};var ye={},ze={},Ae=function(a,b,c,d){if(!ze[a]||Sc[b]||"__zone"===b)return-1;var e={};Ra(d)&&(e=C(d,e));e.id=c;e.status="timeout";return ze[a].tags.push(e)-1},Be=function(a,b,c,d){if(ze[a]){var e=ze[a].tags[b];e&&(e.status=c,e.executionTime=d)}};function Ce(a){for(var b=ye[a]||[],c=0;c<b.length;c++)b[c]();ye[a]={push:function(d){d(I.s,ze[a])}}}
var Fe=function(a,b,c){ze[a]={tags:[]};qa(b)&&De(a,b);c&&D.setTimeout(function(){return Ce(a)},Number(c));return Ee(a)},De=function(a,b){ye[a]=ye[a]||[];ye[a].push(Ia(function(){return H(function(){b(I.s,ze[a])})}))};function Ee(a){var b=0,c=0,d=!1;return{add:function(){c++;return Ia(function(){b++;d&&b>=c&&Ce(a)})},Sf:function(){d=!0;b>=c&&Ce(a)}}};var Ge=function(){function a(d){return!ra(d)||0>d?0:d}if(!Qc._li&&D.performance&&D.performance.timing){var b=D.performance.timing.navigationStart,c=ra(Gd.get("gtm.start"))?Gd.get("gtm.start"):0;Qc._li={cst:a(c-b),cbt:a(Wc-b)}}};var Ke={},Le=function(){return D.GoogleAnalyticsObject&&D[D.GoogleAnalyticsObject]},Me=!1;
var Ne=function(a){D.GoogleAnalyticsObject||(D.GoogleAnalyticsObject=a||"ga");var b=D.GoogleAnalyticsObject;if(D[b])D.hasOwnProperty(b)||J("GTM",12);else{var c=function(){c.q=c.q||[];c.q.push(arguments)};c.l=Number(new Date);D[b]=c}Ge();return D[b]},Oe=function(a,b,c,d){b=String(b).replace(/\s+/g,"").split(",");var e=Le();e(a+"require","linker");e(a+"linker:autoLink",b,c,d)};
var Qe=function(a){},Pe=function(){return D.GoogleAnalyticsObject||"ga"};var Se=/^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;var Te=/:[0-9]+$/,Ue=function(a,b,c){for(var d=a.split("&"),e=0;e<d.length;e++){var f=d[e].split("=");if(decodeURIComponent(f[0]).replace(/\+/g," ")===b){var h=f.slice(1).join("=");return c?h:decodeURIComponent(h).replace(/\+/g," ")}}},Xe=function(a,b,c,d,e){b&&(b=String(b).toLowerCase());if("protocol"===b||"port"===b)a.protocol=Ve(a.protocol)||Ve(D.location.protocol);"port"===b?a.port=String(Number(a.hostname?a.port:D.location.port)||("http"==a.protocol?80:"https"==a.protocol?443:"")):"host"===b&&
(a.hostname=(a.hostname||D.location.hostname).replace(Te,"").toLowerCase());return We(a,b,c,d,e)},We=function(a,b,c,d,e){var f,h=Ve(a.protocol);b&&(b=String(b).toLowerCase());switch(b){case "url_no_fragment":f=Ye(a);break;case "protocol":f=h;break;case "host":f=a.hostname.replace(Te,"").toLowerCase();if(c){var k=/^www\d*\./.exec(f);k&&k[0]&&(f=f.substr(k[0].length))}break;case "port":f=String(Number(a.port)||("http"==h?80:"https"==h?443:""));break;case "path":a.pathname||a.hostname||J("TAGGING",1);
f="/"==a.pathname.substr(0,1)?a.pathname:"/"+a.pathname;var l=f.split("/");0<=n(d||[],l[l.length-1])&&(l[l.length-1]="");f=l.join("/");break;case "query":f=a.search.replace("?","");e&&(f=Ue(f,e,void 0));break;case "extension":var m=a.pathname.split(".");f=1<m.length?m[m.length-1]:"";f=f.split("/")[0];break;case "fragment":f=a.hash.replace("#","");break;default:f=a&&a.href}return f},Ve=function(a){return a?a.replace(":","").toLowerCase():""},Ye=function(a){var b="";if(a&&a.href){var c=a.href.indexOf("#");
b=0>c?a.href:a.href.substr(0,c)}return b},Ze=function(a){var b=E.createElement("a");a&&(b.href=a);var c=b.pathname;"/"!==c[0]&&(a||J("TAGGING",1),c="/"+c);var d=b.hostname.replace(Te,"");return{href:b.href,protocol:b.protocol,host:b.host,hostname:d,pathname:c,search:b.search,hash:b.hash,port:b.port}};function df(a,b,c,d){var e=ub[a],f=ef(a,b,c,d);if(!f)return null;var h=Db(e[Hb.Rd],c,[]);if(h&&h.length){var k=h[0];f=df(k.index,{C:f,B:1===k.pe?b.terminate:f,terminate:b.terminate},c,d)}return f}
function ef(a,b,c,d){function e(){if(f[Hb.pf])k();else{var w=Eb(f,c,[]),x=Ae(c.id,String(f[Hb.va]),Number(f[Hb.Td]),w[Hb.qf]),y=!1;w.vtp_gtmOnSuccess=function(){if(!y){y=!0;var A=Ga()-z;yd(c.id,ub[a],"5");Be(c.id,x,"success",A);h()}};w.vtp_gtmOnFailure=function(){if(!y){y=!0;var A=Ga()-z;yd(c.id,ub[a],"6");Be(c.id,x,"failure",A);k()}};w.vtp_gtmTagId=f.tag_id;
w.vtp_gtmEventId=c.id;yd(c.id,f,"1");var B=function(){var A=Ga()-z;yd(c.id,f,"7");Be(c.id,x,"exception",A);y||(y=!0,k())};var z=Ga();try{Cb(w,c)}catch(A){B(A)}}}var f=ub[a],h=b.C,k=b.B,l=b.terminate;if(c.Vc(f))return null;var m=Db(f[Hb.Ud],c,[]);if(m&&m.length){var q=m[0],r=df(q.index,{C:h,B:k,terminate:l},c,d);if(!r)return null;h=r;k=2===q.pe?l:r}if(f[Hb.Jd]||f[Hb.uf]){var u=f[Hb.Jd]?vb:c.rh,p=h,t=k;if(!u[a]){e=Ia(e);var v=ff(a,u,e);h=v.C;k=v.B}return function(){u[a](p,t)}}return e}
function ff(a,b,c){var d=[],e=[];b[a]=gf(d,e,c);return{C:function(){b[a]=hf;for(var f=0;f<d.length;f++)d[f]()},B:function(){b[a]=jf;for(var f=0;f<e.length;f++)e[f]()}}}function gf(a,b,c){return function(d,e){a.push(d);b.push(e);c()}}function hf(a){a()}function jf(a,b){b()};var mf=function(a,b){for(var c=[],d=0;d<ub.length;d++)if(a.ub[d]){var e=ub[d];var f=b.add();try{var h=df(d,{C:f,B:f,terminate:f},a,d);h?c.push({Te:d,Ne:Fb(e),qg:h}):(kf(d,a),f())}catch(l){f()}}b.Sf();c.sort(lf);for(var k=0;k<c.length;k++)c[k].qg();return 0<c.length};function lf(a,b){var c,d=b.Ne,e=a.Ne;c=d>e?1:d<e?-1:0;var f;if(0!==c)f=c;else{var h=a.Te,k=b.Te;f=h>k?1:h<k?-1:0}return f}
function kf(a,b){if(!vd)return;var c=function(d){var e=b.Vc(ub[d])?"3":"4",f=Db(ub[d][Hb.Rd],b,[]);f&&f.length&&c(f[0].index);yd(b.id,ub[d],e);var h=Db(ub[d][Hb.Ud],b,[]);h&&h.length&&c(h[0].index)};c(a);}
var nf=!1,of=function(a,b,c,d,e){if("gtm.js"==b){if(nf)return!1;nf=!0}xd(a,b);var f=Fe(a,d,e);Kd(a,"event",1);Kd(a,"ecommerce",1);Kd(a,"gtm");var h={id:a,name:b,Vc:ne(c),ub:[],rh:[],De:function(){J("GTM",6)}};h.ub=Lb(h);var k=mf(h,f);"gtm.js"!==b&&"gtm.sync"!==b||Qe(I.s);if(!k)return k;for(var l=0;l<h.ub.length;l++)if(h.ub[l]){var m=ub[l];if(m&&!Sc[String(m[Hb.va])])return!0}return!1};var pf=[];function qf(){var a=ic("google_tag_data",{});a.ics||(a.ics={entries:{},set:rf,update:sf,addListener:tf,notifyListeners:uf,active:!1});return a.ics}function rf(a,b,c,d,e){var f=qf();f.active=!0;if(void 0!=b){var h=f.entries,k=h[a]||{},l=k.region,m=c&&g(c)?c.toUpperCase():void 0;d=d.toUpperCase();e=e.toUpperCase();m!==e&&(m===d?l===e:m||l)||(h[a]={region:m,initial:"granted"===b,update:k.update})}}
function sf(a,b){var c=qf();c.active=!0;if(void 0!=b){var d=vf(a),e=c.entries;e[a]=e[a]||{};e[a].update="granted"===b;if(vf(a)!==d)for(var f=0;f<pf.length;++f){var h=pf[f];sa(h.je)&&-1!==h.je.indexOf(a)&&(h.Me=!0)}}}function tf(a,b){pf.push({je:a,sg:b})}function uf(){for(var a=0;a<pf.length;++a){var b=pf[a];if(b.Me){b.Me=!1;try{b.sg.call()}catch(c){}}}}
var vf=function(a){var b=qf().entries[a]||{};return void 0!==b.update?b.update:void 0!==b.initial?b.initial:void 0},wf=function(){return qf().active},xf=function(a,b){qf().addListener(a,b)},yf=function(a,b){if(!1===vf(b)){var c=!1;xf([b],function(){!c&&vf(b)&&(a(),c=!0)})}};var zf=[Q.o,Q.J],Af=function(a){var b=a.region;b&&J("GTM",40);for(var c=sa(b)?b:[b],d=0;d<c.length;++d)for(var e=0;e<zf.length;e++){var f=zf[e],h=a[zf[e]],k=c[d];qf().set(f,h,k,"US","US-FL")}},Bf=function(a){for(var b=0;b<zf.length;b++){var c=zf[b],d=a[zf[b]];qf().update(c,d)}qf().notifyListeners()},Cf=function(a){var b=vf(a);return void 0!=b?b:!0},Df=function(){for(var a=[],b=0;b<zf.length;b++){var c=vf(zf[b]);a[b]=!0===c?"1":!1===c?"0":"-"}return"G1"+a.join("")};function Ff(a,b){}function Gf(a,b){return Hf()?Ff(a,b):void 0}function Hf(){var a=!1;return a};var If=function(){this.eventModel={};this.targetConfig={};this.containerConfig={};this.h={};this.globalConfig={};this.C=function(){};this.B=function(){};this.ie=void 0},Jf=function(a){var b=new If;b.eventModel=a;return b},Kf=function(a,b){a.targetConfig=b;return a},Lf=function(a,b){a.containerConfig=b;return a},Mf=function(a,b){a.h=b;return a},Nf=function(a,b){a.globalConfig=b;return a},Of=function(a,b){a.C=b;return a},Pf=function(a,b){a.B=b;return a};
If.prototype.getWithConfig=function(a){if(void 0!==this.eventModel[a])return this.eventModel[a];if(void 0!==this.targetConfig[a])return this.targetConfig[a];if(void 0!==this.containerConfig[a])return this.containerConfig[a];if(void 0!==this.h[a])return this.h[a];if(void 0!==this.globalConfig[a])return this.globalConfig[a]};
var Qf=function(a){function b(e){Aa(e,function(f){c[f]=null})}var c={};b(a.eventModel);b(a.targetConfig);b(a.containerConfig);b(a.globalConfig);var d=[];Aa(c,function(e){d.push(e)});return d};function Rf(a,b,c){for(var d=[],e=b.split(";"),f=0;f<e.length;f++){var h=e[f].split("="),k=h[0].replace(/^\s*|\s*$/g,"");if(k&&k==a){var l=h.slice(1).join("=").replace(/^\s*|\s*$/g,"");l&&c&&(l=decodeURIComponent(l));d.push(l)}}return d};var Sf={},Tf=function(a){return void 0==Sf[a]?!1:Sf[a]};var Vf=function(a,b,c,d){return Uf(d)?Rf(a,String(b||document.cookie),c):[]},Yf=function(a,b,c,d,e){if(Uf(e)){var f=Wf(a,d,e);if(1===f.length)return f[0].id;if(0!==f.length){f=Xf(f,function(h){return h.Sb},b);if(1===f.length)return f[0].id;f=Xf(f,function(h){return h.vb},c);return f[0]?f[0].id:void 0}}};function Zf(a,b,c,d){var e=document.cookie;document.cookie=a;var f=document.cookie;return e!=f||void 0!=c&&0<=Vf(b,f,!1,d).indexOf(c)}
var cg=function(a,b,c){function d(p,t,v){if(null==v)return delete h[t],p;h[t]=v;return p+"; "+t+"="+v}function e(p,t){if(null==t)return delete h[t],p;h[t]=!0;return p+"; "+t}if(!Uf(c.Ca))return!1;var f;void 0==b?f=a+"=deleted; expires="+(new Date(0)).toUTCString():(c.encode&&(b=encodeURIComponent(b)),b=$f(b),f=a+"="+b);var h={};f=d(f,"path",c.path);var k;c.expires instanceof Date?k=c.expires.toUTCString():null!=c.expires&&(k=""+c.expires);f=d(f,"expires",k);f=d(f,"max-age",c.Uh);f=d(f,"samesite",
c.$h);c.ai&&(f=e(f,"secure"));f=e(f,c.flags);var l=c.domain;if("auto"===l){for(var m=ag(),q=0;q<m.length;++q){var r="none"!==m[q]?m[q]:void 0,u=d(f,"domain",r);if(!bg(r,c.path)&&Zf(u,a,b,c.Ca))return!0}return!1}l&&"none"!==l&&(f=d(f,"domain",l));return bg(l,c.path)?!1:Zf(f,a,b,c.Ca)},dg=function(a,b,c){null==c.path&&(c.path="/");c.domain||(c.domain="auto");return cg(a,b,c)};
function Xf(a,b,c){for(var d=[],e=[],f,h=0;h<a.length;h++){var k=a[h],l=b(k);l===c?d.push(k):void 0===f||l<f?(e=[k],f=l):l===f&&e.push(k)}return 0<d.length?d:e}function Wf(a,b,c){for(var d=[],e=Vf(a,void 0,void 0,c),f=0;f<e.length;f++){var h=e[f].split("."),k=h.shift();if(!b||-1!==b.indexOf(k)){var l=h.shift();l&&(l=l.split("-"),d.push({id:h.join("."),Sb:1*l[0]||1,vb:1*l[1]||1}))}}return d}
var $f=function(a){a&&1200<a.length&&(a=a.substring(0,1200));return a},eg=/^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,fg=/(^|\.)doubleclick\.net$/i,bg=function(a,b){return fg.test(document.location.hostname)||"/"===b&&eg.test(a)},ag=function(){var a=[],b=document.location.hostname.split(".");if(4===b.length){var c=b[b.length-1];if(parseInt(c,10).toString()===c)return["none"]}for(var d=b.length-2;0<=d;d--)a.push(b.slice(d).join("."));var e=document.location.hostname;fg.test(e)||eg.test(e)||a.push("none");
return a},Uf=function(a){if(!Tf("gtag_cs_api")||!a||!wf())return!0;var b=vf(a);return null==b?!0:!!b};var gg=function(){for(var a=gc.userAgent+(E.cookie||"")+(E.referrer||""),b=a.length,c=D.history.length;0<c;)a+=c--^b++;var d=1,e,f,h;if(a)for(d=0,f=a.length-1;0<=f;f--)h=a.charCodeAt(f),d=(d<<6&268435455)+h+(h<<14),e=d&266338304,d=0!=e?d^e>>21:d;return[Math.round(2147483647*Math.random())^d&2147483647,Math.round(Ga()/1E3)].join(".")},jg=function(a,b,c,d,e){var f=hg(b);return Yf(a,f,ig(c),d,e)},kg=function(a,b,c,d){var e=""+hg(c),f=ig(d);1<f&&(e+="-"+f);return[b,e,a].join(".")},hg=function(a){if(!a)return 1;
a=0===a.indexOf(".")?a.substr(1):a;return a.split(".").length},ig=function(a){if(!a||"/"===a)return 1;"/"!==a[0]&&(a="/"+a);"/"!==a[a.length-1]&&(a+="/");return a.split("/").length-1};function lg(a,b,c){var d,e=a.tb;null==e&&(e=7776E3);0!==e&&(d=new Date((b||Ga())+1E3*e));return{path:a.path,domain:a.domain,flags:a.flags,encode:!!c,expires:d}};function mg(){for(var a=ng,b={},c=0;c<a.length;++c)b[a[c]]=c;return b}function og(){var a="ABCDEFGHIJKLMNOPQRSTUVWXYZ";a+=a.toLowerCase()+"0123456789-_";return a+"."}var ng,pg;function rg(a){ng=ng||og();pg=pg||mg();for(var b=[],c=0;c<a.length;c+=3){var d=c+1<a.length,e=c+2<a.length,f=a.charCodeAt(c),h=d?a.charCodeAt(c+1):0,k=e?a.charCodeAt(c+2):0,l=f>>2,m=(f&3)<<4|h>>4,q=(h&15)<<2|k>>6,r=k&63;e||(r=64,d||(q=64));b.push(ng[l],ng[m],ng[q],ng[r])}return b.join("")}
function sg(a){function b(l){for(;d<a.length;){var m=a.charAt(d++),q=pg[m];if(null!=q)return q;if(!/^[\s\xa0]*$/.test(m))throw Error("Unknown base64 encoding at char: "+m);}return l}ng=ng||og();pg=pg||mg();for(var c="",d=0;;){var e=b(-1),f=b(0),h=b(64),k=b(64);if(64===k&&-1===e)return c;c+=String.fromCharCode(e<<2|f>>4);64!=h&&(c+=String.fromCharCode(f<<4&240|h>>2),64!=k&&(c+=String.fromCharCode(h<<6&192|k)))}};var tg;var xg=function(){var a=ug,b=vg,c=wg(),d=function(h){a(h.target||h.srcElement||{})},e=function(h){b(h.target||h.srcElement||{})};if(!c.init){oc(E,"mousedown",d);oc(E,"keyup",d);oc(E,"submit",e);var f=HTMLFormElement.prototype.submit;HTMLFormElement.prototype.submit=function(){b(this);f.call(this)};c.init=!0}},yg=function(a,b,c,d,e){var f={callback:a,domains:b,fragment:2===c,placement:c,forms:d,sameHost:e};wg().decorators.push(f)},zg=function(a,b,c){for(var d=wg().decorators,e={},f=0;f<d.length;++f){var h=
d[f],k;if(k=!c||h.forms)a:{var l=h.domains,m=a;if(l&&(h.sameHost||m!==E.location.hostname))for(var q=0;q<l.length;q++)if(l[q]instanceof RegExp){if(l[q].test(m)){k=!0;break a}}else if(0<=m.indexOf(l[q])){k=!0;break a}k=!1}if(k){var r=h.placement;void 0==r&&(r=h.fragment?2:1);r===b&&Ja(e,h.callback())}}return e},wg=function(){var a=ic("google_tag_data",{}),b=a.gl;b&&b.decorators||(b={decorators:[]},a.gl=b);return b};var Ag=/(.*?)\*(.*?)\*(.*)/,Bg=/^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,Cg=/^(?:www\.|m\.|amp\.)+/,Dg=/([^?#]+)(\?[^#]*)?(#.*)?/;function Eg(a){return new RegExp("(.*?)(^|&)"+a+"=([^&]*)&?(.*)")}
var Gg=function(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];void 0!==d&&d===d&&null!==d&&"[object Object]"!==d.toString()&&(b.push(c),b.push(rg(String(d))))}var e=b.join("*");return["1",Fg(e),e].join("*")},Fg=function(a,b){var c=[window.navigator.userAgent,(new Date).getTimezoneOffset(),window.navigator.userLanguage||window.navigator.language,Math.floor((new Date).getTime()/60/1E3)-(void 0===b?0:b),a].join("*"),d;if(!(d=tg)){for(var e=Array(256),f=0;256>f;f++){for(var h=f,k=0;8>k;k++)h=
h&1?h>>>1^3988292384:h>>>1;e[f]=h}d=e}tg=d;for(var l=4294967295,m=0;m<c.length;m++)l=l>>>8^tg[(l^c.charCodeAt(m))&255];return((l^-1)>>>0).toString(36)},Ig=function(){return function(a){var b=Ze(D.location.href),c=b.search.replace("?",""),d=Ue(c,"_gl",!0)||"";a.query=Hg(d)||{};var e=Xe(b,"fragment").match(Eg("_gl"));a.fragment=Hg(e&&e[3]||"")||{}}},Jg=function(){var a=Ig(),b=wg();b.data||(b.data={query:{},fragment:{}},a(b.data));var c={},d=b.data;d&&(Ja(c,d.query),Ja(c,d.fragment));return c},Hg=function(a){var b;
b=void 0===b?3:b;try{if(a){var c;a:{for(var d=a,e=0;3>e;++e){var f=Ag.exec(d);if(f){c=f;break a}d=decodeURIComponent(d)}c=void 0}var h=c;if(h&&"1"===h[1]){var k=h[3],l;a:{for(var m=h[2],q=0;q<b;++q)if(m===Fg(k,q)){l=!0;break a}l=!1}if(l){for(var r={},u=k?k.split("*"):[],p=0;p<u.length;p+=2)r[u[p]]=sg(u[p+1]);return r}}}}catch(t){}};
function Kg(a,b,c,d){function e(q){var r=q,u=Eg(a).exec(r),p=r;if(u){var t=u[2],v=u[4];p=u[1];v&&(p=p+t+v)}q=p;var w=q.charAt(q.length-1);q&&"&"!==w&&(q+="&");return q+m}d=void 0===d?!1:d;var f=Dg.exec(c);if(!f)return"";var h=f[1],k=f[2]||"",l=f[3]||"",m=a+"="+b;d?l="#"+e(l.substring(1)):k="?"+e(k.substring(1));return""+h+k+l}
function Lg(a,b){var c="FORM"===(a.tagName||"").toUpperCase(),d=zg(b,1,c),e=zg(b,2,c),f=zg(b,3,c);if(Ka(d)){var h=Gg(d);c?Mg("_gl",h,a):Ng("_gl",h,a,!1)}if(!c&&Ka(e)){var k=Gg(e);Ng("_gl",k,a,!0)}for(var l in f)if(f.hasOwnProperty(l))a:{var m=l,q=f[l],r=a;if(r.tagName){if("a"===r.tagName.toLowerCase()){Ng(m,q,r,void 0);break a}if("form"===r.tagName.toLowerCase()){Mg(m,q,r);break a}}"string"==typeof r&&Kg(m,q,r,void 0)}}
function Ng(a,b,c,d){if(c.href){var e=Kg(a,b,c.href,void 0===d?!1:d);Se.test(e)&&(c.href=e)}}
function Mg(a,b,c){if(c&&c.action){var d=(c.method||"").toLowerCase();if("get"===d){for(var e=c.childNodes||[],f=!1,h=0;h<e.length;h++){var k=e[h];if(k.name===a){k.setAttribute("value",b);f=!0;break}}if(!f){var l=E.createElement("input");l.setAttribute("type","hidden");l.setAttribute("name",a);l.setAttribute("value",b);c.appendChild(l)}}else if("post"===d){var m=Kg(a,b,c.action);Se.test(m)&&(c.action=m)}}}
var ug=function(a){try{var b;a:{for(var c=a,d=100;c&&0<d;){if(c.href&&c.nodeName.match(/^a(?:rea)?$/i)){b=c;break a}c=c.parentNode;d--}b=null}var e=b;if(e){var f=e.protocol;"http:"!==f&&"https:"!==f||Lg(e,e.hostname)}}catch(h){}},vg=function(a){try{if(a.action){var b=Xe(Ze(a.action),"host");Lg(a,b)}}catch(c){}},Og=function(a,b,c,d){xg();yg(a,b,"fragment"===c?2:1,!!d,!1)},Pg=function(a,b){xg();yg(a,[We(D.location,"host",!0)],b,!0,!0)},Qg=function(){var a=E.location.hostname,b=Bg.exec(E.referrer);if(!b)return!1;
var c=b[2],d=b[1],e="";if(c){var f=c.split("/"),h=f[1];e="s"===h?decodeURIComponent(f[2]):decodeURIComponent(h)}else if(d){if(0===d.indexOf("xn--"))return!1;e=d.replace(/-/g,".").replace(/\.\./g,"-")}var k=a.replace(Cg,""),l=e.replace(Cg,""),m;if(!(m=k===l)){var q="."+l;m=k.substring(k.length-q.length,k.length)===q}return m},Rg=function(a,b){return!1===a?!1:a||b||Qg()};var Sg=/^\w+$/,Tg=/^[\w-]+$/,Ug=/^~?[\w-]+$/,Vg={aw:"_aw",dc:"_dc",gf:"_gf",ha:"_ha",gp:"_gp"},Wg=function(){if(!Tf("gtag_cs_api")||!wf())return!0;var a=vf("ad_storage");return null==a?!0:!!a},Xg=function(a){Wg()?a():yf(a,"ad_storage")};function Yg(a){return a&&"string"==typeof a&&a.match(Sg)?a:"_gcl"}
var $g=function(){var a=Ze(D.location.href),b=Xe(a,"query",!1,void 0,"gclid"),c=Xe(a,"query",!1,void 0,"gclsrc"),d=Xe(a,"query",!1,void 0,"dclid");if(!b||!c){var e=a.hash.replace("#","");b=b||Ue(e,"gclid",void 0);c=c||Ue(e,"gclsrc",void 0)}return Zg(b,c,d)},Zg=function(a,b,c){var d={},e=function(f,h){d[h]||(d[h]=[]);d[h].push(f)};d.gclid=a;d.gclsrc=b;d.dclid=c;if(void 0!==a&&a.match(Tg))switch(b){case void 0:e(a,"aw");break;case "aw.ds":e(a,"aw");e(a,"dc");break;case "ds":e(a,"dc");break;case "3p.ds":Tf("gtm_3pds")&&
e(a,"dc");break;case "gf":e(a,"gf");break;case "ha":e(a,"ha");break;case "gp":e(a,"gp")}c&&e(c,"dc");return d},bh=function(a){var b=$g();Xg(function(){return ah(b,a)})};
function ah(a,b,c){function d(m,q){var r=ch(m,e);r&&(dg(r,q,f),h=!0)}b=b||{};var e=Yg(b.prefix);c=c||Ga();var f=lg(b,c,!0);f.Ca="ad_storage";var h=!1,k=Math.round(c/1E3),l=function(m){return["GCL",k,m].join(".")};a.aw&&(!0===b.ei?d("aw",l("~"+a.aw[0])):d("aw",l(a.aw[0])));a.dc&&d("dc",l(a.dc[0]));a.gf&&d("gf",l(a.gf[0]));a.ha&&d("ha",l(a.ha[0]));a.gp&&d("gp",l(a.gp[0]));return h}
var eh=function(a,b){var c=Jg();Xg(function(){for(var d=Yg(b.prefix),e=0;e<a.length;++e){var f=a[e];if(void 0!==Vg[f]){var h=ch(f,d),k=c[h];if(k){var l=Math.min(dh(k),Ga()),m;b:{for(var q=l,r=Vf(h,E.cookie,void 0,"ad_storage"),u=0;u<r.length;++u)if(dh(r[u])>q){m=!0;break b}m=!1}if(!m){var p=lg(b,l,!0);p.Ca="ad_storage";dg(h,k,p)}}}}ah(Zg(c.gclid,c.gclsrc),b)})},ch=function(a,b){var c=Vg[a];if(void 0!==c)return b+c},dh=function(a){var b=a.split(".");return 3!==b.length||"GCL"!==b[0]?0:1E3*(Number(b[1])||
0)};function fh(a){var b=a.split(".");if(3==b.length&&"GCL"==b[0]&&b[1])return b[2]}
var gh=function(a,b,c,d,e){if(sa(b)){var f=Yg(e),h=function(){for(var k={},l=0;l<a.length;++l){var m=ch(a[l],f);if(m){var q=Vf(m,E.cookie,void 0,"ad_storage");q.length&&(k[m]=q.sort()[q.length-1])}}return k};Xg(function(){Og(h,b,c,d)})}},hh=function(a){return a.filter(function(b){return Ug.test(b)})},ih=function(a,b){for(var c=Yg(b.prefix),d={},e=0;e<a.length;e++)Vg[a[e]]&&(d[a[e]]=Vg[a[e]]);Xg(function(){Aa(d,function(f,h){var k=Vf(c+h,E.cookie,void 0,"ad_storage");if(k.length){var l=k[0],m=dh(l),
q={};q[f]=[fh(l)];ah(q,b,m)}})})};function jh(a){for(var b=["aw","dc"],c=0;c<b.length;++c)if(a[b[c]])return!0;return!1}
var kh=function(){function a(d,e,f){f&&(d[e]=f)}var b=$g();if(jh(b)){var c={};a(c,"gclid",b.gclid);a(c,"dclid",b.dclid);a(c,"gclsrc",b.gclsrc);Pg(function(){return c},3);Pg(function(){var d={};return d._up="1",d},1)}},lh=function(){var a;if(Wg()){for(var b=[],c=E.cookie.split(";"),d=/^\s*_gac_(UA-\d+-\d+)=\s*(.+?)\s*$/,e=0;e<c.length;e++){var f=c[e].match(d);f&&b.push({nd:f[1],value:f[2]})}var h={};if(b&&b.length)for(var k=0;k<b.length;k++){var l=b[k].value.split(".");"1"==l[0]&&3==l.length&&l[1]&&
(h[b[k].nd]||(h[b[k].nd]=[]),h[b[k].nd].push({timestamp:l[1],vg:l[2]}))}a=h}else a={};return a};function mh(){var a=!1;return a}
function nh(a){function b(l){var m;Qc.reported_gclid||(Qc.reported_gclid={});m=Qc.reported_gclid;var q=d+(l?"gcu":"gcs");if(!m[q]){m[q]=!0;var r=[],u=function(v,w){w&&r.push(v+"="+encodeURIComponent(w))},p=d;u("gclid",p);u("gclsrc",e);var t="https://www.google.com/pagead/landing?"+r.join("&");uc(t)}}var c=$g(),d=c.gclid||"",e=c.gclsrc,
f=!a&&(!d||e&&"aw.ds"!==e?!1:!0),h=mh();if(f||h){var k=""+gg();b();}};var oh;if(3===I.Kb.length)oh="g";else{var ph="G";oh=ph}
var qh={"":"n",UA:"u",AW:"a",DC:"d",G:"e",GF:"f",HA:"h",GTM:oh,OPT:"o"},rh=function(a){var b=I.s.split("-"),c=b[0].toUpperCase(),d=qh[c]||"i",e=a&&"GTM"===c?b[1]:"OPT"===c?b[1]:"",f;if(3===I.Kb.length){var h=void 0;f="2"+(h||"w")}else f=
"";return f+d+I.Kb+e};var Bh=["1"],Ch={},Gh=function(a){var b=Dh(a.prefix);Ch[b]||Eh(b,a.path,a.domain)||(Fh(b,gg(),a),Eh(b,a.path,a.domain))};function Fh(a,b,c){var d=kg(b,"1",c.domain,c.path),e=lg(c);e.Ca="ad_storage";dg(a,d,e)}function Eh(a,b,c){var d=jg(a,b,c,Bh,"ad_storage");d&&(Ch[a]=d);return d}function Dh(a){return(a||"_gcl")+"_au"};var Hh=/^\d+\.fls\.doubleclick\.net$/;function Ih(a){Cf("ad_storage")?a():yf(a,"ad_storage")}function Jh(a){var b=Ze(D.location.href),c=Xe(b,"host",!1);if(c&&c.match(Hh)){var d=Xe(b,"path").split(a+"=");if(1<d.length)return d[1].split(";")[0].split("?")[0]}}
function Kh(a,b){if("aw"==a||"dc"==a){var c=Jh("gcl"+a);if(c)return c.split(".")}var d=Yg(b);if(Cf("ad_storage")&&"_gcl"==d){var e;e=$g()[a]||[];if(0<e.length)return e}var f=ch(a,d),h;if(f){var k=[];if(E.cookie){var l=Vf(f,E.cookie,void 0,"ad_storage");if(l&&0!=l.length){for(var m=0;m<l.length;m++){var q=fh(l[m]);q&&-1===n(k,q)&&k.push(q)}h=hh(k)}else h=k}else h=k}else h=[];return h}
var Lh=function(){var a=Jh("gac");if(a)return decodeURIComponent(a);var b=lh(),c=[];Aa(b,function(d,e){for(var f=[],h=0;h<e.length;h++)f.push(e[h].vg);f=hh(f);f.length&&c.push(d+":"+f.join(","))});return c.join(";")},Mh=function(a,b){var c=$g().dc||[];Ih(function(){Gh(b);var d=Ch[Dh(b.prefix)],e=!1;if(d&&0<c.length){var f=Qc.joined_au=Qc.joined_au||{},h=b.prefix||"_gcl";if(!f[h])for(var k=0;k<c.length;k++){var l="https://adservice.google.com/ddm/regclk";l=l+"?gclid="+c[k]+"&auiddc="+d;uc(l);e=f[h]=!0}}null==a&&
(a=e);if(a&&d){var m=Dh(b.prefix),q=Ch[m];q&&Fh(m,q,b)}})};var Gi={},Hi=["G","GP"];Gi.Ve="";var Ii=Gi.Ve.split(",");function Ji(){var a=Qc;return a.gcq=a.gcq||new Ki}
var Li=function(a,b,c){Ji().register(a,b,c)},Mi=function(a,b,c,d){Ji().push("event",[b,a],c,d)},Ni=function(a,b){Ji().push("config",[a],b)},Oi={},Pi=function(a){return!0},Qi=function(){this.status=1;this.containerConfig={};this.targetConfig={};this.i={};this.m=null;this.h=!1},Ri=function(a,b,c,d,e){this.type=a;this.m=b;this.Y=c||"";
this.h=d;this.i=e},Ki=function(){this.m={};this.i={};this.h=[]},Si=function(a,b){var c=Rd(b);return a.m[c.containerId]=a.m[c.containerId]||new Qi},Ti=function(a,b,c){if(b){var d=Rd(b);if(d&&1===Si(a,b).status&&Pi(d.prefix)){Si(a,b).status=2;var e={};vd&&(e.timeoutId=D.setTimeout(function(){J("GTM",38);gd()},3E3));a.push("require",[e],d.containerId);Oi[d.containerId]=Ga();if(Ud()){}else{var h="/gtag/js?id="+encodeURIComponent(d.containerId)+"&l=dataLayer&cx=c",k=("http:"!=D.location.protocol?"https:":"http:")+("//www.googletagmanager.com"+h),l=Gf(c,h)||k;kc(l)}}}},Ui=function(a,b,c,d){if(d.Y){var e=Si(a,d.Y),
f=e.m;if(f){var h=C(c),k=C(e.targetConfig[d.Y]),l=C(e.containerConfig),m=C(e.i),q=C(a.i),r=Fd("gtm.uniqueEventId"),u=Rd(d.Y).prefix,p=Pf(Of(Nf(Mf(Lf(Kf(Jf(h),k),l),m),q),function(){zd(r,u,"2");}),function(){zd(r,u,"3");});try{zd(r,u,"1");f(d.Y,b,d.m,p)}catch(t){
zd(r,u,"4");}}}};
Ki.prototype.register=function(a,b,c){if(3!==Si(this,a).status){Si(this,a).m=b;Si(this,a).status=3;c&&(Si(this,a).i=c);var d=Rd(a),e=Oi[d.containerId];if(void 0!==e){var f=Qc[d.containerId].bootstrap,h=d.prefix.toUpperCase();Qc[d.containerId]._spx&&(h=h.toLowerCase());var k=Fd("gtm.uniqueEventId"),l=h,m=Ga()-f;if(vd&&!md[k]){k!==id&&(fd(),id=k);var q=l+"."+Math.floor(f-e)+"."+Math.floor(m);rd=rd?rd+","+q:"&cl="+q}delete Oi[d.containerId]}this.flush()}};
Ki.prototype.push=function(a,b,c,d){var e=Math.floor(Ga()/1E3);Ti(this,c,b[0][Q.xa]||this.i[Q.xa]);this.h.push(new Ri(a,e,c,b,d));d||this.flush()};
Ki.prototype.flush=function(a){for(var b=this;this.h.length;){var c=this.h[0];if(c.i)c.i=!1,this.h.push(c);else switch(c.type){case "require":if(3!==Si(this,c.Y).status&&!a)return;vd&&D.clearTimeout(c.h[0].timeoutId);break;case "set":Aa(c.h[0],function(l,m){C(Ma(l,m),b.i)});break;case "config":var d=c.h[0],e=!!d[Q.bc];delete d[Q.bc];var f=Si(this,c.Y),h=Rd(c.Y),k=h.containerId===h.id;e||(k?f.containerConfig={}:f.targetConfig[c.Y]={});f.h&&e||Ui(this,Q.D,d,c);f.h=!0;delete d[Q.ra];k?C(d,f.containerConfig):
C(d,f.targetConfig[c.Y]);break;case "event":Ui(this,c.h[1],c.h[0],c)}this.h.shift()}};var Vi=["GP","G"],Wi="G".split(/,/);Wi.push("GF");Wi.push("HA");var Xi=!1;Xi=!0;var Yi=null,Zi={},$i={},aj;function bj(a,b){var c={event:a};b&&(c.eventModel=C(b),b[Q.yc]&&(c.eventCallback=b[Q.yc]),b[Q.Fb]&&(c.eventTimeout=b[Q.Fb]));return c}
var hj={config:function(a){},event:function(a){var b=a[1];if(g(b)&&!(3<a.length)){var c;if(2<a.length){if(!Ra(a[2])&&void 0!=a[2])return;c=a[2]}var d=bj(b,c);return d}},js:function(a){if(2==a.length&&a[1].getTime)return{event:"gtm.js","gtm.start":a[1].getTime()}},policy:function(){},set:function(a){var b;2==a.length&&Ra(a[1])?b=C(a[1]):3==a.length&&
g(a[1])&&(b={},Ra(a[2])||sa(a[2])?b[a[1]]=C(a[2]):b[a[1]]=a[2]);if(b){b._clear=!0;return b}}};var ij={policy:!0};var jj=function(a,b){var c=a.hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var d=!0,e;for(e in c)if(c.hasOwnProperty(e)&&!0===c[e]){d=!1;break}d&&(c.end(),c.end=null)}},lj=function(a){var b=kj(),c=b&&b.hide;c&&c.end&&(c[a]=!0)};var mj=!1,nj=[];function oj(){if(!mj){mj=!0;for(var a=0;a<nj.length;a++)H(nj[a])}}var pj=function(a){mj?H(a):nj.push(a)};var Hj=function(a){if(Gj(a))return a;this.h=a};Hj.prototype.zg=function(){return this.h};var Gj=function(a){return!a||"object"!==Pa(a)||Ra(a)?!1:"getUntrustedUpdateValue"in a};Hj.prototype.getUntrustedUpdateValue=Hj.prototype.zg;var Ij=[],Jj=!1,Kj=function(a){return D["dataLayer"].push(a)},Lj=function(a){var b=Qc["dataLayer"],c=b?b.subscribers:1,d=0;return function(){++d===c&&a()}};
function Mj(a){var b=a._clear;Aa(a,function(f,h){"_clear"!==f&&(b&&Jd(f,void 0),Jd(f,h))});Vc||(Vc=a["gtm.start"]);var c=a.event;if(!c)return!1;var d=a["gtm.uniqueEventId"];d||(d=ad(),a["gtm.uniqueEventId"]=d,Jd("gtm.uniqueEventId",d));Xc=c;var e=Nj(a);Xc=null;switch(c){case "gtm.init":J("GTM",19),e&&J("GTM",20)}return e}
function Nj(a){var b=a.event,c=a["gtm.uniqueEventId"],d,e=Qc.zones;d=e?e.checkState(I.s,c):pe;return d.active?of(c,b,d.isWhitelisted,a.eventCallback,a.eventTimeout)?!0:!1:!1}
function Oj(){for(var a=!1;!Jj&&0<Ij.length;){Jj=!0;delete Cd.eventModel;Ed();var b=Ij.shift();if(null!=b){var c=Gj(b);if(c){var d=b;b=Gj(d)?d.getUntrustedUpdateValue():void 0;for(var e=["gtm.whitelist","gtm.blacklist","tagTypeBlacklist"],f=0;f<e.length;f++){var h=e[f],k=Fd(h,1);if(sa(k)||Ra(k))k=C(k);Dd[h]=k}}try{if(qa(b))try{b.call(Gd)}catch(v){}else if(sa(b)){var l=b;if(g(l[0])){var m=
l[0].split("."),q=m.pop(),r=l.slice(1),u=Fd(m.join("."),2);if(void 0!==u&&null!==u)try{u[q].apply(u,r)}catch(v){}}}else{var p=b;if(p&&("[object Arguments]"==Object.prototype.toString.call(p)||Object.prototype.hasOwnProperty.call(p,"callee"))){a:{if(b.length&&g(b[0])){var t=hj[b[0]];if(t&&(!c||!ij[b[0]])){b=t(b);break a}}b=void 0}if(!b){Jj=!1;continue}}a=Mj(b)||a}}finally{c&&Ed(!0)}}Jj=!1}
return!a}function Pj(){var a=Oj();try{jj(D["dataLayer"],I.s)}catch(b){}return a}
var Rj=function(){var a=ic("dataLayer",[]),b=ic("google_tag_manager",{});b=b["dataLayer"]=b["dataLayer"]||{};xe(function(){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))});pj(function(){b.gtmLoad||(b.gtmLoad=!0,a.push({event:"gtm.load"}))});b.subscribers=(b.subscribers||0)+1;var c=a.push;a.push=function(){var d;if(0<Qc.SANDBOXED_JS_SEMAPHORE){d=[];for(var e=0;e<arguments.length;e++)d[e]=new Hj(arguments[e])}else d=[].slice.call(arguments,0);var f=c.apply(a,d);Ij.push.apply(Ij,d);if(300<
this.length)for(J("GTM",4);300<this.length;)this.shift();var h="boolean"!==typeof f||f;return Oj()&&h};Ij.push.apply(Ij,a.slice(0));Qj()&&H(Pj)},Qj=function(){var a=!0;return a};var Sj={};Sj.Gb=new String("undefined");
var Tj=function(a){this.h=function(b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]===Sj.Gb?b:a[d]);return c.join("")}};Tj.prototype.toString=function(){return this.h("undefined")};Tj.prototype.valueOf=Tj.prototype.toString;Sj.Df=Tj;Sj.Hc={};Sj.ig=function(a){return new Tj(a)};var Uj={};Sj.jh=function(a,b){var c=ad();Uj[c]=[a,b];return c};Sj.ke=function(a){var b=a?0:1;return function(c){var d=Uj[c];if(d&&"function"===typeof d[b])d[b]();Uj[c]=void 0}};Sj.Ig=function(a){for(var b=!1,c=!1,d=2;d<a.length;d++)b=
b||8===a[d],c=c||16===a[d];return b&&c};Sj.$g=function(a){if(a===Sj.Gb)return a;var b=ad();Sj.Hc[b]=a;return'google_tag_manager["'+I.s+'"].macro('+b+")"};Sj.Sg=function(a,b,c){a instanceof Sj.Df&&(a=a.h(Sj.jh(b,c)),b=pa);return{Tc:a,C:b}};var Vj=function(a,b,c){function d(f,h){var k=f[h];return k}var e={event:b,"gtm.element":a,"gtm.elementClasses":d(a,"className"),"gtm.elementId":a["for"]||qc(a,"id")||"","gtm.elementTarget":a.formTarget||d(a,"target")||""};c&&(e["gtm.triggers"]=c.join(","));e["gtm.elementUrl"]=(a.attributes&&a.attributes.formaction?a.formAction:"")||a.action||d(a,"href")||a.src||a.code||a.codebase||
"";return e},Wj=function(a){Qc.hasOwnProperty("autoEventsSettings")||(Qc.autoEventsSettings={});var b=Qc.autoEventsSettings;b.hasOwnProperty(a)||(b[a]={});return b[a]},Xj=function(a,b,c){Wj(a)[b]=c},Yj=function(a,b,c,d){var e=Wj(a),f=Ha(e,b,d);e[b]=c(f)},Zj=function(a,b,c){var d=Wj(a);return Ha(d,b,c)};var ak=["input","select","textarea"],bk=["button","hidden","image","reset","submit"],ck=function(a){var b=a.tagName.toLowerCase();return!wa(ak,function(c){return c===b})||"input"===b&&wa(bk,function(c){return c===a.type.toLowerCase()})?!1:!0},dk=function(a){return a.form?a.form.tagName?a.form:E.getElementById(a.form):tc(a,["form"],100)},ek=function(a,b,c){if(!a.elements)return 0;for(var d=b.getAttribute(c),e=0,f=1;e<a.elements.length;e++){var h=a.elements[e];if(ck(h)){if(h.getAttribute(c)===d)return f;
f++}}return 0};var fk=!!D.MutationObserver,gk=void 0,hk=function(a){if(!gk){var b=function(){var c=E.body;if(c)if(fk)(new MutationObserver(function(){for(var e=0;e<gk.length;e++)H(gk[e])})).observe(c,{childList:!0,subtree:!0});else{var d=!1;oc(c,"DOMNodeInserted",function(){d||(d=!0,H(function(){d=!1;for(var e=0;e<gk.length;e++)H(gk[e])}))})}};gk=[];E.body?b():H(b)}gk.push(a)};
var sk=function(){var a=E.body,b=E.documentElement||a&&a.parentElement,c,d;if(E.compatMode&&"BackCompat"!==E.compatMode)c=b?b.clientHeight:0,d=b?b.clientWidth:0;else{var e=function(f,h){return f&&h?Math.min(f,h):Math.max(f,h)};J("GTM",7);c=e(b?b.clientHeight:0,a?a.clientHeight:0);d=e(b?b.clientWidth:0,a?a.clientWidth:0)}return{width:d,height:c}},tk=function(a){var b=sk(),c=b.height,d=b.width,e=a.getBoundingClientRect(),f=e.bottom-e.top,h=e.right-e.left;return f&&h?(1-Math.min((Math.max(0-e.left,0)+
Math.max(e.right-d,0))/h,1))*(1-Math.min((Math.max(0-e.top,0)+Math.max(e.bottom-c,0))/f,1)):0},uk=function(a){if(E.hidden)return!0;var b=a.getBoundingClientRect();if(b.top==b.bottom||b.left==b.right||!D.getComputedStyle)return!0;var c=D.getComputedStyle(a,null);if("hidden"===c.visibility)return!0;for(var d=a,e=c;d;){if("none"===e.display)return!0;var f=e.opacity,h=e.filter;if(h){var k=h.indexOf("opacity(");0<=k&&(h=h.substring(k+8,h.indexOf(")",k)),"%"==h.charAt(h.length-1)&&(h=h.substring(0,h.length-
1)),f=Math.min(h,f))}if(void 0!==f&&0>=f)return!0;(d=d.parentElement)&&(e=D.getComputedStyle(d,null))}return!1};var vk=[],wk=!(!D.IntersectionObserver||!D.IntersectionObserverEntry),xk=function(a,b,c){for(var d=new D.IntersectionObserver(a,{threshold:c}),e=0;e<b.length;e++)d.observe(b[e]);for(var f=0;f<vk.length;f++)if(!vk[f])return vk[f]=d,f;return vk.push(d)-1},yk=function(a,b,c){function d(k,l){var m={top:0,bottom:0,right:0,left:0,width:0,
height:0},q={boundingClientRect:k.getBoundingClientRect(),intersectionRatio:l,intersectionRect:m,isIntersecting:0<l,rootBounds:m,target:k,time:Ga()};H(function(){return a(q)})}for(var e=[],f=[],h=0;h<b.length;h++)e.push(0),f.push(-1);c.sort(function(k,l){return k-l});return function(){for(var k=0;k<b.length;k++){var l=tk(b[k]);if(l>e[k])for(;f[k]<c.length-1&&l>=c[f[k]+1];)d(b[k],l),f[k]++;else if(l<e[k])for(;0<=f[k]&&l<=c[f[k]];)d(b[k],l),f[k]--;e[k]=l}}},zk=function(a,b,c){for(var d=0;d<c.length;d++)1<
c[d]?c[d]=1:0>c[d]&&(c[d]=0);if(wk){var e=!1;H(function(){e||yk(a,b,c)()});return xk(function(f){e=!0;for(var h={Wa:0};h.Wa<f.length;h={Wa:h.Wa},h.Wa++)H(function(k){return function(){return a(f[k.Wa])}}(h))},b,c)}return D.setInterval(yk(a,b,c),1E3)},Ak=function(a){wk?0<=a&&a<vk.length&&vk[a]&&(vk[a].disconnect(),vk[a]=void 0):D.clearInterval(a)};
var Bk=function(a,b,c){function d(){var h=a();f+=e?(Ga()-e)*h.playbackRate/1E3:0;e=Ga()}var e=0,f=0;return{Tb:function(h,k,l){var m=a(),q=m.me,r=void 0!==l?Math.round(l):void 0!==k?Math.round(m.me*k):Math.round(m.jg),u=void 0!==k?Math.round(100*k):0>=q?0:Math.round(r/q*100),p=E.hidden?!1:.5<=tk(c);d();var t=Vj(c,"gtm.video",[b]);t["gtm.videoProvider"]="youtube";t["gtm.videoStatus"]=h;t["gtm.videoUrl"]=m.url;t["gtm.videoTitle"]=m.title;t["gtm.videoDuration"]=Math.round(q);t["gtm.videoCurrentTime"]=
Math.round(r);t["gtm.videoElapsedTime"]=Math.round(f);t["gtm.videoPercent"]=u;t["gtm.videoVisible"]=p;Kj(t)},lh:function(){e=Ga()},Ic:function(){d()}}};var Ck=D.clearTimeout,Dk=D.setTimeout,U=function(a,b,c){if(Ud()){b&&H(b)}else return kc(a,b,c)},Ek=function(){return D.location.href},Fk=function(a){return Xe(Ze(a),"fragment")},Gk=function(a){return Ye(Ze(a))},V=function(a,b){return Fd(a,b||2)},Hk=function(a,b,c){var d;b?(a.eventCallback=b,c&&(a.eventTimeout=c),d=Kj(a)):d=Kj(a);return d},Ik=function(a,b){D[a]=b},W=function(a,b,c){b&&(void 0===D[a]||c&&!D[a])&&(D[a]=
b);return D[a]},Jk=function(a,b,c){return Vf(a,b,void 0===c?!0:!!c)},Kk=function(a,b){if(Ud()){b&&H(b)}else mc(a,b)},Lk=function(a){return!!Zj(a,"init",!1)},Mk=function(a){Xj(a,"init",!0)},Nk=function(a,b){var c=(void 0===b?0:b)?"www.googletagmanager.com/gtag/js":Uc;c+="?id="+encodeURIComponent(a)+"&l=dataLayer";U(T("https://","http://",c))},Ok=function(a,b){var c=a[b];return c};
var Pk=Sj.Sg;var ll=new ya;function ml(a,b){function c(h){var k=Ze(h),l=Xe(k,"protocol"),m=Xe(k,"host",!0),q=Xe(k,"port"),r=Xe(k,"path").toLowerCase().replace(/\/$/,"");if(void 0===l||"http"==l&&"80"==q||"https"==l&&"443"==q)l="web",q="default";return[l,m,q,r]}for(var d=c(String(a)),e=c(String(b)),f=0;f<d.length;f++)if(d[f]!==e[f])return!1;return!0}
function nl(a){return ol(a)?1:0}
function ol(a){var b=a.arg0,c=a.arg1;if(a.any_of&&sa(c)){for(var d=0;d<c.length;d++)if(nl({"function":a["function"],arg0:b,arg1:c[d]}))return!0;return!1}switch(a["function"]){case "_cn":return 0<=String(b).indexOf(String(c));case "_css":var e;a:{if(b){var f=["matches","webkitMatchesSelector","mozMatchesSelector","msMatchesSelector","oMatchesSelector"];try{for(var h=0;h<f.length;h++)if(b[f[h]]){e=b[f[h]](c);break a}}catch(v){}}e=!1}return e;case "_ew":var k,l;k=String(b);l=String(c);var m=k.length-
l.length;return 0<=m&&k.indexOf(l,m)==m;case "_eq":return String(b)==String(c);case "_ge":return Number(b)>=Number(c);case "_gt":return Number(b)>Number(c);case "_lc":var q;q=String(b).split(",");return 0<=n(q,String(c));case "_le":return Number(b)<=Number(c);case "_lt":return Number(b)<Number(c);case "_re":var r;var u=a.ignore_case?"i":void 0;try{var p=String(c)+u,t=ll.get(p);t||(t=new RegExp(c,u),ll.set(p,t));r=t.test(b)}catch(v){r=!1}return r;case "_sw":return 0==String(b).indexOf(String(c));case "_um":return ml(b,
c)}return!1};var pl=function(a,b){var c=function(){};c.prototype=a.prototype;var d=new c;a.apply(d,Array.prototype.slice.call(arguments,1));return d};var ql={},rl=encodeURI,X=encodeURIComponent,sl=nc;var tl=function(a,b){if(!a)return!1;var c=Xe(Ze(a),"host");if(!c)return!1;for(var d=0;b&&d<b.length;d++){var e=b[d]&&b[d].toLowerCase();if(e){var f=c.length-e.length;0<f&&"."!=e.charAt(0)&&(f--,e="."+e);if(0<=f&&c.indexOf(e,f)==f)return!0}}return!1};
var ul=function(a,b,c){for(var d={},e=!1,f=0;a&&f<a.length;f++)a[f]&&a[f].hasOwnProperty(b)&&a[f].hasOwnProperty(c)&&(d[a[f][b]]=a[f][c],e=!0);return e?d:null};ql.Jg=function(){var a=!1;return a};var Im=function(){var a=D.gaGlobal=D.gaGlobal||{};a.hid=a.hid||xa();return a.hid};var Tm=window,Um=document,Vm=function(a){var b=Tm._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a&&!0===Tm["ga-disable-"+a])return!0;try{var c=Tm.external;if(c&&c._gaUserPrefs&&"oo"==c._gaUserPrefs)return!0}catch(f){}for(var d=Rf("AMP_TOKEN",String(Um.cookie),!0),e=0;e<d.length;e++)if("$OPT_OUT"==d[e])return!0;return Um.getElementById("__gaOptOutExtension")?!0:!1};
var Ym=function(a){Aa(a,function(c){"_"===c.charAt(0)&&delete a[c]});var b=a[Q.ja]||{};Aa(b,function(c){"_"===c.charAt(0)&&delete b[c]})};var bn=function(a,b,c){Mi(b,c,a)},cn=function(a,b,c){Mi(b,c,a,!0)},en=function(a,b){};
function dn(a,b){}var Y={a:{}};

Y.a.sdl=["google"],function(){function a(){return!!(Object.keys(l("horiz.pix")).length||Object.keys(l("horiz.pct")).length||Object.keys(l("vert.pix")).length||Object.keys(l("vert.pct")).length)}function b(y){for(var B=[],z=y.split(","),A=0;A<z.length;A++){var F=Number(z[A]);if(isNaN(F))return[];q.test(z[A])||B.push(F)}return B}function c(){var y=0,B=0;return function(){var z=sk(),A=z.height;y=Math.max(v.scrollLeft+z.width,y);B=Math.max(v.scrollTop+A,B);return{lg:y,mg:B}}}function d(){p=W("self");
t=p.document;v=t.scrollingElement||t.body&&t.body.parentNode;x=c()}function e(y,B,z,A){var F=l(B),G={},L;for(L in F){G.Ga=L;if(F.hasOwnProperty(G.Ga)){var R=Number(G.Ga);y<R||(Hk({event:"gtm.scrollDepth","gtm.scrollThreshold":R,"gtm.scrollUnits":z.toLowerCase(),"gtm.scrollDirection":A,"gtm.triggers":F[G.Ga].join(",")}),Yj("sdl",B,function(aa){return function(ba){delete ba[aa.Ga];return ba}}(G),{}))}G={Ga:G.Ga}}}function f(){var y=x(),B=y.lg,z=y.mg,A=B/v.scrollWidth*100,F=z/v.scrollHeight*100;e(B,
"horiz.pix",r.Ib,u.Ed);e(A,"horiz.pct",r.Hb,u.Ed);e(z,"vert.pix",r.Ib,u.Yd);e(F,"vert.pct",r.Hb,u.Yd);Xj("sdl","pending",!1)}function h(){var y=250,B=!1;t.scrollingElement&&t.documentElement&&p.addEventListener&&(y=50,B=!0);var z=0,A=!1,F=function(){A?z=Dk(F,y):(z=0,f(),Lk("sdl")&&!a()&&(pc(p,"scroll",G),pc(p,"resize",G),Xj("sdl","init",!1)));A=!1},G=function(){B&&x();z?A=!0:(z=Dk(F,y),Xj("sdl","pending",!0))};return G}function k(y,B,z){if(B){var A=b(String(y));Yj("sdl",z,function(F){for(var G=0;G<
A.length;G++){var L=String(A[G]);F.hasOwnProperty(L)||(F[L]=[]);F[L].push(B)}return F},{})}}function l(y){return Zj("sdl",y,{})}function m(y){H(y.vtp_gtmOnSuccess);var B=y.vtp_uniqueTriggerId,z=y.vtp_horizontalThresholdsPixels,A=y.vtp_horizontalThresholdsPercent,F=y.vtp_verticalThresholdUnits,G=y.vtp_verticalThresholdsPixels,L=y.vtp_verticalThresholdsPercent;switch(y.vtp_horizontalThresholdUnits){case r.Ib:k(z,B,"horiz.pix");break;case r.Hb:k(A,B,"horiz.pct")}switch(F){case r.Ib:k(G,B,"vert.pix");
break;case r.Hb:k(L,B,"vert.pct")}Lk("sdl")?Zj("sdl","pending")||(w||(d(),w=!0),H(function(){return f()})):(d(),w=!0,v&&(Mk("sdl"),Xj("sdl","pending",!0),H(function(){f();if(a()){var R=h();oc(p,"scroll",R);oc(p,"resize",R)}else Xj("sdl","init",!1)})))}var q=/^\s*$/,r={Hb:"PERCENT",Ib:"PIXELS"},u={Yd:"vertical",Ed:"horizontal"},p,t,v,w=!1,x;(function(y){Y.__sdl=y;Y.__sdl.b="sdl";Y.__sdl.g=!0;Y.__sdl.priorityOverride=0})(function(y){y.vtp_triggerStartOption?m(y):pj(function(){m(y)})})}();

Y.a.jsm=["customScripts"],function(){(function(a){Y.__jsm=a;Y.__jsm.b="jsm";Y.__jsm.g=!0;Y.__jsm.priorityOverride=0})(function(a){if(void 0!==a.vtp_javascript){var b=a.vtp_javascript;try{var c=W("google_tag_manager");return c&&c.e&&c.e(b)}catch(d){}}})}();
Y.a.sp=["google"],function(){(function(a){Y.__sp=a;Y.__sp.b="sp";Y.__sp.g=!0;Y.__sp.priorityOverride=0})(function(a){var b=-1==navigator.userAgent.toLowerCase().indexOf("firefox")?"//www.googleadservices.com/pagead/conversion_async.js":"https://www.google.com/pagead/conversion_async.js",c=a.vtp_gtmOnFailure;Ge();U(b,function(){var d=W("google_trackConversion");if(qa(d)){var e=
{};"DATA_LAYER"==a.vtp_customParamsFormat?e=a.vtp_dataLayerVariable:"USER_SPECIFIED"==a.vtp_customParamsFormat&&(e=ul(a.vtp_customParams,"key","value"));var f={};a.vtp_enableDynamicRemarketing&&(a.vtp_eventName&&(e.event=a.vtp_eventName),a.vtp_eventValue&&(f.value=a.vtp_eventValue),a.vtp_eventItems&&(f.items=a.vtp_eventItems));var h={google_conversion_id:a.vtp_conversionId,google_conversion_label:a.vtp_conversionLabel,google_custom_params:e,google_gtag_event_data:f,google_remarketing_only:!0,onload_callback:a.vtp_gtmOnSuccess,
google_gtm:rh()};a.vtp_rdp&&(h.google_restricted_data_processing=!0);a.vtp_userId&&(h.google_user_id=a.vtp_userId);d(h)||c()}else c()},c)})}();

Y.a.e=["google"],function(){(function(a){Y.__e=a;Y.__e.b="e";Y.__e.g=!0;Y.__e.priorityOverride=0})(function(a){return String(Ld(a.vtp_gtmEventId,"event"))})}();
Y.a.f=["google"],function(){(function(a){Y.__f=a;Y.__f.b="f";Y.__f.g=!0;Y.__f.priorityOverride=0})(function(a){var b=V("gtm.referrer",1)||E.referrer;return b?a.vtp_component&&"URL"!=a.vtp_component?Xe(Ze(String(b)),a.vtp_component,a.vtp_stripWww,a.vtp_defaultPages,a.vtp_queryKey):Gk(String(b)):String(b)})}();
Y.a.cl=["google"],function(){function a(b){var c=b.target;if(c){var d=Vj(c,"gtm.click");Hk(d)}}(function(b){Y.__cl=b;Y.__cl.b="cl";Y.__cl.g=!0;Y.__cl.priorityOverride=0})(function(b){if(!Lk("cl")){var c=W("document");oc(c,"click",a,!0);Mk("cl")}H(b.vtp_gtmOnSuccess)})}();Y.a.k=["google"],function(){(function(a){Y.__k=a;Y.__k.b="k";Y.__k.g=!0;Y.__k.priorityOverride=0})(function(a){return Jk(a.vtp_name,V("gtm.cookie",1),!!a.vtp_decodeCookie)[0]})}();

Y.a.u=["google"],function(){var a=function(b){return{toString:function(){return b}}};(function(b){Y.__u=b;Y.__u.b="u";Y.__u.g=!0;Y.__u.priorityOverride=0})(function(b){var c;b.vtp_customUrlSource?c=b.vtp_customUrlSource:c=V("gtm.url",1);c=c||Ek();var d=b[a("vtp_component")];if(!d||"URL"==d)return Gk(String(c));var e=Ze(String(c)),f;if("QUERY"===d)a:{var h=b[a("vtp_multiQueryKeys").toString()],k=b[a("vtp_queryKey").toString()]||"",l=b[a("vtp_ignoreEmptyQueryParam").toString()],m;h?sa(k)?m=k:m=String(k).replace(/\s+/g,
"").split(","):m=[String(k)];for(var q=0;q<m.length;q++){var r=Xe(e,"QUERY",void 0,void 0,m[q]);if(void 0!=r&&(!l||""!==r)){f=r;break a}}f=void 0}else f=Xe(e,d,"HOST"==d?b[a("vtp_stripWww")]:void 0,"PATH"==d?b[a("vtp_defaultPages")]:void 0,void 0);return f})}();
Y.a.v=["google"],function(){(function(a){Y.__v=a;Y.__v.b="v";Y.__v.g=!0;Y.__v.priorityOverride=0})(function(a){var b=a.vtp_name;if(!b||!b.replace)return!1;var c=V(b.replace(/\\\./g,"."),a.vtp_dataLayerVersion||1);return void 0!==c?c:a.vtp_defaultValue})}();
Y.a.tl=["google"],function(){function a(b){return function(){if(b.Yc&&b.$c>=b.Yc)b.Uc&&W("self").clearInterval(b.Uc);else{b.$c++;var c=(new Date).getTime();Hk({event:b.ca,"gtm.timerId":b.Uc,"gtm.timerEventNumber":b.$c,"gtm.timerInterval":b.interval,"gtm.timerLimit":b.Yc,"gtm.timerStartTime":b.Se,"gtm.timerCurrentTime":c,"gtm.timerElapsedTime":c-b.Se,"gtm.triggers":b.vh})}}}(function(b){Y.__tl=b;Y.__tl.b="tl";Y.__tl.g=!0;Y.__tl.priorityOverride=0})(function(b){H(b.vtp_gtmOnSuccess);if(!isNaN(b.vtp_interval)){var c=
{ca:b.vtp_eventName,$c:0,interval:Number(b.vtp_interval),Yc:isNaN(b.vtp_limit)?0:Number(b.vtp_limit),vh:String(b.vtp_uniqueTriggerId||"0"),Se:(new Date).getTime()};c.Uc=W("self").setInterval(a(c),0>Number(b.vtp_interval)?0:Number(b.vtp_interval))}})}();
Y.a.ua=["google"],function(){var a,b={},c=function(d){var e={},f={},h={},k={},l={},m=void 0;if(d.vtp_gaSettings){var q=d.vtp_gaSettings;C(ul(q.vtp_fieldsToSet,"fieldName","value"),f);C(ul(q.vtp_contentGroup,"index","group"),h);C(ul(q.vtp_dimension,"index","dimension"),k);C(ul(q.vtp_metric,"index","metric"),l);d.vtp_gaSettings=null;q.vtp_fieldsToSet=void 0;q.vtp_contentGroup=void 0;q.vtp_dimension=void 0;q.vtp_metric=void 0;var r=C(q);d=C(d,r)}C(ul(d.vtp_fieldsToSet,"fieldName","value"),f);C(ul(d.vtp_contentGroup,
"index","group"),h);C(ul(d.vtp_dimension,"index","dimension"),k);C(ul(d.vtp_metric,"index","metric"),l);var u=Ne(d.vtp_functionName);if(qa(u)){var p="",t="";d.vtp_setTrackerName&&"string"==typeof d.vtp_trackerName?""!==d.vtp_trackerName&&(t=d.vtp_trackerName,p=t+"."):(t="gtm"+ad(),p=t+".");var v={name:!0,clientId:!0,sampleRate:!0,
siteSpeedSampleRate:!0,alwaysSendReferrer:!0,allowAnchor:!0,allowLinker:!0,cookieName:!0,cookieDomain:!0,cookieExpires:!0,cookiePath:!0,cookieUpdate:!0,cookieFlags:!0,legacyCookieDomain:!0,legacyHistoryImport:!0,storage:!0,useAmpClientId:!0,storeGac:!0},w={allowAnchor:!0,allowLinker:!0,alwaysSendReferrer:!0,anonymizeIp:!0,cookieUpdate:!0,exFatal:!0,forceSSL:!0,javaEnabled:!0,legacyHistoryImport:!0,nonInteraction:!0,useAmpClientId:!0,useBeacon:!0,storeGac:!0,allowAdFeatures:!0,allowAdPersonalizationSignals:!0},
x=function(O){var K=[].slice.call(arguments,0);K[0]=p+K[0];u.apply(window,K)},y=function(O,K){return void 0===K?K:O(K)},B=function(O,K){if(K)for(var ua in K)K.hasOwnProperty(ua)&&x("set",O+ua,K[ua])},z=function(){var O=function(jn,uj,kn){if(!Ra(uj))return!1;for(var hd=Ha(Object(uj),kn,[]),qg=0;hd&&qg<hd.length;qg++)x(jn,hd[qg]);return!!hd&&0<hd.length},K;if(d.vtp_useEcommerceDataLayer){var ua=!1;ua||(K=V("ecommerce",1))}else d.vtp_ecommerceMacroData&&(K=d.vtp_ecommerceMacroData.ecommerce);if(!Ra(K))return;K=Object(K);var Qb=Ha(f,"currencyCode",K.currencyCode);void 0!==Qb&&x("set","&cu",Qb);O("ec:addImpression",K,"impressions");if(O("ec:addPromo",K[K.promoClick?"promoClick":"promoView"],"promotions")&&K.promoClick){x("ec:setAction","promo_click",K.promoClick.actionField);return}for(var Ea="detail checkout checkout_option click add remove purchase refund".split(" "),
ab="refund purchase remove checkout checkout_option add click detail".split(" "),bb=0;bb<Ea.length;bb++){var nb=K[Ea[bb]];if(nb){O("ec:addProduct",nb,"products");x("ec:setAction",Ea[bb],nb.actionField);if(vd)for(var zb=0;zb<ab.length;zb++){var Bc=K[ab[zb]];if(Bc){Bc!==nb&&J("GTM",13);break}}break}}},A=function(O,K,ua){var Qb=0;if(O)for(var Ea in O)if(O.hasOwnProperty(Ea)&&(ua&&v[Ea]||!ua&&void 0===v[Ea])){var ab=w[Ea]?Ca(O[Ea]):O[Ea];
"anonymizeIp"!=Ea||ab||(ab=void 0);K[Ea]=ab;Qb++}return Qb},F={name:t};A(f,F,!0);u("create",d.vtp_trackingId||e.trackingId,F);x("set","&gtm",rh(!0));
d.vtp_enableRecaptcha&&x("require","recaptcha","recaptcha.js");(function(O,K){void 0!==d[K]&&x("set",O,d[K])})("nonInteraction","vtp_nonInteraction");B("contentGroup",h);B("dimension",k);B("metric",l);var G={};A(f,G,!1)&&x("set",G);var L;d.vtp_enableLinkId&&x("require","linkid","linkid.js");x("set","hitCallback",function(){var O=
f&&f.hitCallback;qa(O)&&O();d.vtp_gtmOnSuccess()});if("TRACK_EVENT"==d.vtp_trackType){d.vtp_enableEcommerce&&(x("require","ec","ec.js"),z());var R={hitType:"event",eventCategory:String(d.vtp_eventCategory||e.category),eventAction:String(d.vtp_eventAction||e.action),eventLabel:y(String,d.vtp_eventLabel||e.label),eventValue:y(Ba,d.vtp_eventValue||e.value)};A(L,R,!1);x("send",R);}else if("TRACK_SOCIAL"==
d.vtp_trackType){}else if("TRACK_TRANSACTION"==d.vtp_trackType){}else if("TRACK_TIMING"==d.vtp_trackType){}else if("DECORATE_LINK"==d.vtp_trackType){}else if("DECORATE_FORM"==d.vtp_trackType){}else if("TRACK_DATA"==d.vtp_trackType){}else{d.vtp_enableEcommerce&&(x("require","ec","ec.js"),z());if(d.vtp_doubleClick||"DISPLAY_FEATURES"==d.vtp_advertisingFeaturesType){var ta="_dc_gtm_"+String(d.vtp_trackingId).replace(/[^A-Za-z0-9-]/g,"");x("require",
"displayfeatures",void 0,{cookieName:ta})}if("DISPLAY_FEATURES_WITH_REMARKETING_LISTS"==d.vtp_advertisingFeaturesType){var oa="_dc_gtm_"+String(d.vtp_trackingId).replace(/[^A-Za-z0-9-]/g,"");x("require","adfeatures",{cookieName:oa})}L?x("send","pageview",L):x("send","pageview");d.vtp_autoLinkDomains&&Oe(p,d.vtp_autoLinkDomains,!!d.vtp_useHashAutoLink,!!d.vtp_decorateFormsAutoLink);}if(!a){var va=
d.vtp_useDebugVersion?"u/analytics_debug.js":"analytics.js";d.vtp_useInternalVersion&&!d.vtp_useDebugVersion&&(va="internal/"+va);a=!0;var cb=T("https:","http:","//www.google-analytics.com/"+va,f&&f.forceSSL);U(cb,function(){var O=Le();O&&O.loaded||d.vtp_gtmOnFailure();},d.vtp_gtmOnFailure)}}else H(d.vtp_gtmOnFailure)};Y.__ua=c;Y.__ua.b="ua";Y.__ua.g=!0;Y.__ua.priorityOverride=0}();



Y.a.ytl=["google"],function(){function a(){var w=Math.round(1E9*Math.random())+"";return E.getElementById(w)?a():w}function b(w,x){if(!w)return!1;for(var y=0;y<u.length;y++)if(0<=w.indexOf("//"+u[y]+"/"+x))return!0;return!1}function c(w){var x=-1!==w.indexOf("?")?"&":"?";if(-1<w.indexOf("origin="))return w+x+"enablejsapi=1";if(!t){var y=W("document");t=y.location.protocol+"//"+y.location.hostname;y.location.port&&(t+=":"+y.location.port)}return w+x+"enablejsapi=1&origin="+encodeURIComponent(t)}function d(w,
x){var y=w.getAttribute("src");if(b(y,"embed/")){if(0<y.indexOf("enablejsapi=1"))return!0;if(x)return w.setAttribute("src",c(y)),!0}return!1}function e(w,x){if(!w.getAttribute("data-gtm-yt-inspected-"+x.od)&&(w.setAttribute("data-gtm-yt-inspected-"+x.od,"true"),d(w,x.te))){w.id||(w.id=a());var y=W("YT"),B=y.get(w.id);B||(B=new y.Player(w.id));var z=h(B,x),A={},F;for(F in z)A.Xa=F,z.hasOwnProperty(A.Xa)&&B.addEventListener(A.Xa,function(G){return function(L){return z[G.Xa](L.data)}}(A)),A={Xa:A.Xa}}}
function f(w){H(function(){function x(){for(var B=y.getElementsByTagName("iframe"),z=B.length,A=0;A<z;A++)e(B[A],w)}var y=W("document");x();hk(x)})}function h(w,x){var y,B;function z(){Z=Bk(function(){return{url:P,title:S,me:N,jg:w.getCurrentTime(),playbackRate:ta}},x.od,w.getIframe());N=0;S=P="";ta=1;return A}function A(O){switch(O){case p.PLAYING:N=Math.round(w.getDuration());P=w.getVideoUrl();if(w.getVideoData){var K=w.getVideoData();S=K?K.title:""}ta=w.getPlaybackRate();x.dg?Z.Tb("start"):Z.Ic();
M=m(x.bh,x.ah,w.getDuration());return F(O);default:return A}}function F(){oa=w.getCurrentTime();va=(new Date).getTime();Z.lh();ea();return G}function G(O){var K;switch(O){case p.ENDED:return R(O);case p.PAUSED:K="pause";case p.BUFFERING:var ua=w.getCurrentTime()-oa;K=1<Math.abs(((new Date).getTime()-va)/1E3*ta-ua)?"seek":K||"buffering";w.getCurrentTime()&&(x.cg?Z.Tb(K):Z.Ic());ba();return L;case p.UNSTARTED:return z(O);default:return G}}function L(O){switch(O){case p.ENDED:return R(O);case p.PLAYING:return F(O);
case p.UNSTARTED:return z(O);default:return L}}function R(){for(;B;){var O=y;Ck(B);O()}x.bg&&Z.Tb("complete",1);return z(p.UNSTARTED)}function aa(){}function ba(){B&&(Ck(B),B=0,y=aa)}function ea(){if(M.length&&0!==ta){var O=-1,K;do{K=M[0];if(K.Da>w.getDuration())return;O=(K.Da-w.getCurrentTime())/ta;if(0>O&&(M.shift(),0===M.length))return}while(0>O);y=function(){B=0;y=aa;0<M.length&&M[0].Da===K.Da&&(M.shift(),Z.Tb("progress",K.Le,K.Qe));ea()};B=Dk(y,1E3*O)}}var Z,M=[],N,P,S,ta,oa,va,cb=z(p.UNSTARTED);
B=0;y=aa;return{onStateChange:function(O){cb=cb(O)},onPlaybackRateChange:function(O){oa=w.getCurrentTime();va=(new Date).getTime();Z.Ic();ta=O;ba();ea()}}}function k(w){for(var x=w.split(","),y=x.length,B=[],z=0;z<y;z++){var A=parseInt(x[z],10);isNaN(A)||100<A||0>A||B.push(A/100)}B.sort(function(F,G){return F-G});return B}function l(w){for(var x=w.split(","),y=x.length,B=[],z=0;z<y;z++){var A=parseInt(x[z],10);isNaN(A)||0>A||B.push(A)}B.sort(function(F,G){return F-G});return B}function m(w,x,y){var B=
w.map(function(F){return{Da:F,Qe:F,Le:void 0}});if(!x.length)return B;var z=x.map(function(F){return{Da:F*y,Qe:void 0,Le:F}});if(!B.length)return z;var A=B.concat(z);A.sort(function(F,G){return F.Da-G.Da});return A}function q(w){w.vtp_triggerStartOption?r(w):xe(function(){r(w)})}function r(w){var x=!!w.vtp_captureStart,y=!!w.vtp_captureComplete,B=!!w.vtp_capturePause,z=k(w.vtp_progressThresholdsPercent+""),A=l(w.vtp_progressThresholdsTimeInSeconds+""),F=!!w.vtp_fixMissingApi;if(x||y||B||z.length||
A.length){var G={dg:x,bg:y,cg:B,ah:z,bh:A,te:F,od:void 0===w.vtp_uniqueTriggerId?"":w.vtp_uniqueTriggerId},L=W("YT"),R=function(){f(G)};H(w.vtp_gtmOnSuccess);if(L)L.ready&&L.ready(R);else{var aa=W("onYouTubeIframeAPIReady");Ik("onYouTubeIframeAPIReady",function(){aa&&aa();R()});H(function(){for(var ba=W("document"),ea=ba.getElementsByTagName("script"),Z=ea.length,M=0;M<Z;M++){var N=ea[M].getAttribute("src");if(b(N,"iframe_api")||b(N,"player_api"))return}for(var P=ba.getElementsByTagName("iframe"),
S=P.length,ta=0;ta<S;ta++)if(!v&&d(P[ta],G.te)){U("https://www.youtube.com/iframe_api");v=!0;break}})}}else H(w.vtp_gtmOnSuccess)}var u=["www.youtube.com","www.youtube-nocookie.com"],p={UNSTARTED:-1,ENDED:0,PLAYING:1,PAUSED:2,BUFFERING:3,CUED:5},t,v=!1;Y.__ytl=q;Y.__ytl.b="ytl";Y.__ytl.g=!0;Y.__ytl.priorityOverride=0}();


Y.a.gclidw=["google"],function(){var a=["aw","dc","gf","ha","gp"];(function(b){Y.__gclidw=b;Y.__gclidw.b="gclidw";Y.__gclidw.g=!0;Y.__gclidw.priorityOverride=100})(function(b){H(b.vtp_gtmOnSuccess);var c,d,e;b.vtp_enableCookieOverrides&&(e=b.vtp_cookiePrefix,c=b.vtp_path,d=b.vtp_domain);var f=null;b.vtp_enableCookieUpdateFeature&&(f=!0,void 0!==b.vtp_cookieUpdate&&(f=!!b.vtp_cookieUpdate));var h={prefix:e,path:c,domain:d};b.vtp_enableCrossDomainFeature&&(b.vtp_enableCrossDomain&&!1===b.vtp_acceptIncoming||
(b.vtp_enableCrossDomain||Qg())&&eh(a,h));bh(h);ih(["aw","dc"],h);Mh(f,h);var k=e;if(b.vtp_enableCrossDomainFeature&&b.vtp_enableCrossDomain&&b.vtp_linkerDomains){var l=b.vtp_linkerDomains.toString().replace(/\s+/g,"").split(","),m=b.vtp_urlPosition,q=!!b.vtp_formDecoration;gh(a,l,m,q,k);}nh();})}();


Y.a.aev=["google"],function(){function a(p,t){var v=Ld(p,"gtm");if(v)return v[t]}function b(p,t,v,w){w||(w="element");var x=p+"."+t,y;if(q.hasOwnProperty(x))y=q[x];else{var B=a(p,w);if(B&&(y=v(B),q[x]=y,r.push(x),35<r.length)){var z=r.shift();delete q[z]}}return y}function c(p,t,v){var w=a(p,u[t]);return void 0!==w?w:v}function d(p,t){if(!p)return!1;var v=e(Ek());sa(t)||(t=String(t||"").replace(/\s+/g,"").split(","));for(var w=[v],x=0;x<t.length;x++)if(t[x]instanceof RegExp){if(t[x].test(p))return!1}else{var y=
t[x];if(0!=y.length){if(0<=e(p).indexOf(y))return!1;w.push(e(y))}}return!tl(p,w)}function e(p){m.test(p)||(p="http://"+p);return Xe(Ze(p),"HOST",!0)}function f(p,t,v){switch(p){case "SUBMIT_TEXT":return b(t,"FORM."+p,h,"formSubmitElement")||v;case "LENGTH":var w=b(t,"FORM."+p,k);return void 0===w?v:w;case "INTERACTED_FIELD_ID":return l(t,"id",v);case "INTERACTED_FIELD_NAME":return l(t,"name",v);case "INTERACTED_FIELD_TYPE":return l(t,"type",v);case "INTERACTED_FIELD_POSITION":var x=a(t,"interactedFormFieldPosition");
return void 0===x?v:x;case "INTERACT_SEQUENCE_NUMBER":var y=a(t,"interactSequenceNumber");return void 0===y?v:y;default:return v}}function h(p){switch(p.tagName.toLowerCase()){case "input":return qc(p,"value");case "button":return rc(p);default:return null}}function k(p){if("form"===p.tagName.toLowerCase()&&p.elements){for(var t=0,v=0;v<p.elements.length;v++)ck(p.elements[v])&&t++;return t}}function l(p,t,v){var w=a(p,"interactedFormField");return w&&qc(w,t)||v}var m=/^https?:\/\//i,q={},r=[],u={ATTRIBUTE:"elementAttribute",
CLASSES:"elementClasses",ELEMENT:"element",ID:"elementId",HISTORY_CHANGE_SOURCE:"historyChangeSource",HISTORY_NEW_STATE:"newHistoryState",HISTORY_NEW_URL_FRAGMENT:"newUrlFragment",HISTORY_OLD_STATE:"oldHistoryState",HISTORY_OLD_URL_FRAGMENT:"oldUrlFragment",TARGET:"elementTarget"};(function(p){Y.__aev=p;Y.__aev.b="aev";Y.__aev.g=!0;Y.__aev.priorityOverride=0})(function(p){var t=p.vtp_gtmEventId,v=p.vtp_defaultValue,w=p.vtp_varType;switch(w){case "TAG_NAME":var x=a(t,"element");return x&&x.tagName||
v;case "TEXT":return b(t,w,rc)||v;case "URL":var y;a:{var B=String(a(t,"elementUrl")||v||""),z=Ze(B),A=String(p.vtp_component||"URL");switch(A){case "URL":y=B;break a;case "IS_OUTBOUND":y=d(B,p.vtp_affiliatedDomains);break a;default:y=Xe(z,A,p.vtp_stripWww,p.vtp_defaultPages,p.vtp_queryKey)}}return y;case "ATTRIBUTE":var F;if(void 0===p.vtp_attribute)F=c(t,w,v);else{var G=p.vtp_attribute,L=a(t,"element");F=L&&qc(L,G)||v||""}return F;case "MD":var R=p.vtp_mdValue,aa=b(t,"MD",ok);return R&&aa?rk(aa,
R)||v:aa||v;case "FORM":return f(String(p.vtp_component||"SUBMIT_TEXT"),t,v);default:return c(t,w,v)}})}();
Y.a.gas=["google"],function(){function a(b,c,d){b.vtp_fieldsToSet=b.vtp_fieldsToSet||[];var e=b[c];void 0!==e&&(b.vtp_fieldsToSet.push({fieldName:d,value:e}),delete b[c])}(function(b){Y.__gas=b;Y.__gas.b="gas";Y.__gas.g=!0;Y.__gas.priorityOverride=0})(function(b){var c=C(b),d=c;d[Hb.va]=null;d[Hb.ff]=null;c=d;a(c,"vtp_cookieDomain","cookieDomain");return c})}();


Y.a.hl=["google"],function(){function a(f){return f.target&&f.target.location&&f.target.location.href?f.target.location.href:Ek()}function b(f,h){oc(f,"hashchange",function(k){var l=a(k);h({source:"hashchange",state:null,url:Gk(l),L:Fk(l)})})}function c(f,h){oc(f,"popstate",function(k){var l=a(k);h({source:"popstate",state:k.state,url:Gk(l),L:Fk(l)})})}function d(f,h,k){var l=h.history,m=l[f];if(qa(m))try{l[f]=function(q,r,u){m.apply(l,[].slice.call(arguments,0));k({source:f,state:q,url:Gk(Ek()),
L:Fk(Ek())})}}catch(q){}}function e(){var f={source:null,state:W("history").state||null,url:Gk(Ek()),L:Fk(Ek())};return function(h){var k=f,l={};l[k.source]=!0;l[h.source]=!0;if(!l.popstate||!l.hashchange||k.L!=h.L){var m={event:"gtm.historyChange","gtm.historyChangeSource":h.source,"gtm.oldUrlFragment":f.L,"gtm.newUrlFragment":h.L,"gtm.oldHistoryState":f.state,"gtm.newHistoryState":h.state};m["gtm.oldUrl"]=f.url,m["gtm.newUrl"]=h.url;
f=h;Hk(m)}}}(function(f){Y.__hl=f;Y.__hl.b="hl";Y.__hl.g=!0;Y.__hl.priorityOverride=0})(function(f){var h=W("self");if(!Lk("hl")){var k=e();b(h,k);c(h,k);d("pushState",h,k);d("replaceState",h,k);Mk("hl")}H(f.vtp_gtmOnSuccess)})}();
Y.a.awct=["google"],function(){var a=!1,b=[],c=function(k){var l=W("google_trackConversion"),m=k.gtm_onFailure;"function"==typeof l?l(k)||m():m()},d=function(){for(;0<b.length;)c(b.shift())},e=function(){return function(){d();a=!1}},f=function(){return function(){d();b={push:c};}},h=function(k){Ge();var l={google_basket_transaction_type:"purchase",google_conversion_domain:"",google_conversion_id:k.vtp_conversionId,google_conversion_label:k.vtp_conversionLabel,
google_conversion_value:k.vtp_conversionValue||0,google_remarketing_only:!1,onload_callback:k.vtp_gtmOnSuccess,gtm_onFailure:k.vtp_gtmOnFailure,google_gtm:rh()};k.vtp_rdp&&(l.google_restricted_data_processing=!0);var m=function(w){return function(x,y,B){var z="DATA_LAYER"==w?V(B):k[y];z&&(l[x]=z)}},q=m("JSON");q("google_conversion_currency","vtp_currencyCode");q("google_conversion_order_id","vtp_orderId");k.vtp_enableProductReporting&&(q=m(k.vtp_productReportingDataSource),q("google_conversion_merchant_id",
"vtp_awMerchantId","aw_merchant_id"),q("google_basket_feed_country","vtp_awFeedCountry","aw_feed_country"),q("google_basket_feed_language","vtp_awFeedLanguage","aw_feed_language"),q("google_basket_discount","vtp_discount","discount"),q("google_conversion_items","vtp_items","items"),l.google_conversion_items&&l.google_conversion_items.map&&(l.google_conversion_items=l.google_conversion_items.map(function(w){return{value:w.price,quantity:w.quantity,item_id:w.id}})));var r=function(w,x){(l.google_additional_conversion_params=
l.google_additional_conversion_params||{})[w]=x},u=function(w){return function(x,y,B,z){var A="DATA_LAYER"==w?V(B):k[y];z(A)&&r(x,A)}},p=-1==navigator.userAgent.toLowerCase().indexOf("firefox")?"//www.googleadservices.com/pagead/conversion_async.js":"https://www.google.com/pagead/conversion_async.js";
k.vtp_enableNewCustomerReporting&&(q=u(k.vtp_newCustomerReportingDataSource),q("vdnc","vtp_awNewCustomer","new_customer",function(w){return void 0!=w&&""!==w}),q("vdltv","vtp_awCustomerLTV","customer_lifetime_value",function(w){return void 0!=w&&""!==w}));!k.hasOwnProperty("vtp_enableConversionLinker")||k.vtp_enableConversionLinker?(k.vtp_conversionCookiePrefix&&(l.google_gcl_cookie_prefix=k.vtp_conversionCookiePrefix),l.google_read_gcl_cookie_opt_out=!1):l.google_read_gcl_cookie_opt_out=!0;var v=
!0;v&&b.push(l);a||(a=!0,U(p,f(),e(p)))};
Y.__awct=h;Y.__awct.b="awct";Y.__awct.g=!0;Y.__awct.priorityOverride=0}();
Y.a.bzi=["nonGoogleScripts"],function(){(function(a){Y.__bzi=a;Y.__bzi.b="bzi";Y.__bzi.g=!0;Y.__bzi.priorityOverride=0})(function(a){D._linkedin_data_partner_id=a.vtp_id;U("https://snap.licdn.com/li.lms-analytics/insight.min.js",a.vtp_gtmOnSuccess,a.vtp_gtmOnFailure)})}();Y.a.remm=["google"],function(){(function(a){Y.__remm=a;Y.__remm.b="remm";Y.__remm.g=!0;Y.__remm.priorityOverride=0})(function(a){for(var b=a.vtp_input,c=a.vtp_map||[],d=a.vtp_fullMatch,e=a.vtp_ignoreCase?"gi":"g",f=0;f<c.length;f++){var h=c[f].key||"";d&&(h="^"+h+"$");var k=new RegExp(h,e);if(k.test(b)){var l=c[f].value;a.vtp_replaceAfterMatch&&(l=String(b).replace(k,l));return l}}return a.vtp_defaultValue})}();

Y.a.baut=["nonGoogleScripts"],function(){var a=!1,b=function(c){var d=c.vtp_uetqName||"uetq",e=W(d,[],!0);if("VARIABLE_REVENUE"==c.vtp_eventType)e.push({gv:c.vtp_goalValue}),c.vtp_gtmOnSuccess();else if("CUSTOM"==c.vtp_eventType){var f={},h=function(k,l){void 0!==c[k]&&(f[l]=c[k])};h("vtp_goalValue","gv");h("vtp_eventCategory","ec");h("vtp_eventAction","ea");h("vtp_eventLabel","el");h("vtp_eventValue","ev");e.push(f);c.vtp_gtmOnSuccess()}else if(a)c.vtp_gtmOnSuccess();else try{U("//bat.bing.com/bat.js",
function(){var k=pl(W("UET"),{ti:c.vtp_tagId,q:e});D[d]=k;k.push("pageLoad");c.vtp_gtmOnSuccess()},c.vtp_gtmOnFailure),a=!0}catch(k){H(c.vtp_gtmOnFailure)}};Y.__baut=b;Y.__baut.b="baut";Y.__baut.g=!0;Y.__baut.priorityOverride=0}();Y.a.smm=["google"],function(){(function(a){Y.__smm=a;Y.__smm.b="smm";Y.__smm.g=!0;Y.__smm.priorityOverride=0})(function(a){var b=a.vtp_input,c=ul(a.vtp_map,"key","value")||{};return c.hasOwnProperty(b)?c[b]:a.vtp_defaultValue})}();




Y.a.paused=[],function(){(function(a){Y.__paused=a;Y.__paused.b="paused";Y.__paused.g=!0;Y.__paused.priorityOverride=0})(function(a){H(a.vtp_gtmOnFailure)})}();
Y.a.zone=[],function(){function a(r){for(var u=r.vtp_boundaries||[],p=0;p<u.length;p++)if(!u[p])return!1;return!0}function b(r){var u=I.s,p=u+":"+r.vtp_gtmTagId,t=V("gtm.uniqueEventId")||0,v=qe(function(){return new h}),w=a(r),x=r.vtp_enableTypeRestrictions?r.vtp_whitelistedTypes.map(function(G){return G.typeId}):null;x=x&&La(x,f);if(v.registerZone(p,t,w,x))for(var y=r.vtp_childContainers.map(function(G){return G.publicId}),B=0;B<y.length;B++){var z=String(y[B]);if(v.registerChild(z,u,p)){var A=0!==
z.indexOf("GTM-");if(A){var F=function(G,L){Hk(arguments)};F("js",new Date);m?(F("config",z),l||Nk(z,A)):Ni({},z)}else Nk(z,A)}}}var c={active:!1,isWhitelisted:function(){return!1}},d={active:!0,isWhitelisted:function(){return!0}},e={zone:!0,cn:!0,css:!0,ew:!0,eq:!0,ge:!0,gt:!0,lc:!0,le:!0,lt:!0,re:!0,sw:!0,um:!0},f={cl:["ecl"],ecl:["cl"],ehl:["hl"],hl:["ehl"]},h=function(){this.h={};this.i={}};h.prototype.checkState=function(r,u){var p=this.h[r];if(!p)return d;var t=this.checkState(p.Je,u);if(!t.active)return c;
for(var v=[],w=0;w<p.vd.length;w++){var x=this.i[p.vd[w]];x.sb(u)&&v.push(x)}return v.length?{active:!0,isWhitelisted:function(y,B){B=B||[];if(!t.isWhitelisted(y,B))return!1;for(var z=0;z<v.length;++z)if(v[z].isWhitelisted(y,B))return!0;return!1}}:c};h.prototype.unregisterChild=function(r){delete this.h[r]};h.prototype.registerZone=function(r,u,p,t){var v=this.i[r];if(v)return v.m(u,p),!1;if(!p)return!1;this.i[r]=new k(u,t);return!0};h.prototype.registerChild=function(r,u,p){var t=this.h[r];if(!t&&
Qc[r]||t&&t.Je!==u)return!1;if(t)return t.vd.push(p),!1;this.h[r]={Je:u,vd:[p]};return!0};var k=function(r,u){this.h=[{eventId:r,sb:!0}];this.i=null;if(u){this.i={};for(var p=0;p<u.length;p++)this.i[u[p]]=!0}};k.prototype.m=function(r,u){var p=this.h[this.h.length-1];r<=p.eventId||p.sb!=u&&this.h.push({eventId:r,sb:u})};k.prototype.sb=function(r){if(!this.h||0==this.h.length)return!1;for(var u=this.h.length-1;0<=u;u--)if(this.h[u].eventId<=r)return this.h[u].sb;return!1};k.prototype.isWhitelisted=
function(r,u){u=u||[];if(!this.i||e[r]||this.i[r])return!0;for(var p=0;p<u.length;++p)if(this.i[u[p]])return!0;return!1};var l=!1;var m=!0;var q=function(r){b(r);H(r.vtp_gtmOnSuccess)};Y.__zone=q;Y.__zone.b="zone";Y.__zone.g=!0;Y.__zone.priorityOverride=0}();
Y.a.html=["customScripts"],function(){function a(d,e,f,h){return function(){try{if(0<e.length){var k=e.shift(),l=a(d,e,f,h);if("SCRIPT"==String(k.nodeName).toUpperCase()&&"text/gtmscript"==k.type){var m=E.createElement("script");m.async=!1;m.type="text/javascript";m.id=k.id;m.text=k.text||k.textContent||k.innerHTML||"";k.charset&&(m.charset=k.charset);var q=k.getAttribute("data-gtmsrc");q&&(m.src=q,jc(m,l));d.insertBefore(m,null);q||l()}else if(k.innerHTML&&0<=k.innerHTML.toLowerCase().indexOf("<script")){for(var r=
[];k.firstChild;)r.push(k.removeChild(k.firstChild));d.insertBefore(k,null);a(k,r,l,h)()}else d.insertBefore(k,null),l()}else f()}catch(u){H(h)}}}var b=function(d,e,f){xe(function(){var h,k=Qc;k.postscribe||(k.postscribe=fc);h=k.postscribe;var l={done:e},m=E.createElement("div");m.style.display="none";m.style.visibility="hidden";E.body.appendChild(m);try{h(m,d,l)}catch(q){H(f)}})};var c=function(d){if(E.body){var e=
d.vtp_gtmOnFailure,f=Pk(d.vtp_html,d.vtp_gtmOnSuccess,e),h=f.Tc,k=f.C;if(d.vtp_useIframe){}else d.vtp_supportDocumentWrite?b(h,k,e):a(E.body,sc(h),k,e)()}else Dk(function(){c(d)},
200)};Y.__html=c;Y.__html.b="html";Y.__html.g=!0;Y.__html.priorityOverride=0}();






Y.a.evl=["google"],function(){function a(f,h){this.element=f;this.uid=h}function b(){var f=Number(V("gtm.start"))||0;return(new Date).getTime()-f}function c(f,h,k,l){function m(){if(!uk(f.target)){h.has(e.Jb)||h.set(e.Jb,""+b());h.has(e.Bc)||h.set(e.Bc,""+b());var r=0;h.has(e.Lb)&&(r=Number(h.get(e.Lb)));r+=100;h.set(e.Lb,""+r);if(r>=k){var u=Vj(f.target,"gtm.elementVisibility",[h.uid]),p=tk(f.target);u["gtm.visibleRatio"]=Math.round(1E3*p)/10;u["gtm.visibleTime"]=k;u["gtm.visibleFirstTime"]=Number(h.get(e.Bc));
u["gtm.visibleLastTime"]=Number(h.get(e.Jb));Hk(u);l()}}}if(!h.has(e.cb)&&(0==k&&m(),!h.has(e.Ha))){var q=W("self").setInterval(m,100);h.set(e.cb,q)}}function d(f){f.has(e.cb)&&(W("self").clearInterval(Number(f.get(e.cb))),f.h(e.cb))}var e={cb:"polling-id-",Bc:"first-on-screen-",Jb:"recent-on-screen-",Lb:"total-visible-time-",Ha:"has-fired-"};a.prototype.has=function(f){return!!this.element.getAttribute("data-gtm-vis-"+f+this.uid)};a.prototype.get=function(f){return this.element.getAttribute("data-gtm-vis-"+
f+this.uid)};a.prototype.set=function(f,h){this.element.setAttribute("data-gtm-vis-"+f+this.uid,h)};a.prototype.h=function(f){this.element.removeAttribute("data-gtm-vis-"+f+this.uid)};(function(f){Y.__evl=f;Y.__evl.b="evl";Y.__evl.g=!0;Y.__evl.priorityOverride=0})(function(f){function h(){var x=!1,y=null;if("CSS"===l){try{y=xc(m)}catch(G){}x=!!y&&v.length!=y.length}else if("ID"===l){var B=E.getElementById(m);B&&(y=[B],x=1!=v.length||v[0]!==B)}y||(y=[],x=0<v.length);if(x){for(var z=0;z<v.length;z++){var A=
new a(v[z],p);d(A)}v=[];for(var F=0;F<y.length;F++)v.push(y[F]);0<=w&&Ak(w);0<v.length&&(w=zk(k,v,[u]))}}function k(x){var y=new a(x.target,p);x.intersectionRatio>=u?y.has(e.Ha)||c(x,y,r,"ONCE"===t?function(){for(var B=0;B<v.length;B++){var z=new a(v[B],p);z.set(e.Ha,"1");d(z)}Ak(w);if(q&&gk)for(var A=0;A<gk.length;A++)gk[A]===h&&gk.splice(A,1)}:function(){y.set(e.Ha,"1");d(y)}):(d(y),"MANY_PER_ELEMENT"===t&&y.has(e.Ha)&&(y.h(e.Ha),y.h(e.Lb)),y.h(e.Jb))}var l=f.vtp_selectorType,m;"ID"===l?m=String(f.vtp_elementId):
"CSS"===l&&(m=String(f.vtp_elementSelector));var q=!!f.vtp_useDomChangeListener,r=f.vtp_useOnScreenDuration&&Number(f.vtp_onScreenDuration)||0,u=(Number(f.vtp_onScreenRatio)||50)/100,p=f.vtp_uniqueTriggerId,t=f.vtp_firingFrequency,v=[],w=-1;h();q&&hk(h);H(f.vtp_gtmOnSuccess)})}();


var fn={};fn.macro=function(a){if(Sj.Hc.hasOwnProperty(a))return Sj.Hc[a]},fn.onHtmlSuccess=Sj.ke(!0),fn.onHtmlFailure=Sj.ke(!1);fn.dataLayer=Gd;fn.callback=function(a){Zc.hasOwnProperty(a)&&qa(Zc[a])&&Zc[a]();delete Zc[a]};function gn(){Qc[I.s]=fn;Ja($c,Y.a);yb=yb||Sj;Ab=oe}
function hn(){Sf.gtm_3pds=!0;Qc=D.google_tag_manager=D.google_tag_manager||{};if(Qc[I.s]){var a=Qc.zones;a&&a.unregisterChild(I.s);}else{for(var b=data.resource||{},c=b.macros||[],d=0;d<c.length;d++)rb.push(c[d]);for(var e=b.tags||[],f=0;f<e.length;f++)ub.push(e[f]);for(var h=b.predicates||[],k=0;k<h.length;k++)tb.push(h[k]);for(var l=b.rules||[],m=0;m<l.length;m++){for(var q=l[m],r={},u=0;u<q.length;u++)r[q[u][0]]=Array.prototype.slice.call(q[u],1);sb.push(r)}wb=Y;xb=nl;gn();Rj();se=!1;te=0;if("interactive"==E.readyState&&!E.createEventObject||"complete"==E.readyState)ve();else{oc(E,
"DOMContentLoaded",ve);oc(E,"readystatechange",ve);if(E.createEventObject&&E.documentElement.doScroll){var p=!0;try{p=!D.frameElement}catch(x){}p&&we()}oc(D,"load",ve)}mj=!1;"complete"===E.readyState?oj():oc(D,"load",oj);a:{if(!vd)break a;D.setInterval(wd,864E5);
}Wc=(new Date).getTime();}}
(function(a){a()})(hn);


})()
